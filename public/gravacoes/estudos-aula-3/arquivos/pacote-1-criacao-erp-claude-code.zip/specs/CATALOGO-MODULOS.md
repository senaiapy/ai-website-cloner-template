# Catálogo de módulos do ERP modular

Cada módulo é um pacote instalável pelo painel admin, por tenant. Na fase 1, o agente de instalação apresenta os 14 módulos padrão numa entrevista e o dono desliga o que o negócio não usa. **O sistema só constrói o que foi escolhido na entrevista.** Os 14 opcionais entram depois, com a fase 1 no ar, pelo segundo pacote (prompt de inclusão de módulo, skill `incluir-modulo-erp` e uma spec por módulo), num novo ciclo de build, review e deploy. Cada módulo lista suas abas (submenus dentro da página, nunca na sidebar), o que herda do Aureus ERP e de quem depende. O módulo Integrações (conectores, webhooks, API REST e servidor MCP para agentes como Claude Code, OpenClaw e Hermes) é padrão e está detalhado em `INTEGRACOES-API-MCP.md`.

## Núcleo (sempre instalado, não aparece na entrevista)

Usuários, papéis e permissões por módulo, tenants, workspaces, empresas (multi-empresa dentro do tenant), sequências de numeração, moedas, unidades de medida, campos personalizados, visões de tabela salvas, chatter (mensagens, seguidores, anexos e histórico de alteração em qualquer registro), auditoria, fila e outbox, painel admin, configurações, health check.

## Módulos padrão (14)

| # | Módulo | Menu | Abas | Base do Aureus | Depende de |
|---|---|---|---|---|---|
| 1 | Cadastros | Cadastros | Empresas, Projetos, Clientes, Fornecedores, Contatos, Tags e setores | partners e contacts: parceiro único (pessoa, empresa, endereço) com parent_id, título, setor, tags, contas bancárias, endereços, ranking de cliente e fornecedor | núcleo |
| 2 | Pipeline de oportunidades | Comercial | Pipeline, Equipes, Metas, Motivos de perda, Atividades | sales: equipes de venda, atividades e UTM (origem, mídia, campanha) do support | Cadastros |
| 3 | Conversas | Comercial | WhatsApp, Instagram, Respostas rápidas, Templates | chatter: histórico preso ao registro | Cadastros |
| 4 | Financeiro | Financeiro | Entradas e saídas, Contas e caixas, Categorias, Centros de custo, Conciliação, Fluxo de caixa | accounts: diários, moedas, impostos básicos, condições de pagamento | Cadastros |
| 5 | Contas a receber e a pagar | Financeiro | A receber, A pagar, Notas de crédito, Recorrências, Cobranças | accounts e invoices: fatura, conta a pagar, nota de crédito e reembolso na mesma tabela (tipo e estado), condições de pagamento, baixa parcial | Financeiro |
| 6 | Agenda | Agenda | Semana, Dia, Mês, Profissionais e recursos, Serviços | full-calendar e activities: atividades com prazo e responsável | Cadastros |
| 7 | Pessoas | Pessoas | Funcionários, Departamentos, Funções, Contratos, Documentos, Jornada e escala, Habilidades | employees: departamentos, cargos, tipos de contrato, calendários de trabalho, habilidades, documentos | núcleo |
| 8 | Benefícios e folha | Pessoas | Benefícios, Eventos, Competências, Holerites | employees e accounts: lançamento contábil da folha | Pessoas, Financeiro |
| 9 | Estoque | Operação | Produtos, Variações e unidades, Depósitos, Movimentações, Reposição, Inventário, Lotes e validade | products e inventories: variações e atributos, unidades de medida, depósitos e locais, operações (recebimento, entrega, transferência), regras de reposição, lotes | Cadastros |
| 10 | Compras | Operação | Requisições, Cotações, Pedidos, Recebimentos, Fornecedores | purchases: requisição, cotação, pedido com estados, recebimento parcial, conta a pagar no recebimento | Estoque, Contas a receber e a pagar |
| 11 | Treinamento | Treinamento | Cursos, Trilhas, Progresso | sem equivalente no Aureus; padrão de área de membros com player externo | Pessoas |
| 12 | Painel admin | Admin | Painel, Módulos, Tenants e workspaces, Usuários e papéis, Auditoria, Saúde | plugin-manager e security: instalar e desinstalar com dependência, papéis e permissões por módulo, empresas permitidas por usuário | núcleo |
| 13 | Configurações | Admin | Empresa, Aparência, Sequências, Campos personalizados, Visões salvas, Modelos | support, fields e table-views: sequências por empresa e período, campos com coluna física, visões de tabela por usuário | núcleo |
| 14 | Integrações | Integrações | Conectores, Webhooks, API, MCP | sem equivalente no Aureus; NocoBase e Twenty expõem MCP nativo. Detalhe em `INTEGRACOES-API-MCP.md` | núcleo |

## Módulos opcionais (14)

| # | Módulo | Menu | Abas | Base | Depende de |
|---|---|---|---|---|---|
| 16 | Vendas | Comercial | Orçamentos, Pedidos, Entregas, Faturar | Aureus sales: orçamento e pedido no mesmo registro por estado (rascunho, enviado, venda, cancelado), linhas de produto, entrega parcial, fatura gerada do pedido, equipes e metas | Cadastros, Estoque, Contas a receber e a pagar |
| 16 | Projetos e tarefas | Operação | Projetos, Tarefas, Marcos, Estágios | Aureus projects: tarefas em kanban, marcos, estágios, visibilidade | Cadastros |
| 17 | Apontamento de horas | Operação | Horas, Por projeto, Por pessoa, Faturar horas | Aureus timesheets | Projetos e tarefas, Pessoas |
| 18 | Recrutamento | Pessoas | Vagas, Candidatos, Etapas, Entrevistas | Aureus recruitments: candidato vira funcionário na contratação | Pessoas |
| 19 | Férias e ausências | Pessoas | Tipos, Saldos, Pedidos, Aprovações, Calendário | Aureus time-off | Pessoas |
| 20 | Contabilidade | Financeiro | Plano de contas, Diários, Lançamentos, Impostos, Fechamento, Relatórios | Aureus accounting e accounts: partida dobrada, diários, impostos, relatórios | Financeiro, Contas a receber e a pagar |
| 21 | Fabricação | Operação | Lista de materiais, Ordens de produção, Centros de trabalho, Consumo | Aureus manufacturing | Estoque |
| 22 | Manutenção | Operação | Equipamentos, Pedidos, Preventivas, Equipes | Aureus maintenance | núcleo |
| 23 | Tickets e helpdesk | Comercial | Tickets, Filas, SLA, Base de conhecimento | Odoo e ERPNext; encaixa nas Conversas | Cadastros |
| 24 | Ponto de venda | Operação | Caixa, Mesas, Delivery, Fechamento | Odoo e ERPNext (URY): offline, ligado a estoque e financeiro | Estoque, Financeiro |
| 25 | Assinaturas e recorrência | Financeiro | Planos, Assinaturas, Renovações, Cancelamentos | Odoo | Contas a receber e a pagar |
| 26 | Despesas e reembolso | Financeiro | Despesas, Aprovações, Reembolsos | Odoo e ERPNext; reembolso na folha ou no financeiro | Pessoas, Financeiro |
| 27 | Documentos e assinatura | Cadastros | Arquivos, Contratos, Assinaturas | Odoo: repositório por registro e assinatura eletrônica | Cadastros |
| 28 | Portal do cliente | Comercial | Acesso do cliente, Faturas, Pedidos, Documentos | Aureus customer panel: login próprio do cliente final | Cadastros, Contas a receber e a pagar |

Módulos que o catálogo reserva para depois, sem entrar na entrevista da primeira versão: Site e blog, Marketing e automações, Qualidade e inspeção, Frota.

## Perfis sugeridos (a entrevista oferece como atalho, o dono ajusta)

- Clínica: padrão sem Compras, mais Portal do cliente, Assinaturas, Documentos e assinatura, Férias e ausências.
- Escritório de serviços: padrão sem Estoque e Compras, mais Projetos e tarefas, Apontamento de horas, Vendas, Documentos e assinatura.
- Restaurante: padrão sem Pipeline e Treinamento, mais Ponto de venda, Fabricação (fichas técnicas), Férias e ausências.
- Loja e distribuidora: padrão completo, mais Vendas, Contabilidade, Ponto de venda.
- Agência e consultoria: padrão sem Estoque e Compras, mais Projetos e tarefas, Apontamento de horas, Vendas, Assinaturas, Recrutamento.

## Formato do resultado da entrevista

O agente grava `specs/modulos.json`:

```json
{
  "nicho": "clinica",
  "topologia": "1-vps",
  "modulos": ["cadastros", "pipeline", "conversas", "financeiro", "contas", "agenda", "pessoas", "folha", "treinamento", "admin", "configuracoes", "integracoes", "portal-cliente", "assinaturas"],
  "integracoes": ["whatsapp-cloud-api", "instagram-messenger", "google-calendar:maton", "webhook-landing", "pix-boleto", "players:youtube,vimeo"]
}
```

A ordem de construção sai deste arquivo pela resolução de dependências: um módulo só entra na fila depois de todos os que ele lista em `depende_de`.
