# Módulo opcional: Despesas e reembolso

- Slug: `despesas`
- Menu principal: Financeiro
- Abas na página: Despesas, Aprovações, Reembolsos
- Depende de: pessoas, financeiro
- Sidebar: não ganha item novo; entra como aba dentro de Financeiro. Se o menu Financeiro ainda não existir no tenant, o módulo cria o item principal.

## Escopo

Funcionário lança despesa com comprovante e categoria, gestor aprova, reembolso sai como conta a pagar ou como provento na folha, relatório por centro de custo.

## Agregados e entidades

- Despesa (raiz): funcionario, data, categoria, valor, comprovante_url, centro_custo, estado (rascunho, enviada, aprovada, recusada, reembolsada)

Toda tabela com `tenant_id`, `workspace_id`, `creator_id`, `created_at`, `updated_at`, `deleted_at`, RLS e chave composta. Prefixo de tabela `despesas_`.

## Casos de uso

- LancarDespesa
- EnviarParaAprovacao
- AprovarDespesa
- ReembolsarDespesa (conta a pagar ou evento de folha)

Comando devolve void e passa por caso de uso; consulta devolve DTO. Entidade e objeto de valor com `create` e `tryCreate`. Result em vez de exceção. Trabalho lento (envio, geração de documento, job recorrente) vai pra fila com outbox.

## Rotas

`/api/v1/despesas/...` descritas em OpenAPI antes do código: uma rota por caso de uso, listagens paginadas com filtro e ordenação, e a interface publicada que outros módulos consomem.

## Interfaces com outros módulos

- Pessoas: funcionario e gestor
- Financeiro: conta a pagar
- Beneficios e folha: provento

Só por interface publicada, nunca por import interno.

## Permissões

`despesas.ver`, `despesas.criar`, `despesas.editar`, `despesas.excluir`, `despesas.aprovar` quando houver aprovação, `despesas.configurar`. Geradas na instalação e ligadas aos papéis existentes conforme a entrevista.

## Telas

Padrão visual do sistema: kicker, título, botão primário rosa, abas na página, cards e tabelas com estados vazio, carregando e erro, mobile sem scroll horizontal, i18n pt, en e es.

## Seeds e dados demo

Registros plausíveis com a marca demo do tenant, suficientes pra demonstrar cada aba.

## Provas exigidas

- Teste de cada caso de uso com repositório em memória.
- Arquivo `.http` com todas as rotas e resposta esperada.
- Screenshot Playwright de cada aba.
- Tentativa de ler registro deste módulo de outro tenant devolvendo 404.
- Instalar e desinstalar pelo painel admin sem erro, com bloqueio quando há dependente.
