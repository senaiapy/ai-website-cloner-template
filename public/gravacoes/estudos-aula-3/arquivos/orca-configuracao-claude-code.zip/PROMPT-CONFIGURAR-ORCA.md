# Prompt · instalar e configurar o Orca na máquina

Cole no Claude Code ou no Codex, em qualquer pasta. Preencha a pasta dos seus projetos entre colchetes.

---

Instala e configura o Orca nesta máquina, do começo ao fim, sem me pedir para fazer nada à mão, e me prova cada passo com a saída do comando. O Orca é o app de desktop gratuito e de código aberto da Stably (github.com/stablyai/orca). Use só os instaladores oficiais da última versão em `https://github.com/stablyai/orca/releases/latest/download/<arquivo>`.

1. **Detectar.** Descobre o sistema operacional e a arquitetura (arm64 ou x64) e confere se o Orca já está instalado. Se já estiver, pula para o passo 3.
2. **Instalar o Orca.**
   - **macOS:** se o Homebrew existir, `brew install --cask stablyai/orca/orca`. Sem Homebrew, baixa `orca-macos-arm64.dmg` (Apple Silicon) ou `orca-macos-x64.dmg` (Intel), monta com `hdiutil attach`, copia `Orca.app` para `/Applications`, desmonta com `hdiutil detach` e apaga o DMG.
   - **Windows:** no PowerShell, baixa `orca-windows-setup.exe` para a pasta temporária com `Invoke-WebRequest`, roda o instalador em modo silencioso (`Start-Process <arquivo> -ArgumentList '/S' -Wait`) e apaga o instalador.
   - **Linux:** consulta `https://api.github.com/repos/stablyai/orca/releases/latest` para pegar o nome exato do pacote. Debian e Ubuntu: baixa o `orca-ide_<versão>_amd64.deb` ou `_arm64.deb` e instala com `sudo apt install ./<arquivo>`. Fedora e derivados: o `.rpm` correspondente com `sudo dnf install ./<arquivo>`. Outras distros: baixa `orca-linux.AppImage` ou `orca-linux-arm64.AppImage` para `~/.local/bin/`, dá `chmod +x` e cria o atalho.
   - Se algum passo pedir senha de administrador, me avisa em uma linha e espera eu digitar.
3. **Comando no terminal.** Roda `orca --version`. No macOS, se o comando não existir, cria o link `ln -sf /Applications/Orca.app/Contents/Resources/bin/orca ~/.local/bin/orca` e garante `~/.local/bin` no PATH do meu shell. No Windows, procura o binário `orca` dentro da pasta de instalação e coloca essa pasta no PATH do usuário. No Linux, fora dos terminais do Orca, usa `orca-ide` e nunca `orca` (que é o leitor de tela do GNOME).
4. **App no ar.** `orca open --json` e depois `orca status --json`, até o runtime aparecer pronto.
5. **Guia do próprio binário.** `orca skills get orca-cli` e lê o guia antes de qualquer outro comando, porque os subcomandos mudam entre versões.
6. **Skills dos agentes.** `orca skills install --all` para instalar as skills do Orca (orca-cli, orchestration, computer-use e as demais) nos agentes detectados, Claude Code e Codex incluídos. Mostra `orca skills installed`.
7. **Projetos.** Para cada repositório git dentro de [PASTA DOS PROJETOS], roda `orca repo add` com o caminho e mostra `orca repo list --json`.
8. **Teste de worktree.** No primeiro projeto, cria um worktree de teste com `orca worktree create`, mostra `orca worktree list --json` e remove o worktree de teste com `orca worktree rm`.
9. **Reporte.** Me entrega a versão do Orca instalada, os projetos cadastrados, as skills instaladas e qualquer passo que ficou pendente, com a saída de cada comando.

Não instale nada além do Orca e das skills dele. Não altere arquivo de projeto.
