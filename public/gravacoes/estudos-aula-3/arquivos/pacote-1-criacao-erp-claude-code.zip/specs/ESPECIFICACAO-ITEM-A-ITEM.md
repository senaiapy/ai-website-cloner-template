# Especificação item a item do ERP modular (fase 1)

Este arquivo diz ao Claude Code, item por item, tudo o que será construído na fase 1. Cada item tem um código (I1, N3, M5.2...). O agente marca cada código em `docs/LOOP-STATE.md` como pendente, feito ou verificado, e só declara a fase 1 concluída quando todos os códigos dos módulos escolhidos em `specs/modulos.json` estiverem verificados com prova.

A fase 1 constrói a infraestrutura, o núcleo e os módulos iniciais (os 14 padrão do catálogo, menos os que o dono desligar na entrevista). Os 14 módulos opcionais NÃO entram na fase 1: eles chegam depois, com o pacote 2 (`pacote-2-modulos-opcionais-erp`), quando a fase 1 estiver no ar.

Regras que valem para todos os itens:

- Toda tabela de dado tem `id uuid`, `tenant_id`, `workspace_id`, `creator_id`, `created_at`, `updated_at`, `deleted_at`, RLS ligada e chave composta `(id, tenant_id, workspace_id)`. Prefixo de tabela igual ao slug do módulo.
- Escopo de tenant e workspace vem da sessão, nunca de header, query ou corpo.
- Comando passa por caso de uso (`execute(entrada) -> Result`) e devolve void; consulta lê direto e devolve DTO.
- Entidade e objeto de valor com `create` e `tryCreate`. Erro é valor (Result), não exceção.
- Trabalho lento vai para a fila, com a intenção gravada antes no outbox.
- Rotas em `/api/v1/<modulo>/...`, descritas em OpenAPI antes do código.
- Toda tela com estados vazio, carregando e erro, tema claro e escuro, pt, en e es, mobile sem scroll horizontal.
- Zero gradiente, zero emoji, zero travessão em texto de tela. Cor só por token.

---

## Parte I · Infraestrutura (camadas 1 e 9)

**I1. Repositório.** Repositório privado no GitHub criado antes da primeira linha. Monorepo com `apps/api`, `apps/worker`, `apps/web`, `packages/shared`, `modules/`, `infra/`, `specs/`, `docs/`. Branch padrão `master`. Hook de caça de segredos antes de cada push.

**I2. Servidor.** VPS Linux (topologia 1) ou duas ou mais VPS de aplicação atrás de load balancer (topologia 2), conforme `specs/modulos.json`. Script em `infra/` que cria usuários de sistema, pastas, permissões, unidades e timers. Rodar o script duas vezes não muda nada.

**I3. Serviços systemd.** Unidades `erp-api`, `erp-worker` e `caddy`, todas com `Restart=always`. API e worker em porta alta escutando só em `127.0.0.1`.

**I4. Segredos.** Arquivo de template com referências ao cofre (1Password ou equivalente), `.env` derivado com permissão 600, nunca versionado. Nenhuma chave de IA ou integração no frontend.

**I5. Caddy e domínio.** Subdomínio apontado no Cloudflare para o servidor, HTTPS automático no Caddy, proxy para a API local, arquivos estáticos do frontend servidos com cache longo e `index.html` sem cache.

**I6. Health.** `GET /health` devolve versão (SHA), estado do banco e estado da fila. `GET /health/ready` devolve 503 quando banco ou Redis estão fora, para o load balancer tirar a réplica do rodízio.

**I7. Logs e alertas.** Logs estruturados em JSON com `request_id`, tenant e rota. Alerta quando o worker para ou quando a fila passa de um limite configurável.

**I8. Deploy.** Script `infra/deploy.sh` que recebe um SHA, monta uma cópia limpa (`git worktree add --detach`), roda migrations, sobe um canário em porta reservada, testa `/health` do canário e só então reinicia as réplicas uma a uma. Rollback para o SHA anterior em um comando.

**I9. Backup.** Timer diário com `pg_dump` comprimido, enviado para fora do servidor, retenção de 14 dias. Restauração testada uma vez num banco descartável, com o comando documentado em `docs/OPERACAO.md`.

---

## Parte II · Banco (camada 2)

**B1. PostgreSQL 16** com extensões `pgcrypto`, `citext` e `vector` (pgvector).

**B2. Migrations numeradas** em `apps/api/migrations/NNNN_nome.sql` e em `modules/<slug>/migrations/`, idempotentes, registradas numa tabela `schema_migrations`. Runner que aplica em ordem e para tudo na primeira falha.

**B3. Contexto da sessão.** Toda transação da API abre com `set_config('app.tenant_id', ...)` e `set_config('app.workspace_id', ...)`. Colunas `tenant_id` e `workspace_id` têm default lido desse contexto.

**B4. RLS.** Política em toda tabela de dado filtrando por `tenant_id = current_setting('app.tenant_id')::uuid` e `workspace_id = current_setting('app.workspace_id')::uuid`. O papel do banco usado pela API não é dono das tabelas e não tem `BYPASSRLS`.

**B5. Integridade de escopo.** Chave estrangeira composta em toda referência entre tabelas de dado. Trigger impede alterar `tenant_id` e `workspace_id` depois de criados.

**B6. Funções privilegiadas.** Criação de tenant e promoção a dono só por função `SECURITY DEFINER` com `search_path` fixo.

**B7. Teste de isolamento.** Script que cria dois tenants, grava dado em cada um e prova que a sessão do tenant A recebe zero linhas do tenant B em todas as tabelas.

---

## Parte III · Núcleo (sempre instalado)

**N1. Usuários.** Tabela `usuarios` (nome, e-mail citext único, hash de senha argon2id, idioma, tema, ativo, último acesso). Convite por e-mail com link de uso único e validade de 72 horas.

**N2. Autenticação.** Login por e-mail e senha, sessão em cookie assinado `HttpOnly`, `Secure` e `SameSite=Lax`, expiração deslizante. Logout que invalida a sessão no servidor. Recuperação de senha por e-mail com token de uso único (30 minutos). Rate limit e bloqueio progressivo por e-mail e por IP.

**N3. Tenants e workspaces.** `tenants` (nome, plano, estado), `workspaces` (tenant, nome, slug, fuso, moeda, idioma padrão). Usuário pode pertencer a vários workspaces; seletor de workspace no topo da sidebar.

**N4. Empresas.** Multi-empresa dentro do tenant: `empresas` (razão social, nome fantasia, documento, endereço, logo). Usuário tem lista de empresas permitidas.

**N5. Papéis e permissões.** `papeis`, `permissoes` (código `modulo.acao`), `papel_permissoes`, `usuario_papeis`. Papéis de fábrica: Dono, Administrador, Gestor, Operador, Leitura. Middleware `requer('modulo.acao')` em toda rota.

**N6. Sequências.** `sequencias` (código, prefixo, próximo número, reinício por ano opcional, por empresa). Função transacional que entrega o próximo número sem buraco nem duplicidade sob concorrência.

**N7. Moedas e unidades.** Tabelas `moedas` e `unidades_medida` com dados de fábrica (BRL, USD, EUR; un, kg, g, l, ml, m, h, cx).

**N8. Campos personalizados.** `campos_personalizados` (módulo, entidade, chave, rótulo, tipo texto, número, data, lista ou booleano, obrigatório, ordem). Valores em coluna `extras jsonb` da entidade, validados pelo tipo. Aparecem no formulário e na tabela.

**N9. Visões salvas.** `visoes_salvas` (usuário, tela, filtros, colunas, ordenação, padrão). Toda tabela de listagem permite salvar e escolher visão.

**N10. Chatter.** Em qualquer registro: mensagens, notas internas, seguidores, anexos e histórico de alteração de campo. Tabelas `chatter_mensagens`, `chatter_seguidores`, `anexos`. Componente único reaproveitado por todos os módulos.

**N11. Auditoria.** `auditoria` (usuário ou chave de API, ação, entidade, id, antes, depois, IP, data). Gravada por todo caso de uso de escrita. Só leitura na interface.

**N12. Fila e outbox.** Tabela `outbox` (tipo de job, payload, estado, tentativas, disponível em). Despachante que move do outbox para o BullMQ e reenvia o que ficou pendente após reinício do Redis. Tabela `jobs` com estado visível para a interface (pendente, rodando, concluído, erro) e rota `GET /api/v1/jobs/:id`.

**N13. Sistema de módulos.** Tabela `modulos` (slug, versão, estado instalado ou desinstalado, instalado_em, por tenant). Cada módulo tem `modules/<slug>/module.json` com `nome`, `versao`, `depende_de`, `menu`, `abas`, `permissoes`, `eventos`. Comandos `modulo:instalar <slug>` e `modulo:desinstalar <slug>`: instalar resolve dependências e instala antes; desinstalar é bloqueado com mensagem clara enquanto um módulo instalado depende dele. Desinstalar esconde menus e rotas e preserva os dados.

**N14. Catálogo de eventos.** Registro onde cada módulo declara seus eventos (`cliente.criado`, `fatura.paga`...). Publicação de evento grava no outbox na mesma transação do caso de uso.

**N15. Anotação `@tool`.** Casos de uso e consultas marcados com `@tool` viram automaticamente tool do servidor MCP e rota da API pública, com schema derivado do DTO.

**N16. Configurações gerais.** `configuracoes` chave e valor por workspace com histórico de alteração.

**N17. E-mail transacional.** Serviço `email.enviar(template, para, dados)` via Resend, sempre pela fila. Templates de convite, recuperação de senha e cobrança.

---

## Parte IV · Shell do frontend (camada 8)

**F1. Stack.** React com Vite e TypeScript, Tailwind só com classes core, React Router, TanStack Query para dados. Uma pasta por módulo em `apps/web/src/modules/<slug>/`.

**F2. Tokens.** Arquivo `tokens.css` com toda cor em oklch. Tema escuro padrão: fundo preto, superfícies `#121214`, `#1b1b1f`, `#26262c`, tinta `#fafafa`, `#d0d0d8`, `#a4a4b0`, borda `#323238`, acento rosa `oklch(0.50 0.20 8)`, roxo, azul, ciano para dados, laranja para atenção, dourado para créditos. Tema claro equivalente. Tema aplicado no `<html>` antes do paint.

**F3. Tipografia.** Bricolage Grotesque na interface e JetBrains Mono em números e kickers, hospedadas junto do app.

**F4. Login.** Duas colunas (marca à esquerda, formulário à direita), única rota pública, link "esqueci a senha".

**F5. Sidebar.** 256px, gerada de um array, filtrada por permissão e por módulo instalado. Só menus principais: Início, Cadastros, Comercial, Financeiro, Agenda, Pessoas, Operação, Treinamento, Integrações, Admin. Item ativo com fundo rosa suave. Sem numeração e sem badge de atalho. Recolhível no mobile.

**F6. Página de seção.** Kicker, título, botão primário rosa, abas da seção (os submenus vivem aqui, nunca na sidebar), conteúdo com cards e tabelas.

**F7. Componentes base.** Tabela com paginação por cursor, filtro, ordenação e visão salva; formulário com validação e campos personalizados; modal; drawer; kanban; calendário; toast; estados vazio, carregando e erro; painel de chatter.

**F8. Idiomas.** pt, en e es trocando ao vivo, dicionário com chaves por módulo.

**F9. Onboarding.** Tour de holofote no primeiro login apontando sidebar, seletor de workspace, primeira ação e menu Admin.

**F10. Início.** Painel com indicadores dos módulos instalados (oportunidades abertas, a receber na semana, agenda de hoje, estoque abaixo do mínimo) e atalhos.

---

## Parte V · Módulos iniciais

Cada módulo abaixo vira um pacote em `modules/<slug>/` com `module.json`, migrations, agregados (`model/`, `use-case/`, `query/`, `adapter/`), `routes.ts`, permissões (`<slug>.ver`, `.criar`, `.editar`, `.excluir` e as específicas listadas), seeds demo, telas e testes.

### M1. Cadastros (`cadastros`) · menu Cadastros · depende do núcleo

- **M1.1 Agregado Parceiro.** Registro único para pessoa e empresa: tipo (pessoa, empresa), nome, documento (CPF ou CNPJ validado por objeto de valor), e-mail, telefone (objeto de valor E.164), `parent_id` (contato ligado à empresa), cargo, setor, tags, origem, ranking de cliente e de fornecedor, flags `e_cliente` e `e_fornecedor`.
- **M1.2 Endereços e contas bancárias** do parceiro, vários por registro.
- **M1.3 Projeto.** Cliente, equipe, prazo, orçamento, status (planejado, em andamento, pausado, concluído, cancelado).
- **M1.4 Tags e setores** configuráveis.
- **M1.5 Casos de uso.** CriarParceiro, EditarParceiro, ArquivarParceiro, MesclarDuplicados, CriarProjeto, MudarStatusProjeto, ImportarParceirosCSV (job).
- **M1.6 Webhook de landing page.** Endpoint público assinado por token do tenant que recebe formulário, cria ou atualiza o parceiro pelo e-mail ou telefone e abre oportunidade no Pipeline quando instalado.
- **M1.7 Abas.** Empresas, Projetos, Clientes, Fornecedores, Contatos, Tags e setores. Ficha do parceiro com chatter, histórico e registros ligados de outros módulos.
- **M1.8 Eventos.** `cliente.criado`, `cliente.atualizado`, `projeto.criado`. **Tools MCP:** `clientes.listar`, `clientes.obter`, `clientes.criar`, `projetos.listar`.

### M2. Pipeline de oportunidades (`pipeline`) · menu Comercial · depende de Cadastros

- **M2.1 Agregado Oportunidade.** Título, parceiro, valor, moeda, responsável, equipe, etapa, probabilidade, origem, canal, UTM (fonte, mídia, campanha), previsão de fechamento, motivo de perda.
- **M2.2 Etapas configuráveis** por workspace, padrão: novo, contato, proposta, negociação, ganho, perdido.
- **M2.3 Atividades.** Tarefa, ligação, reunião e follow-up com data, responsável e estado, ligadas à Agenda quando instalada.
- **M2.4 Equipes e metas** mensais por equipe e por vendedor.
- **M2.5 Casos de uso.** CriarOportunidade, MoverEtapa, MarcarGanha (com opção de converter em projeto com um clique), MarcarPerdida (motivo obrigatório), AgendarAtividade, ConcluirAtividade.
- **M2.6 Abas.** Pipeline (kanban com arrastar), Equipes, Metas, Motivos de perda, Atividades. Métricas no topo: valor em negociação, conversão por etapa, ciclo médio.
- **M2.7 Eventos.** `oportunidade.criada`, `oportunidade.movida`, `oportunidade.ganha`, `oportunidade.perdida`. **Tools:** `oportunidades.listar`, `oportunidade.criar`, `oportunidade.mover`.

### M3. Conversas (`conversas`) · menu Comercial · depende de Cadastros e dos conectores

- **M3.1 Agregado Conversa.** Canal (WhatsApp, Instagram), parceiro, atendente, estado (aberta, pendente, encerrada), não lidas, última mensagem.
- **M3.2 Mensagens** recebidas por webhook (gravação idempotente pelo id do provedor) e enviadas pela fila, com status de entrega e leitura.
- **M3.3 Respostas rápidas e templates** aprovados da Meta, sincronizados por job.
- **M3.4 Casos de uso.** ReceberMensagem, EnviarMensagem, EnviarTemplate, TransferirAtendente, EncerrarConversa, AbrirOportunidadeDaConversa, AgendarDaConversa.
- **M3.5 Abas.** WhatsApp, Instagram, Respostas rápidas, Templates. Tela de caixa unificada com lista à esquerda e conversa à direita.
- **M3.6 Regra.** Contato desconhecido vira parceiro automaticamente. Desinstalado, o resto do sistema funciona igual.

### M4. Financeiro (`financeiro`) · menu Financeiro · depende de Cadastros

- **M4.1 Contas e caixas.** Banco, agência, conta, saldo inicial, moeda.
- **M4.2 Categorias** em árvore (receita e despesa) e **centros de custo**.
- **M4.3 Agregado Lançamento.** Tipo (entrada, saída, transferência), conta, categoria, centro de custo, parceiro, valor em centavos (objeto de valor Dinheiro, nunca float), data de competência, data de caixa, comprovante anexo, conciliado.
- **M4.4 Conciliação.** Importação de extrato OFX ou CSV por job, sugestão de par por valor e data, confirmação manual.
- **M4.5 Fluxo de caixa** realizado e previsto (com títulos em aberto de M5), por período e por conta.
- **M4.6 Casos de uso.** RegistrarLancamento, Transferir, EstornarLancamento (nunca apagar), ImportarExtrato, Conciliar, ExportarContabil (CSV por job).
- **M4.7 Abas.** Entradas e saídas, Contas e caixas, Categorias, Centros de custo, Conciliação, Fluxo de caixa.
- **M4.8 Eventos.** `lancamento.registrado`. **Tools:** `financeiro.saldo`, `lancamentos.listar`.

### M5. Contas a receber e a pagar (`contas`) · menu Financeiro · depende de Financeiro

- **M5.1 Agregado Documento.** Uma tabela para fatura, conta a pagar, nota de crédito e reembolso (campo tipo), com número por sequência, parceiro, itens, vencimento, condição de pagamento, valor, juros, multa, desconto, estado (em aberto, parcial, pago, cancelado).
- **M5.2 Baixa** parcial e total; cada baixa gera lançamento em M4.
- **M5.3 Recorrência** mensal, trimestral e anual gerando documentos por job.
- **M5.4 Cobrança automática** por WhatsApp e e-mail no vencimento e em atraso, pela fila, com régua configurável.
- **M5.5 Pix e boleto** pelo conector de pagamento; webhook de confirmação baixa o documento de forma idempotente.
- **M5.6 Casos de uso.** EmitirDocumento, Baixar, CancelarDocumento, GerarCobranca, ConfigurarRecorrencia.
- **M5.7 Abas.** A receber, A pagar, Notas de crédito, Recorrências, Cobranças. Atrasados em destaque.
- **M5.8 Eventos.** `fatura.emitida`, `fatura.paga`, `fatura.vencida`. **Tools:** `fatura.criar`, `fatura.baixar`, `faturas.vencidas`. `Idempotency-Key` obrigatório no POST.

### M6. Agenda (`agenda`) · menu Agenda · depende de Cadastros

- **M6.1 Recursos.** Profissional, sala ou equipamento, com horário de trabalho e bloqueios.
- **M6.2 Serviços** com duração e preço.
- **M6.3 Agregado Agendamento.** Recurso, serviço, parceiro, oportunidade opcional, início, fim, estado (marcado, confirmado, realizado, faltou, cancelado), recorrência.
- **M6.4 Disponibilidade.** Consulta de horários livres por recurso e serviço; conflito bloqueado na gravação.
- **M6.5 Google Calendar** nos dois sentidos via Maton ou OAuth direto, por job, conflito resolvido pelo evento mais recente.
- **M6.6 Confirmação e lembrete** pelo WhatsApp por job (24 h e 2 h antes, configurável).
- **M6.7 Abas.** Semana, Dia, Mês, Profissionais e recursos, Serviços.
- **M6.8 Eventos.** `agenda.marcado`, `agenda.confirmado`, `agenda.cancelado`. **Tools:** `agenda.disponibilidade`, `agenda.agendar`.

### M7. Pessoas (`pessoas`) · menu Pessoas · depende do núcleo

- **M7.1 Agregado Funcionário.** Dados pessoais, documento, contrato (tipo, admissão, salário), departamento, função, gestor, jornada, estado. Funcionário nasce com usuário e papel.
- **M7.2 Departamentos e funções** com permissões herdadas.
- **M7.3 Documentos** com validade e alerta de vencimento por job.
- **M7.4 Jornada e escala** por calendário de trabalho.
- **M7.5 Habilidades** e histórico de cargo e salário.
- **M7.6 Onboarding** com checklist por função.
- **M7.7 Abas.** Funcionários, Departamentos, Funções, Contratos, Documentos, Jornada e escala, Habilidades.
- **M7.8 Eventos.** `funcionario.admitido`, `funcionario.desligado`.

### M8. Benefícios e folha (`folha`) · menu Pessoas · depende de Pessoas e Financeiro

- **M8.1 Benefícios** por funcionário ou por função.
- **M8.2 Eventos de folha.** Provento, desconto e encargo, fixos ou variáveis.
- **M8.3 Competência.** Abertura, cálculo, conferência e fechamento mensal; o fechamento roda como job com trilha de auditoria.
- **M8.4 Holerite** por funcionário em PDF, enviado por e-mail pela fila.
- **M8.5 Lançamento** do total da folha no Financeiro, por centro de custo.
- **M8.6 Abas.** Benefícios, Eventos, Competências, Holerites.
- **M8.7 Evento.** `folha.fechada`.

### M9. Estoque (`estoque`) · menu Operação · depende de Cadastros

- **M9.1 Produtos** com variações e atributos, unidade, código de barras, custo, preço, estoque mínimo.
- **M9.2 Depósitos e locais.**
- **M9.3 Agregado Movimentação.** Entrada, saída, transferência e ajuste com motivo obrigatório. O saldo é sempre a soma das movimentações; nenhum saldo é editado à mão.
- **M9.4 Reposição.** Alerta por job quando o saldo cai abaixo do mínimo.
- **M9.5 Inventário** com contagem e ajuste automático da diferença.
- **M9.6 Lotes e validade.**
- **M9.7 Custo médio** e valor em estoque.
- **M9.8 Abas.** Produtos, Variações e unidades, Depósitos, Movimentações, Reposição, Inventário, Lotes e validade.
- **M9.9 Eventos.** `estoque.abaixo_minimo`. **Tools:** `estoque.saldo`, `produtos.listar`.

### M10. Compras (`compras`) · menu Operação · depende de Estoque e Contas

- **M10.1 Requisição, cotação e pedido** num fluxo com estados: rascunho, enviado, confirmado, recebido, cancelado.
- **M10.2 Fornecedor** com condição de pagamento e prazo.
- **M10.3 Recebimento** parcial e total conferido com o pedido, gerando entrada no Estoque e conta a pagar em Contas.
- **M10.4 Histórico de preço** por produto e fornecedor.
- **M10.5 Abas.** Requisições, Cotações, Pedidos, Recebimentos, Fornecedores.
- **M10.6 Tool.** `pedido_compra.criar`.

### M11. Treinamento (`treinamento`) · menu Treinamento · depende de Pessoas

- **M11.1 Cursos** com módulos e aulas em ordem e pré-requisito.
- **M11.2 Player externo.** YouTube, Vimeo, Panda Video e Bunny Stream, guardando só o id do vídeo.
- **M11.3 Layout de área de membros.** Vídeo grande com lista de aulas ao lado.
- **M11.4 Progresso** por pessoa, conclusão e certificado interno.
- **M11.5 Trilhas** por função; funcionário admitido recebe a trilha da função.
- **M11.6 Material de apoio** anexado à aula.
- **M11.7 Abas.** Cursos, Trilhas, Progresso.

### M12. Painel admin (`admin`) · menu Admin · sempre instalado

- **M12.1 Painel** com saúde (PostgreSQL, Redis, worker, versão no ar), jobs na fila e erros recentes.
- **M12.2 Módulos.** Lista do catálogo com estado, dependências e botões instalar e desinstalar, sem deploy.
- **M12.3 Tenants e workspaces**, planos e créditos.
- **M12.4 Usuários e papéis** com permissões por módulo e empresas permitidas.
- **M12.5 Auditoria** com filtro por usuário, entidade e período.
- **M12.6 Abas.** Painel, Módulos, Tenants e workspaces, Usuários e papéis, Auditoria, Saúde.

### M13. Configurações (`configuracoes`) · menu Admin · sempre instalado

- **M13.1 Empresa** (dados, logo) e **Aparência** (cores de marca dentro dos tokens, tema e idioma padrão).
- **M13.2 Sequências** de pedido, fatura e contrato.
- **M13.3 Campos personalizados** por cadastro, com tela de criação.
- **M13.4 Visões salvas** e **modelos** de mensagem e documento.
- **M13.5 Etapas do pipeline, categorias financeiras e funções** editáveis aqui.
- **M13.6 Abas.** Empresa, Aparência, Sequências, Campos personalizados, Visões salvas, Modelos. Toda alteração com histórico.

### M14. Integrações (`integracoes`) · menu Integrações · sempre instalado

Construído exatamente como `specs/INTEGRACOES-API-MCP.md`.

- **M14.1 Conectores.** WhatsApp Cloud API, Instagram Messenger API, Google Calendar, players de vídeo, pagamentos (Asaas ou Stripe) e Resend, com credencial no cofre, status, testar e reconectar.
- **M14.2 Webhooks de saída.** Assinatura por evento, HMAC-SHA256, `X-ERP-Signature` e `X-ERP-Timestamp`, retry em 1 min, 5 min, 30 min, 2 h e 12 h, log de entregas, reenvio manual, desativação após 20 falhas.
- **M14.3 Webhooks de entrada.** Um endpoint por conector, validação de assinatura, idempotência pelo id do evento, gravação e enfileiramento.
- **M14.4 API REST.** `/api/v1`, OpenAPI 3.1 em `/api/docs`, chave por workspace com escopo por módulo, rate limit por chave, `Idempotency-Key`, paginação por cursor, erros padronizados, auditoria.
- **M14.5 Servidor MCP.** `/mcp` Streamable HTTP, tools geradas dos `@tool` dos módulos instalados, resources, prompts, Bearer, RBAC por tool, auditoria, timeout de 30 s com job para tool lenta.
- **M14.6 Snippets** prontos para Claude Code, OpenClaw e Hermes com a URL do tenant e a chave recém-criada.
- **M14.7 Abas.** Conectores, Webhooks, API, MCP.

---

## Parte VI · Dados demo

**D1.** Seed por módulo com dados plausíveis do nicho escolhido (nomes, valores e datas coerentes), suficientes para cada aba ter conteúdo na primeira demonstração.

**D2.** Workspace sandbox separado para o integrador testar a API e o MCP.

---

## Parte VII · Provas exigidas (definição de concluído da fase 1)

**P1.** `curl https://<dominio>/health` devolvendo 200 com o SHA do deploy.
**P2.** Login real com o usuário dono e screenshot de cada menu e de cada aba dos módulos instalados.
**P3.** Teste de cada caso de uso com repositório em memória, todos verdes.
**P4.** Arquivo `.http` por módulo com todas as rotas e a resposta esperada.
**P5.** Script B7 provando isolamento entre dois tenants, mais tentativa de ler registro de outro tenant por id, por rota, por webhook e por job, devolvendo 404 ou zero linhas.
**P6.** Instalar e desinstalar um módulo pelo painel admin, com o bloqueio aparecendo quando há dependente.
**P7.** Chave de API com escopo devolvendo 200, fora do escopo 403, de outro tenant 404.
**P8.** Claude Code conectado ao `/mcp` do tenant demo listando as tools e chamando `clientes.listar`.
**P9.** Webhook de saída entregue com assinatura válida e retry após falha simulada; webhook de entrada com assinatura inválida rejeitado.
**P10.** Fila: Redis reiniciado no meio de um job e o outbox reenviando sem duplicar.
**P11.** Greps de `gradient`, emoji e travessão no frontend devolvendo zero.
**P12.** Backup gerado e restaurado num banco descartável.
**P13.** Repositório no GitHub igual ao SHA em produção, sem segredo versionado.

Com P1 a P13 verdes, a fase 1 está no ar. A partir daí entra o pacote 2 para os módulos opcionais.
