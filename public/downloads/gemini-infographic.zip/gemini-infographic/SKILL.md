---
name: gemini-infographic
description: >
  Gera o prompt de infográfico estilo lousa desenhado à mão, aquele formato que estoura de impressões no feed. Pega um conteúdo de origem (um post, uma newsletter, um artigo de blog, uma nota de pesquisa) e devolve um prompt completo de geração de imagem no Gemini com um briefing estruturado. Use esta skill sempre que o dono pedir "infográfico de lousa", "infográfico no gemini", "gráfico desenhado à mão", "transforma isso em lousa", ou quando ele quiser um infográfico gerado por IA pra um post.
---

# Infográfico no Gemini

## IMPORTANTE: começa sozinha ao carregar

Quando esta skill disparar, vá direto pro Passo 1. Não fique resumindo o processo.

## Passo 1. Pegue o conteúdo de origem

Pergunte:

> Cola aqui o conteúdo que você quer transformar em infográfico. Pode ser um post, um trecho de newsletter, um blog, uma nota de pesquisa ou só os tópicos soltos.

Espere o conteúdo chegar.

## Passo 2. Monte o briefing

Analise o conteúdo e produza um briefing de infográfico em linguagem simples. Inclua:

- **Título** (6 palavras ou menos, de impacto)
- **Subtítulo** (opcional, uma linha de contexto)
- **Estrutura central**: decida entre passos, framework, comparação, números ou lista
- **Pontos-chave**: de 3 a 7 tópicos no máximo, cada um com 10 palavras ou menos
- **Sugestões visuais**: setas, caixas, números destacados, ícones, cores de destaque. Seja específica sobre posição e cor.
- **CTA do rodapé**: texto à mão escrito "Siga [Nome] [Bordão] pra mais conteúdo útil | Reposte ♻️"

Diga pro dono:

> Aqui está o briefing. Me fala o que mudar, ou escreve "gera" quando estiver satisfeito.

Espere a aprovação.

## Passo 3. Devolva o prompt do Gemini

Depois de aprovado, devolva o prompt completo num bloco de código, com o briefing inserido no lugar do marcador `[INSIRA AQUI O CONTEÚDO E O LAYOUT DO SEU INFOGRÁFICO]`:

```
Generate a single image of a physical, hand-drawn infographic on a large whiteboard or notebook page.

Crucial Style Instructions (Read First):

Medium: The image must look like a photograph of a real whiteboard or large paper notepad.

Texture: All elements must look created by hand using colored marker pens (black, blue, red, green) and highlighters (yellow/orange). Lines should be slightly imperfect, wobbly, and have the texture of ink on a surface.

No Digital Fonts: All text, headings, and bullet points must appear handwritten or hand-printed in marker pen.

Layout: Structure the 1080x1350 image as follows:

[INSIRA AQUI O BRIEFING — título, subtítulo, estrutura central, pontos-chave, sugestões visuais]

Use multi-colored markers for emphasis. Keep text large and legible. Make everything look hand-drawn with slight imperfections. Make it look like a photograph of an actual notebook page.

Always include the handwritten text "Siga [Nome] [Bordão] pra mais conteúdo útil | Reposte ♻️" at the bottom of the image, in the same hand-drawn marker style.
```

Diga pro dono:

> Cola isso numa conversa nova do Gemini com a geração de imagem ligada e o Nano Banana selecionado. Gera no tamanho 1080x1350.

## Passo 4. Ofereça ajuste

Depois do prompt, ofereça:

> Se a primeira geração não acertar, me diz o que ajustar que eu reescrevo o prompt. Ajustes comuns: menos cores, título maior, direção de layout diferente.

## Regras

- A saída em 1080x1350 pixels é inegociável. O formato vertical domina o feed.
- O CTA do rodapé sempre inclui o símbolo de reciclagem e a palavra "Reposte".
- Nunca use travessões em nenhuma saída.
- Mantenha os tópicos com menos de 10 palavras. Texto longo perde legibilidade na escala de lousa.
- Sempre espere a aprovação do dono no briefing antes de devolver o prompt final.
- Português do Brasil, a menos que o arquivo voice.md diga outra coisa.
- Se o dono tiver brand-kit.md ou colours.md no projeto, incorpore as cores da marca dele nas sugestões visuais.
