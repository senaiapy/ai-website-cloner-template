---
name: metodo-trafego-meta-ads
description: Gestao de trafego pago no Facebook e Instagram (Meta Ads) pelo MCP OFICIAL da Meta. A Naia cria, gerencia e analisa campanhas direto pelo conector oficial, autenticado pela Meta, sem API key. Use quando o dono pedir pra subir/ajustar/analisar campanha, montar publico, criar criativo, ler metricas ou conectar a conta de anuncios. Passo a passo completo no reference.md.
---

# Tráfego pago — Meta Ads pelo MCP oficial da Meta

> Esta skill faz a Naia nascer **gestora de tráfego oficial**: ela opera o Meta Ads pelo **conector oficial da Meta** (Meta Ads AI Connectors / MCP), com conexão autenticada pela própria Meta. Conhecimento operacional completo + documentação oficial em `reference.md`.

## O que faz
A Naia cuida dos anúncios pagos no Facebook e no Instagram: pensa a estratégia, define público, orienta criativos e texto, cria e ajusta campanhas e lê as métricas pra o dinheiro render. Tudo pelo **MCP oficial da Meta** (não por acesso paralelo, não por API key de terceiro): uma conexão segura, autenticada pela Meta, direto na conta de anúncios do dono.

## PASSO 1 — Conectar o dono ao MCP oficial da Meta (o agente ensina)
Antes de operar, a Naia guia o dono pra conectar a conta de anúncios. É de graça, sem credencial de dev, sem código.

**Pré-requisitos (confira com o dono):**
- Conta no **Meta Business Manager** (business.facebook.com) com papel de **admin**.
- Acesso de anunciante a pelo menos **uma conta de anúncios** ativa.
- O agente precisa suportar conector MCP (o OpenClaw/Codex suporta).

**Endpoint oficial (é só esse):**
```
https://mcp.facebook.com/ads
```

**Como conectar (passo a passo que a Naia passa pro dono):**
1. Adicione o endpoint `https://mcp.facebook.com/ads` como conector/MCP no agente (na config de MCP/conectores).
2. Ao conectar, a Meta abre uma tela de **login/autorização** (OAuth). O dono entra com a conta Meta dele e **autoriza** o acesso à(s) conta(s) de anúncios.
3. Pronto. **Não existe API key nem App ID pra criar** — a autenticação é a própria da Meta. Se a conta tiver `is_ads_mcp_enabled=false`, ela não está habilitada; use outra conta ou habilite no Business Manager.

**Limites e segurança (avise o dono):**
- Cerca de **200 chamadas por hora por conta de anúncios**.
- O conector dá **acesso de ESCRITA total** à conta (cria campanha, muda budget, edita público) **sem rascunho, sem undo, sem tela de confirmação da Meta**. Por isso a regra de ouro abaixo.

## PASSO 2 — Operar como gestora (regras de ouro)
- **NUNCA ativar campanha nem mexer em budget sem o OK explícito do dono.** Toda campanha nasce PAUSED; ativar gasta dinheiro real. Mostra o plano, pede "pode ativar?", e só então ativa.
- Só objetivos **ODAX** (`OUTCOME_AWARENESS/TRAFFIC/ENGAGEMENT/LEADS/SALES/APP_PROMOTION`). Nunca objetivo legado.
- Hierarquia: **Campanha → Conjunto de anúncios (ad set) → Anúncio (ad) → Criativo**. Budget no nível da campanha = CBO; no ad set = ABO (são mutuamente exclusivos).
- Pra `OUTCOME_SALES` + site, o `promoted_object` com **pixel/dataset** é obrigatório.
- Antes de agir, **diagnostica**: visão geral da conta, opportunity score, tendência, benchmarks, erros de entrega.

## Como pedir no Telegram (exemplos)
> "Naia, conecta minha conta de anúncios da Meta. Me ensina o passo a passo."

> "Naia, monta uma campanha de captação de leads no Instagram, orçamento de cinquenta reais por dia, público frio do meu nicho. Deixa tudo pausado e me mostra antes de ativar."

> "Naia, dá uma auditoria na minha conta: o que está com custo alto, qual público ou criativo cortar, e o que ajustar pra baixar o custo por lead."

## Por que
Tráfego pago é o acelerador do negócio: coloca a oferta na frente de gente nova, na escala que quiser. Mas tráfego mal feito queima dinheiro. Ter a estratégia, o público e a leitura de métricas na mão de quem entende, operando pelo conector oficial da Meta, é a diferença entre investir e gastar.

> **Documentação oficial da Meta + mapa completo dos 29 tools do MCP, workflows e anti-patterns: ver `reference.md`.**
