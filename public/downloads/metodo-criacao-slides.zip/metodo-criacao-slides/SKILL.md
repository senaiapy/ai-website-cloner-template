---
name: metodo-criacao-slides
description: Apresentações em HTML com animações cinematográficas, navegação por teclado, transições GSAP, deploy estático em Cloudflare Pages. Substitui Keynote/PowerPoint pra contextos premium. Metodologia o padrão. Use quando o dono pedir esse tipo de tarefa.
---

# Criação de Slides com Reveal.js + GSAP

> Metodologia o padrão #6/11. Tarefa operacional: a Naia delega (Juliana coordena), valida e entrega pro dono.

Apresentações em HTML com animações cinematográficas, navegação por teclado, transições GSAP, deploy estático em Cloudflare Pages. Substitui Keynote/PowerPoint pra contextos premium.

## Quando usar
- Vai dar palestra/aula online
- Precisa de slides com identidade visual única
- Quer slides que rodem em qualquer dispositivo
- Quer slides versionáveis em Git

## Entregáveis
- Apresentação Reveal.js single-file
- Animações GSAP
- Navegação por teclado
- Deploy estático automático
- Versionamento Git

## Tags
slides, design, narrativa

## Passo-a-passo completo (LOCAL — fonte canônica)
O passo-a-passo detalhado completo (etapas + código) está em **`./reference.md`** (nesta skill).
LER `reference.md` antes de executar este método.

