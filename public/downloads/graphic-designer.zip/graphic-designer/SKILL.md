---
name: graphic-designer
description: >
  Cria artes para posts do LinkedIn. Decide entre uma arte estruturada em HTML/CSS ou um infográfico gerado por IA com base no conteúdo do post. Use esta skill sempre que o dono pedir "cria uma arte", "faz um visual", "monta uma imagem", "arte pro meu post", "imagem pro LinkedIn", ou quiser qualquer conteúdo visual para acompanhar um post do LinkedIn. Acione também quando o dono terminar de escrever um post e quiser uma arte combinando.
---

# Designer de Artes

## CRÍTICO: começar sozinha ao carregar

Quando esta skill for acionada, vá direto pro Passo 1. Não resuma. Não explique as opções. Comece imediatamente.

## Passo 1. Ler o post

Veja se o projeto tem o arquivo de post mais recente. Se encontrar, leia. Se não, diga:

> Cola aí o post que você quer transformar em arte.

Espere o post, depois chame AskUserQuestion:

```json
[
  {
    "question": "Que tipo de arte combina melhor com este post?",
    "header": "Estilo",
    "multiSelect": false,
    "options": [
      {"label": "Arte HTML/CSS", "description": "Layout limpo e estruturado. Framework, comparação, passos, dados. Totalmente editável, exporta por print."},
      {"label": "Infográfico de quadro branco", "description": "Estilo desenhado à mão com caneta marcador num quadro branco ou folha de caderno. Resume o post visualmente. Gerado no Gemini."},
      {"label": "Infográfico de marca", "description": "Infográfico profissional usando suas cores de marca. Resume o post visualmente. Gerado no Gemini."},
      {"label": "Você decide", "description": "Analise o post e escolha o melhor formato automaticamente"}
    ]
  }
]
```

Se for "Você decide": analise o post. Se ele tem passos numerados, frameworks, comparações ou tabelas de dados, vá pelo Caminho A (HTML/CSS). Se ele resume um fluxo de trabalho, compartilha dicas, ensina um conceito ou conta uma história, vá pelo Caminho B (prompt de imagem) e escolha o estilo que melhor encaixar.

## Caminho A: arte estruturada em HTML/CSS

Restrições de design:
- 1200 x 1400 pixels (ideal para LinkedIn)
- Fundo escuro (#1a1a2e ou a cor de marca do dono) com texto de alto contraste
- Fonte sans-serif limpa (Inter, system-ui)
- Texto branco ou claro sobre fundo escuro
- Uma cor de destaque para realces e divisórias
- 40px de padding mínimo em todos os lados
- Sem fundos de banco de imagens
- Deixe o conteúdo do post definir quantas seções a arte tem. 3 passos = 3 blocos. 10 dicas = 10 blocos. A restrição é a legibilidade, não um número fixo. Todo elemento precisa ser grande o suficiente para ler na tela do celular.

Arquivo HTML único e autossuficiente com CSS inline. Inclua a meta tag de viewport.

Extraia o framework ou os passos centrais do post. Não copie o post inteiro. Destile em:
- Um título curto (5 a 8 palavras)
- Pontos-chave como blocos visuais (ícones em Unicode estão liberados)
- Rodapé com o nome do autor a partir do about-me.md se disponível

Salve o arquivo HTML. Diga pro dono:

> Abre o HTML no navegador e tira um print.

## Caminho B: prompt de geração de imagem

A arte precisa resumir o conteúdo do post de forma visual. Não é uma ilustração abstrata nem foto de banco de imagens. Ela resume a informação central do post num formato visual que o leitor consegue escanear.

Primeiro, extraia o conteúdo para o infográfico a partir do post:
- O título ou gancho principal (encurtado para 5 a 10 palavras)
- 3 a 6 pontos, passos ou aprendizados principais (uma linha curta cada)
- Quaisquer números, estatísticas ou dados que valha destacar
- Uma linha de rodapé (nome do autor e CTA se fizer sentido)

Depois monte o prompt com base no estilo escolhido.

### Estilo 1: Infográfico de quadro branco

Use este modelo de prompt. Preencha as seções de conteúdo com o que veio do post.

```
Gere uma única imagem de um infográfico físico, desenhado à mão, num quadro branco grande ou folha de caderno.

Instruções de Estilo Cruciais (Leia Primeiro):
Meio: A imagem precisa parecer uma fotografia de um quadro branco real ou bloco de papel grande.
Textura: Todos os elementos precisam parecer feitos à mão com canetas marcadoras coloridas (preta, azul, vermelha, verde) e marca-textos (amarelo/laranja). As linhas devem ser levemente imperfeitas, trêmulas, com a textura de tinta sobre a superfície.
Sem Fontes Digitais: Todo texto, títulos e tópicos precisam parecer escritos ou impressos à mão com caneta marcadora.

Layout: Estruture a imagem 1080x1350 assim:

TÍTULO (marcador grande e em negrito, no topo da página):
[Insira o título a partir do post]

CONTEÚDO (seções desenhadas à mão com caneta marcadora):
[Insira 3 a 6 pontos-chave, cada um como uma linha curta escrita à mão com um marcador, número ou pequeno ícone desenhado ao lado]

[Se houver estatísticas ou números, desenhe-os grandes com um círculo ou caixa ao redor]

Use marcadores de várias cores para dar ênfase. Mantenha o texto grande e legível. Faça tudo parecer desenhado à mão com pequenas imperfeições. Faça parecer uma fotografia de uma folha de caderno de verdade.

Sempre inclua o texto manuscrito "[Nome do autor a partir do about-me.md] | Repost" na parte de baixo da imagem, no mesmo estilo desenhado à mão com marcador.
```

### Estilo 2: Infográfico de marca

Peça as cores de marca ao dono se ainda não souber. Se o about-me.md existir, confira lá primeiro.

```
Gere uma imagem de infográfico profissional em 1080x1350 pixels.

Estilo: Limpo, moderno, editorial. Design flat com cantos retos e tipografia forte. Sem efeitos 3D, sem gradientes, sem fotos de banco de imagens.

Paleta de cores:
- Fundo: [cor primária de marca ou neutro escuro]
- Texto: [branco ou cor de alto contraste]
- Destaque: [cor secundária de marca]

Layout:
TÍTULO (topo, texto grande em negrito):
[Insira o título a partir do post]

CORPO (seções estruturadas, cada uma com um ícone ou número):
[Insira 3 a 6 pontos-chave como linhas curtas, cada uma com um marcador visual: círculo numerado, check ou ícone simples]

[Se houver estatísticas, mostre-as como números grandes em destaque com um rótulo embaixo]

RODAPÉ:
[Nome do autor a partir do about-me.md] | [CTA ou tagline se fizer sentido]

Mantenha o texto grande e fácil de escanear. No máximo 40 palavras na imagem inteira. Sem bordas decorativas. Sem marcas d'água. Sem logos, a menos que o dono forneça um.
```

Mostre o prompt completo num bloco de código. Diga pro dono:

> Cole isso no Gemini ou no seu gerador de imagem. O prompt está pronto pra usar.

## Depois de qualquer caminho

Diga:

> Arte pronta. Fala "avalia meu post" quando quiser feedback antes de publicar.

## Regras

- Sempre leia o post antes de desenhar. A arte precisa resumir o conteúdo do post, não ilustrar um conceito abstrato.
- Artes estruturadas (Caminho A) precisam ser um único arquivo HTML com CSS inline.
- Prompts de imagem (Caminho B) precisam ser totalmente independentes. O dono cola no Gemini sem mais nada e recebe a arte.
- Extraia e destile o conteúdo do post para a arte. Sem copiar o texto inteiro do post.
- Estilo quadro branco: sempre com cara de desenho à mão com marcador, linhas imperfeitas, canetas coloridas, textura de caderno/quadro branco.
- Estilo de marca: sempre limpo, flat, moderno, usando as cores de marca do dono.
- Nunca use travessões em nenhuma saída.
- Português do Brasil em tudo.
