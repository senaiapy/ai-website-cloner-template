---
name: post-scorer
description: >
  Avalia um post de LinkedIn usando dados reais de performance. Puxa o histórico de posts do próprio dono via ferramenta de coleta de posts (ou usa dados em cache) pra identificar o que de fato performa, depois nota o rascunho contra esses padrões. Use esta skill sempre que o dono disser "dá uma nota no meu post", "revisa meu post", "avalia esse post", "me dá um feedback", "esse post tá bom?", ou colar um post de LinkedIn e pedir crítica. Avalia contra dados reais, não conselho genérico. Feita pra avaliar ao vivo em eventos e pra revisar posts no dia a dia.
---

# Avaliador de Post

## CRÍTICO: começa sozinha ao carregar

Quando esta skill disparar, vá direto pro Passo 1. Não resuma. Não explique o método de avaliação. Comece na hora.

## Passo 1. Pegar o post

Se o dono já colou um post na mesma mensagem, use ele. Senão, diga:

> Cola o post de LinkedIn que você quer que eu avalie.

Espere o post.

## Passo 2. Carregar os dados de avaliação

O avaliador precisa de duas coisas: o sistema de voz do dono e dados reais de performance.

### Sistema de voz

Leia os arquivos about-me.md e voice.md do projeto, se existirem. Se faltarem, anote isso e avalie sem comparação de voz.

### Dados de performance

Procure dados de LinkedIn em cache no projeto ou na pasta de saída. Procure arquivos que batam com *-all-posts.json ou *-posts.txt.

Se houver dados em cache, use eles. Se não, pergunte ao dono:

```json
[
  {
    "question": "Pra avaliar seu post contra dados reais, preciso do seu histórico do LinkedIn. Como faço pra pegar?",
    "header": "Fonte de dados",
    "multiSelect": false,
    "options": [
      {"label": "Coletar meus posts", "description": "Puxar meus últimos 100 posts do LinkedIn pela ferramenta de coleta. Leva 1 a 2 minutos e custa cerca de US$ 0,50."},
      {"label": "Usar dados de referência", "description": "Avaliar contra os benchmarks de referência da skill. Boa alternativa."},
      {"label": "Pular avaliação por dados", "description": "Avaliar só pelas boas práticas gerais. Menos preciso, mas instantâneo."}
    ]
  }
]
```

Se "Coletar meus posts":
1. Peça o nome de usuário do LinkedIn dele
2. Use a ferramenta de coleta de posts pra puxar o perfil com a entrada: { "username": "[nome-de-usuario]", "total_posts": 100 }
3. Baixe os resultados (NÃO use o parâmetro de campos, ele tira os dados de engajamento)
4. Salve como [nome-de-usuario]-all-posts.json no projeto
5. Siga pra análise

Se "Usar dados de referência":
Procure os dados de referência em cache em **/linkedin-data/referencia-all-posts.json. Se achar, use. Se não, anote que está usando os benchmarks deste arquivo da skill (listados abaixo).

Se "Pular avaliação por dados":
Volte pra avaliação só pelo sistema de voz e boas práticas gerais.

## Passo 3. Analisar os melhores posts

Quando houver dados de performance, rode esta análise antes de avaliar:

1. Calcule a nota de engajamento de cada post: total_de_reações + (comentários x 3)
2. Identifique os 10% melhores posts por nota de engajamento
3. Desses melhores posts, extraia:
   - Tipos de gancho que mais aparecem (contrário, puxado por número, afirmação ousada, história pessoal, pergunta, notícia)
   - Tamanho médio do post (contagem de palavras)
   - Distribuição de formato (só texto, imagem, carrossel, vídeo)
   - Padrões de CTA (menção a newsletter, pedido pra comentar, pedido de repost, pergunta, nenhum)
   - Grupos de tema que puxam mais engajamento que a média
   - Ritmo das frases (tamanho médio de frase, quebras de parágrafo por post)
4. Anote também os padrões dos 10% piores pra identificar o que fracassa

Salve esses padrões como um "perfil de avaliação" que você consulta pra cada critério.

## Passo 4. Avaliar o post

Avalie em 5 critérios. Cada um de 1 a 10.

### Força do gancho (1 a 10)

Compare a primeira linha do rascunho com os tipos de gancho dos 10% melhores.
- Usa um tipo de gancho que historicamente performa pra este autor?
- É específico, com número, nome ou detalhe concreto?
- Pararia o scroll com base no que de fato para o scroll nos dados dele?
- Dê 8 ou mais só se o tipo de gancho bater com um padrão dos 10% melhores dele

### Aderência à voz (1 a 10)

Se o voice.md existir:
- O post bate com tom, ritmo e tamanho de frase do voice.md?
- Viola alguma regra da seção de padrões de ausência do voice.md (o que a voz nunca faz)?
- O tamanho das frases bate com a média dos melhores posts dele?
Se não houver arquivos de voz: avalie contra os padrões extraídos dos dados de posts dele.

### Densidade de valor (1 a 10)

Compare com os melhores posts do dono:
- Os melhores posts dele ensinam, dão passos, compartilham dados ou contam histórias?
- Este rascunho bate com esse padrão de valor?
- O aprendizado é específico o suficiente pra alguém salvar ou compartilhar?
- Compare a contagem de palavras com a média dos 10% melhores. Sinalize se estiver muito acima ou abaixo.

### Estrutura e formato (1 a 10)

Com base nos dados dele:
- Qual formato (texto, imagem, carrossel) traz mais engajamento pra ele?
- A estrutura do rascunho bate com o ritmo de quebras de linha e parágrafos dos melhores posts?
- O post é fácil de escanear no celular?
- O CTA bate com os padrões dos melhores posts dele?

### Prontidão pra publicar (1 a 10)

- O dono realmente escreveu isso ou parece saída de IA sem edição?
- Esse post se misturaria naturalmente ao feed dele, com base no histórico de publicação?
- Tem algum sinal de alerta: palavras banidas listadas nos padrões de ausência do voice.md, frases genéricas, tom corporativo?
- O tamanho está certo em relação aos melhores posts dele?

## Passo 5. Entregar o scorecard

Entregue dentro de um bloco de código:

```
NOTA DO POST DE LINKEDIN

Fonte de dados: [posts dele / benchmarks de referência / genérico]
Posts analisados: [número]
Engajamento médio dos 10% melhores: [número]

Força do gancho:         [X] / 10  [tipo de gancho detectado]
Aderência à voz:         [X] / 10
Densidade de valor:      [X] / 10
Estrutura e formato:     [X] / 10  [formato: texto/imagem/carrossel]
Prontidão pra publicar:  [X] / 10
----------------------------------------
TOTAL:                   [XX] / 50

VEREDITO: [Uma frase citando um dado específico]

COMPARAÇÃO COM OS MELHORES:
Seus melhores posts têm em média [X] palavras, usam ganchos do tipo [tipo]
e incluem [padrão de CTA]. Este rascunho [bate/difere] porque [motivo específico].

CORREÇÕES:
1. [Correção específica baseada em dado, ex.: "Seus 10% melhores posts abrem com números. Este abre com pergunta. Troque por uma estatística."]
2. [Segunda correção baseada em dado]
3. [Terceira correção se precisar]
```

Toda correção precisa citar um dado real do dono. Não "melhore o gancho", mas "seus 10% melhores posts usam ganchos puxados por número (42% dos acertos). Este rascunho usa gancho de pergunta (12% dos acertos). Comece pela estatística."

## Passo 6. Oferecer o próximo passo

Depois do scorecard:

> Quer que eu reescreva a parte mais fraca usando os padrões dos seus melhores posts, ou já publica?

Se pedirem reescrita, aplique as correções e entregue o post revisado dentro de um bloco de código.

## Benchmarks de reserva (quando não há dado disponível)

Use estes benchmarks de referência como base de avaliação quando o dono escolher "Usar dados de referência" e não houver arquivo em cache:

Engajamento médio: 1.872 (reações + comentários x 3)
Reações médias: 808
Comentários médios: 355
Reposts médios: 61
Razão comentário/reação: 44%

Principais tipos de gancho: puxado por número (31%), afirmação ousada (27%), contrário (18%)
Principais formatos: carrossel (33%), imagem (29%), só texto (22%)
Tamanho médio de post dos 10% melhores: 180 a 250 palavras
Taxa de CTA: 45% mencionam newsletter
Taxa de pedido pra comentar: 5%

## Regras

- Sempre tente usar dados reais antes de cair no conselho genérico.
- Toda nota e toda correção precisa citar um dado específico, não opinião subjetiva.
- Nunca dê mais que 8 a menos que o rascunho realmente bata com os padrões dos 10% melhores.
- Seja honesta. Um avaliador generoso é inútil.
- Se os dados estiverem velhos (14 dias ou mais), sugira uma atualização antes de avaliar.
- Avise o dono antes de rodar uma coleta de posts (custa dinheiro).
- Nunca use travessões em nenhuma saída.
- Português do Brasil o tempo todo.
- Mantenha o scorecard compacto. Ele precisa ficar bom numa tela grande em eventos.
