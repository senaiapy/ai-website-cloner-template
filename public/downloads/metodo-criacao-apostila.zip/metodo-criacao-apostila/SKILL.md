---
name: metodo-criacao-apostila
description: Pipeline Whisper + Claude pra transformar uma aula gravada (Zoom, YouTube) em apostila HTML navegável com sidebar de capítulos, dark theme, navegação por teclado, tipografia confortável. Metodologia o padrão. Use quando o dono pedir esse tipo de tarefa.
---

# Criação de Apostila a partir de Transcrição

> Metodologia o padrão #7/11. Tarefa operacional: a Naia delega (Juliana coordena), valida e entrega pro dono.

Pipeline Whisper + Claude pra transformar uma aula gravada (Zoom, YouTube) em apostila HTML navegável com sidebar de capítulos, dark theme, navegação por teclado, tipografia confortável.

## Quando usar
- Você dá aulas/lives e quer materializar como apostila
- Tem comunidade que precisa de material indexável
- Não quer hospedar em plataforma EAD travada
- Quer apostila versionável em Git

## Entregáveis
- Apostila HTML single-file
- Sidebar com índice clicável
- Navegação por setas
- Dark theme responsivo
- Deploy automático Cloudflare Pages

## Tags
educacao, conteudo, docs

## Passo-a-passo completo (LOCAL — fonte canônica)
O passo-a-passo detalhado completo (etapas + código) está em **`./reference.md`** (nesta skill).
LER `reference.md` antes de executar este método.

