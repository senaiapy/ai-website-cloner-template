# Prompt · incluir os módulos opcionais

Cole no Claude Code, na raiz do repositório do ERP já construído com o pacote 1, depois de descompactar este pacote ali.

---

Aciona a skill `incluir-modulo-erp` (está em `.claude/skills/`). Este repositório é o ERP modular cuja fase 1 já está no ar. Quero incluir módulos opcionais das specs em `specs/modulos-opcionais/`.

## O que fazer

1. Estude o sistema antes de perguntar: `docs/LOOP-STATE.md`, `docs/CONTRATOS.md`, `docs/OWNERSHIP.md`, `specs/modulos.json` (inclusive `opcionais_desejados`), a receita `model-modulo-erp`, a tabela `modulos`, a pasta `modules/` e o `/health` em produção. Confirme que as provas P1 a P13 da fase 1 estão verdes; se não estiverem, pare e me diga qual falta.
2. Leia as 14 specs e me mostre uma tabela com: módulo, já existe (sim ou não), dependências, dependências que faltam no sistema, menu de destino.
3. Faça UMA pergunta com duas opções:
   - **A · Escolher módulos:** eu digo quais quero. Dependência ausente entra no ciclo antes do módulo, com aviso.
   - **B · Instalar todos:** você constrói todos os opcionais que ainda não existem, em ondas pela ordem das dependências (incluindo módulos padrão que a fase 1 deixou de fora e algum opcional precisa).
4. Backup antes do primeiro build: dump do banco fora da árvore, tag `pre-modulo-YYYYMMDD` empurrada, lista de regressão dos módulos vizinhos e comando de rollback no LOOP-STATE.
5. Construa cada módulo pela spec dele e pela receita do sistema, um agente por módulo dentro da onda.
6. Review em quatro lentes por onda (spec, segurança adversarial entre tenants, visual, robustez) e lista de regressão verde.
7. Deploy por SHA de uma cópia limpa, canário e rolling, ao fim de cada onda. Instale os módulos pelo painel admin no tenant que eu indicar e prove de fora.
8. Atualize `specs/modulos.json`, `docs/CONTRATOS.md`, `docs/OWNERSHIP.md` e `docs/LOOP-STATE.md`. Commit e push.

## Regras

- Não altere módulos existentes além do ponto de encaixe declarado na spec.
- Não mude o núcleo sem me avisar antes, em uma linha, com o motivo.
- Zero gradiente, zero emoji, zero travessão; cor só por token; sidebar sem submenus.
- "Concluído" só com o módulo instalado no tenant e verificado de fora.

Comece pelo passo 1 e só me pergunte o que está no passo 3.
