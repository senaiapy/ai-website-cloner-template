# Módulo opcional: Documentos e assinatura

- Slug: `documentos`
- Menu principal: Cadastros
- Abas na página: Arquivos, Contratos, Assinaturas
- Depende de: cadastros
- Sidebar: não ganha item novo; entra como aba dentro de Cadastros. Se o menu Cadastros ainda não existir no tenant, o módulo cria o item principal.

## Escopo

Repositório de arquivos ligado a qualquer registro (cliente, projeto, funcionário, pedido), modelos de contrato com variáveis preenchidas do cadastro, envio para assinatura eletrônica com trilha de auditoria e download do documento assinado.

## Agregados e entidades

- Documento (raiz): registro_tipo, registro_id, nome, arquivo_url, versao, tags
- ModeloContrato: nome, corpo com variaveis
- Assinatura (raiz): documento, signatarios[], estado (rascunho, enviado, assinado, recusado), trilha[]

Toda tabela com `tenant_id`, `workspace_id`, `creator_id`, `created_at`, `updated_at`, `deleted_at`, RLS e chave composta. Prefixo de tabela `documentos_`.

## Casos de uso

- AnexarDocumento
- GerarContratoDeModelo
- EnviarParaAssinatura (job)
- RegistrarAssinatura (webhook do provedor)

Comando devolve void e passa por caso de uso; consulta devolve DTO. Entidade e objeto de valor com `create` e `tryCreate`. Result em vez de exceção. Trabalho lento (envio, geração de documento, job recorrente) vai pra fila com outbox.

## Rotas

`/api/v1/documentos/...` descritas em OpenAPI antes do código: uma rota por caso de uso, listagens paginadas com filtro e ordenação, e a interface publicada que outros módulos consomem.

## Interfaces com outros módulos

- Storage do nucleo com bucket por tenant
- Conversas ou e-mail: envio do link
- Portal do cliente: assinatura pelo cliente

Só por interface publicada, nunca por import interno.

## Permissões

`documentos.ver`, `documentos.criar`, `documentos.editar`, `documentos.excluir`, `documentos.aprovar` quando houver aprovação, `documentos.configurar`. Geradas na instalação e ligadas aos papéis existentes conforme a entrevista.

## Telas

Padrão visual do sistema: kicker, título, botão primário rosa, abas na página, cards e tabelas com estados vazio, carregando e erro, mobile sem scroll horizontal, i18n pt, en e es.

## Seeds e dados demo

Registros plausíveis com a marca demo do tenant, suficientes pra demonstrar cada aba.

## Provas exigidas

- Teste de cada caso de uso com repositório em memória.
- Arquivo `.http` com todas as rotas e resposta esperada.
- Screenshot Playwright de cada aba.
- Tentativa de ler registro deste módulo de outro tenant devolvendo 404.
- Instalar e desinstalar pelo painel admin sem erro, com bloqueio quando há dependente.
