# Módulo opcional: Manutenção

- Slug: `manutencao`
- Menu principal: Operação
- Abas na página: Equipamentos, Pedidos, Preventivas, Equipes
- Depende de: núcleo apenas
- Sidebar: não ganha item novo; entra como aba dentro de Operação. Se o menu Operação ainda não existir no tenant, o módulo cria o item principal.

## Escopo

Cadastro de equipamentos com localização e responsável, pedidos de manutenção corretiva com prioridade e estado, planos preventivos com recorrência gerando pedidos automaticamente, equipes de manutenção.

## Agregados e entidades

- Equipamento (raiz): nome, codigo, categoria, local, responsavel, data_compra, garantia
- PedidoManutencao (raiz): equipamento, tipo (corretiva, preventiva), prioridade, descricao, equipe, estado (novo, em_andamento, concluido, cancelado), custo
- PlanoPreventivo: equipamento, recorrencia, checklist

Toda tabela com `tenant_id`, `workspace_id`, `creator_id`, `created_at`, `updated_at`, `deleted_at`, RLS e chave composta. Prefixo de tabela `manutencao_`.

## Casos de uso

- AbrirPedido
- AtribuirEquipe
- ConcluirPedido
- GerarPreventivas (job recorrente)

Comando devolve void e passa por caso de uso; consulta devolve DTO. Entidade e objeto de valor com `create` e `tryCreate`. Result em vez de exceção. Trabalho lento (envio, geração de documento, job recorrente) vai pra fila com outbox.

## Rotas

`/api/v1/manutencao/...` descritas em OpenAPI antes do código: uma rota por caso de uso, listagens paginadas com filtro e ordenação, e a interface publicada que outros módulos consomem.

## Interfaces com outros módulos

- Agenda: preventiva vira compromisso
- Financeiro: custo do pedido vira saida

Só por interface publicada, nunca por import interno.

## Permissões

`manutencao.ver`, `manutencao.criar`, `manutencao.editar`, `manutencao.excluir`, `manutencao.aprovar` quando houver aprovação, `manutencao.configurar`. Geradas na instalação e ligadas aos papéis existentes conforme a entrevista.

## Telas

Padrão visual do sistema: kicker, título, botão primário rosa, abas na página, cards e tabelas com estados vazio, carregando e erro, mobile sem scroll horizontal, i18n pt, en e es.

## Seeds e dados demo

Registros plausíveis com a marca demo do tenant, suficientes pra demonstrar cada aba.

## Provas exigidas

- Teste de cada caso de uso com repositório em memória.
- Arquivo `.http` com todas as rotas e resposta esperada.
- Screenshot Playwright de cada aba.
- Tentativa de ler registro deste módulo de outro tenant devolvendo 404.
- Instalar e desinstalar pelo painel admin sem erro, com bloqueio quando há dependente.
