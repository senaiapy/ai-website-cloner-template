---
name: youtube-thumbnail
description: >
  Gera uma thumbnail de YouTube com a marca do dono a partir do título de um vídeo. Usa uma foto de referência do dono, princípios de thumbnail com alto CTR e as cores da marca para produzir um prompt de imagem pronto pra gerar no Gemini. Use esta skill sempre que o dono pedir "thumbnail", "thumbnail de youtube", "monta uma thumbnail pra mim", ou quiser uma capa de vídeo antes de escrever o roteiro. O fluxo de thumbnail primeiro espelha a abordagem de criar o visual antes do conteúdo: vende o vídeo antes de alguém ouvir uma palavra do roteiro.
---

# Thumbnail de YouTube

## CRÍTICO: Começa sozinha ao carregar

Quando esta skill for acionada, vá direto pro Passo 1.

## Passo 1. Reúna os dados de entrada

Procure no projeto uma configuração de foto de referência. Olhe nesta ordem:

1. `thumbnail-config.md` na raiz do projeto
2. `brand-kit.md`, procure por um caminho de imagem de referência e pelas cores da marca
3. `about-me.md`, pelo nome do dono e seu posicionamento

Se houver um caminho de foto de referência salvo, já preencha. Se não, pergunte:

> Envie ou passe o caminho da foto de referência sua que você quer usar na thumbnail. O ideal é uma foto nítida do rosto, com iluminação e expressão marcantes que você pretende reaproveitar em vários vídeos pra manter a marca consistente.

Depois chame o AskUserQuestion:

```json
[
  {
    "question": "Qual é o título do vídeo?",
    "header": "Título",
    "multiSelect": false,
    "options": [
      {"label": "Eu vou digitar o título", "description": "Digite o título completo de trabalho"},
      {"label": "Sugira um", "description": "Dado o tema, proponha primeiro 3 títulos chamativos"}
    ]
  },
  {
    "question": "Tom emocional?",
    "header": "Tom",
    "multiSelect": false,
    "options": [
      {"label": "Choque / surpresa", "description": "Olhos arregalados, boca aberta, reação forte"},
      {"label": "Curioso / pensativo", "description": "Sorriso de canto, sobrancelha levantada, olhar fora do quadro"},
      {"label": "Confiante / direto", "description": "Olhar na câmera, calmo, assertivo"},
      {"label": "Irritado / opinião forte", "description": "Olhar intenso, gesto com a mão, tensão"}
    ]
  }
]
```

## Passo 2. Aplique as boas práticas de thumbnail

Toda thumbnail tem que seguir estas regras:

- **O rosto ocupa de 30 a 50 por cento** do quadro. Legível em tamanhos pequenos.
- **No máximo 3 a 5 palavras** de texto grande. 6 só se for absolutamente necessário.
- **Duas cores dominam**. A cor primária da marca + uma cor de destaque de alto contraste (amarelo, vermelho e ciano funcionam bem).
- **Um elemento focal claro** além do rosto. Logo de uma ferramenta, número grande, seta ou objeto.
- **Alto contraste** entre rosto, texto e fundo. Teste apertando os olhos.
- **O texto não é uma frase**. É uma frase de gancho. Exemplos: "Demiti meu time", "A IA agora consegue...", "Não faça isso".
- **Sem texto pequeno, sem logos no canto inferior direito** (o ícone de tempo de exibição fica ali).

## Passo 3. Monte o briefing da thumbnail

Entregue um briefing enxuto que o dono possa revisar:

```
BRIEFING DA THUMBNAIL: [título do vídeo]

Composição: [posição do rosto, % do quadro, direção do olhar]
Texto: "[frase de gancho, 3 a 5 palavras]"
Posição do texto: [esquerda, direita, topo, contorna o rosto]
Paleta de cores: [hex primário], [hex de destaque], [hex de fundo]
Elemento de apoio: [logo / objeto / seta / número]
Tom emocional: [tom do Passo 1]
```

Depois pergunte:

> Aqui está o briefing. Diga "gerar" pra eu soltar o prompt da imagem ou me diga o que mudar.

## Passo 4. Solte o prompt do Gemini

Depois de aprovado, entregue o prompt de geração de imagem num bloco de código:

```
Usando a foto de referência minha em anexo, gere uma thumbnail de YouTube em 1280 x 720 pixels (16:9).

Composição:
- Me posicione [à esquerda / à direita / ao centro] ocupando [30-50]% do quadro
- Minha expressão: [detalhes do tom, ex.: chocado com olhos arregalados e boca aberta]
- Meu olhar: [direção, ex.: olhando direto pra câmera / olhando pra fora do quadro na direção do texto]

Texto:
- Mostre "[frase de gancho]" em tipografia sem serifa, grande e em negrito
- Cor do texto: [hex]
- Contorno do texto: [cor, espessura pra legibilidade]
- Posição do texto: [área específica]

Paleta de cores:
- Primária: [hex]
- Destaque: [hex]
- Fundo: [hex], [descreva o tratamento: chapado, gradiente, cena desfocada, etc.]

Elemento de apoio: [descrição específica do visual de apoio]

Restrições:
- O rosto tem que estar nítido e bem definido
- O texto tem que ser legível com 320px de largura (tamanho mobile do YouTube)
- Sem marca d'água, sem elementos de interface do YouTube, sem texto no canto inferior direito
- Alto contraste entre rosto, texto e fundo
```

Diga pro dono:

> Cole isso num chat novo do Gemini, anexe sua foto de referência, ative o Criar Imagem e selecione o Nano Banana. Gere em 1280x720.

## Passo 5. Ofereça o próximo passo

> Quer que eu esboce o vídeo agora? Gancho, meio e CTA a partir da thumbnail. Ou chame a skill de criação, se você tiver uma.

## Regras

- 1280x720 pixels (16:9). É o tamanho nativo de thumbnail do YouTube.
- Nunca inclua o caminho da foto de referência dentro do próprio prompt, o dono anexa a foto separadamente.
- Nunca permita mais de 6 palavras de texto, 5 é o ideal, 3 é o melhor.
- O rosto sempre tem que ser um ponto focal visível. Nada de composições com o rosto escondido.
- Nunca use travessões.
- Português do Brasil, a não ser que o voice.md especifique outra coisa.
- Se houver um brand-kit.md no projeto, leia e use as cores exatas da marca.
- Recomende ao dono manter um estilo de thumbnail consistente entre os vídeos pra reconhecimento do canal.
