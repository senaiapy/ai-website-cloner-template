# Módulo opcional: Contabilidade

- Slug: `contabilidade`
- Menu principal: Financeiro
- Abas na página: Plano de contas, Diários, Lançamentos, Impostos, Fechamento, Relatórios
- Depende de: financeiro, contas
- Sidebar: não ganha item novo; entra como aba dentro de Financeiro. Se o menu Financeiro ainda não existir no tenant, o módulo cria o item principal.

## Escopo

Plano de contas por tenant, diários (vendas, compras, banco, caixa), lançamentos de partida dobrada gerados dos documentos financeiros, impostos por alíquota, fechamento de período e relatórios (balancete, DRE, razão).

## Agregados e entidades

- Conta contabil: codigo, nome, tipo, pai
- Diario: nome, tipo, conta_padrao
- Lancamento (raiz): diario, data, linhas[] (conta, debito, credito), origem (documento), estado (rascunho, lancado, cancelado)
- Imposto: nome, aliquota, conta

Toda tabela com `tenant_id`, `workspace_id`, `creator_id`, `created_at`, `updated_at`, `deleted_at`, RLS e chave composta. Prefixo de tabela `contabilidade_`.

## Casos de uso

- LancarDocumento (a partir de fatura, pagamento ou lancamento financeiro)
- EstornarLancamento
- FecharPeriodo
- GerarBalancete
- GerarDRE

Comando devolve void e passa por caso de uso; consulta devolve DTO. Entidade e objeto de valor com `create` e `tryCreate`. Result em vez de exceção. Trabalho lento (envio, geração de documento, job recorrente) vai pra fila com outbox.

## Rotas

`/api/v1/contabilidade/...` descritas em OpenAPI antes do código: uma rota por caso de uso, listagens paginadas com filtro e ordenação, e a interface publicada que outros módulos consomem.

## Interfaces com outros módulos

- Financeiro e Contas: origem dos lancamentos
- Beneficios e folha: lancamento da folha

Só por interface publicada, nunca por import interno.

## Permissões

`contabilidade.ver`, `contabilidade.criar`, `contabilidade.editar`, `contabilidade.excluir`, `contabilidade.aprovar` quando houver aprovação, `contabilidade.configurar`. Geradas na instalação e ligadas aos papéis existentes conforme a entrevista.

## Telas

Padrão visual do sistema: kicker, título, botão primário rosa, abas na página, cards e tabelas com estados vazio, carregando e erro, mobile sem scroll horizontal, i18n pt, en e es.

## Seeds e dados demo

Registros plausíveis com a marca demo do tenant, suficientes pra demonstrar cada aba.

## Provas exigidas

- Teste de cada caso de uso com repositório em memória.
- Arquivo `.http` com todas as rotas e resposta esperada.
- Screenshot Playwright de cada aba.
- Tentativa de ler registro deste módulo de outro tenant devolvendo 404.
- Instalar e desinstalar pelo painel admin sem erro, com bloqueio quando há dependente.
