# Módulo opcional: Tickets e helpdesk

- Slug: `tickets`
- Menu principal: Comercial
- Abas na página: Tickets, Filas, SLA, Base de conhecimento
- Depende de: cadastros
- Sidebar: não ganha item novo; entra como aba dentro de Comercial. Se o menu Comercial ainda não existir no tenant, o módulo cria o item principal.

## Escopo

Ticket por cliente aberto por conversa, e-mail ou formulário, com fila, prioridade, SLA de primeira resposta e resolução, atribuição, comentários internos e públicos, base de conhecimento com artigos.

## Agregados e entidades

- Ticket (raiz): numero por sequencia TK-, cliente, assunto, fila, prioridade, responsavel, estado (aberto, em_atendimento, aguardando, resolvido, fechado), sla_primeira_resposta, sla_resolucao, comentarios[]
- Fila: nome, equipe, sla_padrao
- Artigo: titulo, corpo, categoria, publicado

Toda tabela com `tenant_id`, `workspace_id`, `creator_id`, `created_at`, `updated_at`, `deleted_at`, RLS e chave composta. Prefixo de tabela `tickets_`.

## Casos de uso

- AbrirTicket (manual, webhook, conversa)
- AtribuirTicket
- ResponderTicket (envio pela fila para WhatsApp, Instagram ou e-mail)
- ResolverTicket
- EscalarSLA (job)

Comando devolve void e passa por caso de uso; consulta devolve DTO. Entidade e objeto de valor com `create` e `tryCreate`. Result em vez de exceção. Trabalho lento (envio, geração de documento, job recorrente) vai pra fila com outbox.

## Rotas

`/api/v1/tickets/...` descritas em OpenAPI antes do código: uma rota por caso de uso, listagens paginadas com filtro e ordenação, e a interface publicada que outros módulos consomem.

## Interfaces com outros módulos

- Conversas: ticket a partir da conversa
- Cadastros: cliente
- Portal do cliente: abertura e acompanhamento

Só por interface publicada, nunca por import interno.

## Permissões

`tickets.ver`, `tickets.criar`, `tickets.editar`, `tickets.excluir`, `tickets.aprovar` quando houver aprovação, `tickets.configurar`. Geradas na instalação e ligadas aos papéis existentes conforme a entrevista.

## Telas

Padrão visual do sistema: kicker, título, botão primário rosa, abas na página, cards e tabelas com estados vazio, carregando e erro, mobile sem scroll horizontal, i18n pt, en e es.

## Seeds e dados demo

Registros plausíveis com a marca demo do tenant, suficientes pra demonstrar cada aba.

## Provas exigidas

- Teste de cada caso de uso com repositório em memória.
- Arquivo `.http` com todas as rotas e resposta esperada.
- Screenshot Playwright de cada aba.
- Tentativa de ler registro deste módulo de outro tenant devolvendo 404.
- Instalar e desinstalar pelo painel admin sem erro, com bloqueio quando há dependente.
