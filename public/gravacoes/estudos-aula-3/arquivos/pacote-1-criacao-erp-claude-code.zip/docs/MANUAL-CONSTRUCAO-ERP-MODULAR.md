# Manual de construção de um ERP modular

Um sistema, muitos nichos. Este manual descreve, camada por camada, com nomenclatura técnica, como construir um ERP que serve clínica, escritório, restaurante ou loja com o mesmo núcleo. O que muda de um cliente para outro são os módulos ligados, nunca o código base.

Ele nasce de três fontes: a arquitetura de sistemas Avalanche (destilada da infra de borda da Atlassian), o desenho de plugins do Aureus ERP (Laravel, 27 plugins com dependência declarada) e a organização interna de código do curso Arquitetura de Software com IA (entidade, objeto de valor, caso de uso, repositório por porta). O stack de referência é o do Feed Growly: Node com Fastify, React com Vite, PostgreSQL, Redis com BullMQ, Caddy.

## 1. As nove camadas

| Camada | O que é | Por que existe |
|---|---|---|
| VPS, systemd e infra como código | VPS Linux, systemd, infra como código, imagem imutável | Toda máquina nasce igual e reinicia sozinha |
| PostgreSQL, pgvector e RLS | PostgreSQL com RLS por tenant, pgvector, migrations, backup | Única fonte de verdade, sobrevive a bug e reinício |
| API Fastify, núcleo e módulos | API Fastify com contrato OpenAPI, núcleo e módulos plugáveis | Sustenta os módulos sem que um dependa do código do outro |
| Redis, BullMQ, outbox e worker | Redis, fila BullMQ, worker, outbox | Separa o rápido do lento, a tela nunca trava |
| Caddy, Cloudflare, sessão e RBAC | Caddy, Cloudflare, sessão, permissões, rate limit | Segurança resolvida uma vez, na borda |
| Webhooks e integrações | Webhooks e integrações (WhatsApp, Instagram, Google Calendar, players, cobrança) | Liga o sistema ao mundo pela fila |
| Módulos de negócio | Os módulos de negócio | Cada cliente liga só o que usa |
| React, Vite, design system e i18n | React, tokens em oklch, dois temas, i18n | Uma cara só para todos os módulos |
| DNS, HTTPS, health check, deploy e backup | Domínio, HTTPS, health, logs, deploy com canário, backup | O sistema de pé, observável e atualizável sem queda |

## 2. Topologia: 1 VPS ou load balancer

**Topologia 1, uso próprio.** Uma VPS com API, worker, Redis e PostgreSQL. Caddy na frente. Backup diário para fora da máquina.

**Topologia 2, revenda.** No mínimo duas VPS de aplicação (API e worker em cada), load balancer distribuindo com health check. PostgreSQL numa máquina própria, com réplica de leitura quando apertar. Redis separado. Worker escalando pelo tamanho da fila. Multi-tenant por linha: cada cliente é um tenant, cada unidade um workspace, créditos e plano por workspace.

O mesmo código roda nas duas topologias. Comece na topologia 1 e migre sem reescrever, porque cada peça já nasceu separada.

## 3. VPS, systemd e infra como código

- VPS Linux. Cada serviço (api, worker, caddy) é uma unidade systemd com `Restart=always`.
- Serviços em porta alta, escutando só em `127.0.0.1`. Só o Caddy fala com a internet.
- Infra declarada em arquivo: usuários de sistema, pastas, permissões, unidades, timers. Uma máquina nova sobe do mesmo script e fica idêntica.
- Segredos fora do código, injetados em runtime a partir do cofre (1Password ou equivalente). `.env` com permissão 600.
- Deploy sempre de uma cópia limpa por SHA, nunca do diretório de trabalho.

## 4. PostgreSQL, pgvector e RLS

- PostgreSQL 16 ou superior. Migrations numeradas no repositório, uma por mudança, idempotentes.
- Toda tabela de dado leva `tenant_id` e `workspace_id` obrigatórios, preenchidos por default a partir do contexto da sessão.
- Row Level Security em toda tabela. Chave estrangeira composta `(id, tenant_id, workspace_id)` para que um registro nunca aponte para outro de fora do seu workspace.
- `tenant_id` imutável por trigger. Criação de tenant e promoção a dono só por função `SECURITY DEFINER`.
- pgvector na mesma instância para busca por significado (memória do workspace, fórmulas parecidas).
- Soft delete (`deleted_at`), `created_at`, `updated_at`, `creator_id` em toda tabela.
- Backup diário por timer, guardado fora do servidor, restauração testada.

## 5. API Fastify, núcleo e módulos

**Contrato primeiro.** Cada rota é descrita em OpenAPI antes do código. O framework é trocável, o contrato fica.

**Núcleo (sempre instalado):** usuários, papéis e permissões, tenants, workspaces, empresas, sequências de numeração, configurações, campos personalizados, auditoria, fila e outbox.

**Módulo:** um pacote com rotas, migrations, telas, permissões, seeds e testes. O módulo declara de quem depende. Instalar puxa as dependências antes, roda as migrations, gera as permissões e grava na tabela `modulos`. Desinstalar é bloqueado enquanto outro módulo instalado depende dele. Um módulo nunca importa o código interno de outro: conversa por interface publicada (consultas e DTOs expostos de propósito).

**Dentro do módulo (organização por agregado):**

```
modules/<modulo>/
  src/<agregado>/
    model/        entidade, objetos de valor, DTO, porta do repositório
    use-case/     um arquivo por caso de uso (execute(entrada) -> Result<saida>)
    query/        consultas de leitura, podem ser SQL direto, devolvem DTO
    adapter/      implementação do repositório (Postgres)
    routes.ts     rotas Fastify que chamam os casos de uso
  migrations/
  seeds/
  permissions.ts
  module.json     nome, versão, depende_de[]
  tests/
```

- Regra de negócio mora primeiro no objeto de valor, depois na entidade, depois no serviço de domínio.
- Toda entidade e objeto de valor têm `create` (lança) e `tryCreate` (devolve Result). Alteração gera clone, nunca muta.
- Padrão Result: `ok`, `fail`, lista de erros com código e metadados. Erro é valor, não exceção.
- Comando escreve via caso de uso e devolve void; consulta lê direto e devolve DTO.
- Repositório com interfaces segregadas por operação.

## 6. Redis, BullMQ, outbox e worker

- Redis guarda as filas do BullMQ. Rápido, em memória, não é fonte de verdade.
- Antes de ir para o Redis, a intenção do job é gravada numa tabela outbox no Postgres, na mesma transação do pedido. Um despachante reenvia o que ficou pendente.
- Worker em processo separado, concorrência por tipo de job, lock longo para job demorado, retry com backoff.
- Tudo que é lento vai para a fila: relatório, envio de mensagem, sincronização de agenda, cobrança, fechamento de folha, importação.
- Job grava status no banco. A tela consulta o status até ficar pronto.
- Job idempotente: rodar duas vezes não duplica cobrança nem envio.

## 7. Caddy, Cloudflare, sessão e RBAC

- Cloudflare na frente contra DDoS. Caddy recebe HTTPS e repassa para a API local.
- Sessão por cookie assinado, com tenant e workspace amarrados. O escopo vem sempre da sessão, nunca de header ou parâmetro do cliente.
- Papéis e permissões por módulo, geradas na instalação do módulo. Uma policy por recurso.
- Rate limit por rota sensível: login, cadastro, webhook, recuperação de senha. Bloqueio progressivo por credencial.
- Login é a única rota pública. Todo o resto atrás do gate de sessão.
- IA nunca no client: proxy server-side valida a sessão e só então chama o modelo com a chave do servidor.

## 8. Integrações: conectores, webhooks, API e MCP

Módulo padrão com menu próprio e abas Conectores, Webhooks, API e MCP. O ERP expõe a mesma API do frontend com chave por workspace e escopo por módulo, e um servidor MCP nativo em `/mcp` com tools geradas por módulo instalado, para agentes como Claude Code, OpenClaw e Hermes operarem o sistema. Especificação completa e snippets de conexão em `INTEGRACOES-API-MCP.md`.

- Cada integração é um módulo isolado que entra e sai sem tocar no núcleo.
- Toda entrada por webhook valida assinatura, grava o evento e vira job. Nada roda direto na request.
- Webhook de formulário de landing page cria cliente e abre oportunidade.
- WhatsApp oficial (Cloud API) e Direct do Instagram (Messenger Platform) espelhados na tela de conversas. Envio pela fila.
- Google Calendar via Maton ou API direta, sincronização nos dois sentidos.
- Players externos de vídeo: YouTube, Vimeo, Panda e Bunny. O sistema guarda o id do vídeo, nunca o arquivo.
- Cobrança (Pix, boleto, cartão) pelo módulo financeiro.

## 9. Módulos: catálogo e entrevista

A lista completa vive em `CATALOGO-MODULOS.md`: 14 módulos padrão (Cadastros, Pipeline, Conversas, Financeiro, Contas a receber e a pagar, Agenda, Pessoas, Benefícios e folha, Estoque, Compras, Treinamento, Painel admin, Configurações, Integrações), cada um com as abas enriquecidas pelo que o Aureus ERP tem no plugin equivalente, e 14 opcionais (Vendas, Projetos e tarefas, Apontamento de horas, Recrutamento, Férias e ausências, Contabilidade, Fabricação, Manutenção, Tickets e helpdesk, Ponto de venda, Assinaturas e recorrência, Despesas e reembolso, Documentos e assinatura, Portal do cliente), com dependências e perfis sugeridos por nicho.

Na instalação, o agente entrevista o dono grupo por grupo, valida as dependências e grava `specs/modulos.json`. O painel admin permite instalar e desinstalar qualquer módulo do catálogo depois, por tenant.

## 10. React, Vite, design system e i18n

- React com Vite, uma pasta por módulo espelhando o backend. Componentes burros que consomem hooks.
- Toda cor é `var(--token)` em oklch. Tema claro e escuro aplicados no `<html>` antes do paint.
- Bricolage Grotesque na interface, JetBrains Mono em números e kickers. Fontes hospedadas junto do app.
- Sidebar só com os menus principais, gerada de um array e filtrada por permissão; os submenus de cada seção são abas dentro da página.
- Zero gradiente, zero emoji, ícone SVG de linha (Lucide). Zero travessão em texto de tela.
- Português, inglês e espanhol trocando ao vivo, dicionário com chaves por área.
- Login em duas colunas, única rota pública. Onboarding no primeiro login com tour de holofote.

## 11. DNS, HTTPS, health check, deploy e backup

- Subdomínio no Cloudflare apontando para o Caddy, HTTPS automático.
- `/health` responde versão, banco e fila. `/health/ready` tira a réplica doente do rodízio.
- Logs estruturados, alerta quando o worker para ou a fila cresce.
- Deploy por SHA de uma cópia limpa, canário primeiro, depois rolling nas réplicas. Rollback em um comando.
- Backup do banco por timer, fora do servidor. Repositório privado igual à produção, caça de segredos antes de cada push.

## 12. Ordem de construção

1. Spec: entrevista até a definição de concluído ser testável.
2. Arquitetura: o prédio conferido no checklist de dez passos.
3. Build: esqueleto de ponta a ponta primeiro (repo, serviço, Caddy, banco migrado, login, uma tela, curl 200 no domínio). Depois o núcleo à mão, com cuidado. Depois um agente por módulo, cada um na sua zona, com prova executável.
4. Review: spec, segurança adversarial (tentar vazar dado entre tenants), visual, robustez. Duas rodadas limpas quando envolve dinheiro ou dado.
5. Entrega: login real, telas navegadas, query no banco, probe externo, repositório igual à produção, credenciais no cofre.

Construa o núcleo à mão, vire receita (skill), e cada módulo novo é "faça igual ao anterior" com a IA executando e você conferindo.
