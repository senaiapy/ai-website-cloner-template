# Módulo opcional: Férias e ausências

- Slug: `ferias-ausencias`
- Menu principal: Pessoas
- Abas na página: Tipos, Saldos, Pedidos, Aprovações, Calendário
- Depende de: pessoas
- Sidebar: não ganha item novo; entra como aba dentro de Pessoas. Se o menu Pessoas ainda não existir no tenant, o módulo cria o item principal.

## Escopo

Tipos de ausência (férias, atestado, folga, licença) com regra de saldo, pedido pelo funcionário, aprovação pelo gestor, calendário da equipe e integração com a folha.

## Agregados e entidades

- TipoAusencia: nome, remunerada, saldo_anual, exige_aprovacao
- Pedido (raiz): funcionario, tipo, inicio, fim, dias, estado (pedido, aprovado, recusado, cancelado), aprovador
- Saldo: funcionario, tipo, ano, direito, usado

Toda tabela com `tenant_id`, `workspace_id`, `creator_id`, `created_at`, `updated_at`, `deleted_at`, RLS e chave composta. Prefixo de tabela `ferias_ausencias_`.

## Casos de uso

- PedirAusencia
- AprovarPedido
- RecusarPedido
- CalcularSaldo
- ExportarParaFolha

Comando devolve void e passa por caso de uso; consulta devolve DTO. Entidade e objeto de valor com `create` e `tryCreate`. Result em vez de exceção. Trabalho lento (envio, geração de documento, job recorrente) vai pra fila com outbox.

## Rotas

`/api/v1/ferias-ausencias/...` descritas em OpenAPI antes do código: uma rota por caso de uso, listagens paginadas com filtro e ordenação, e a interface publicada que outros módulos consomem.

## Interfaces com outros módulos

- Pessoas: funcionario e gestor
- Beneficios e folha: desconto ou provento
- Agenda: bloqueio do calendario

Só por interface publicada, nunca por import interno.

## Permissões

`ferias-ausencias.ver`, `ferias-ausencias.criar`, `ferias-ausencias.editar`, `ferias-ausencias.excluir`, `ferias-ausencias.aprovar` quando houver aprovação, `ferias-ausencias.configurar`. Geradas na instalação e ligadas aos papéis existentes conforme a entrevista.

## Telas

Padrão visual do sistema: kicker, título, botão primário rosa, abas na página, cards e tabelas com estados vazio, carregando e erro, mobile sem scroll horizontal, i18n pt, en e es.

## Seeds e dados demo

Registros plausíveis com a marca demo do tenant, suficientes pra demonstrar cada aba.

## Provas exigidas

- Teste de cada caso de uso com repositório em memória.
- Arquivo `.http` com todas as rotas e resposta esperada.
- Screenshot Playwright de cada aba.
- Tentativa de ler registro deste módulo de outro tenant devolvendo 404.
- Instalar e desinstalar pelo painel admin sem erro, com bloqueio quando há dependente.
