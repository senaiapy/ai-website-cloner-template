---
name: metodo-analise-bmad-instagram
description: Pipeline 10 etapas BMAD pra analisar perfil Instagram de um cliente e gerar plano de crescimento de 30 dias. Scraping dos últimos 60 posts, análise temática, gaps de conteúdo, calendário diário, métricas de meta. Metodologia o padrão. Use quando o dono pedir esse tipo de tarefa.
---

# Análise BMAD de Instagram + Plano 30 dias

> Metodologia o padrão #5/11. Tarefa operacional: a Naia delega (Juliana coordena), valida e entrega pro dono.

Pipeline 10 etapas BMAD pra analisar perfil Instagram de um cliente e gerar plano de crescimento de 30 dias. Scraping dos últimos 60 posts, análise temática, gaps de conteúdo, calendário diário, métricas de meta.

## Quando usar
- Cliente quer crescer no Instagram em 30 dias
- Você presta consultoria de conteúdo
- Aluno precisa de plano executável
- Lançamento depende de pré-aquecimento

## Entregáveis
- Análise BMAD em PDF/HTML
- Calendário 30 dias de posts
- Sugestões de retemas
- Métricas de meta
- Acompanhamento semanal

## Tags
instagram, auditoria, bmad

## Passo-a-passo completo (LOCAL — fonte canônica)
O passo-a-passo detalhado completo (etapas + código) está em **`./reference.md`** (nesta skill).
LER `reference.md` antes de executar este método.

