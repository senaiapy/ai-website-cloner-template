---
name: metodo-criacao-propostas
description: Pipeline completo em 7 etapas pra transformar uma call de venda em um site de proposta comercial em HTML estático, hospedado em subdomínio único do cliente. Cada proposta vira um link próprio, com layout premium, abas, simuladores e CTA persistente. Metodologia o padrão. Use quando o dono pedir esse tipo de tarefa.
---

# Criação de Propostas Comerciais em HTML

> Metodologia o padrão #1/11. Tarefa operacional: a Naia delega (Juliana coordena), valida e entrega pro dono.

Pipeline completo em 7 etapas pra transformar uma call de venda em um site de proposta comercial em HTML estático, hospedado em subdomínio único do cliente. Cada proposta vira um link próprio, com layout premium, abas, simuladores e CTA persistente.

## Quando usar
- Você fechou uma call e precisa entregar a proposta em formato premium
- Quer que cada cliente receba um link único (cliente.seudominio.com)
- Quer fugir do PDF travado
- Quer dashboard interno pra trackear pipeline

## Entregáveis
- Site HTML estático single-file (layout escuro/claro)
- Subdomínio próprio via DNS Cloudflare
- Deploy automático Vercel
- Dashboard interno de pipeline
- Métricas de conversão por proposta

## Tags
vendas, html, vercel

## Passo-a-passo completo (LOCAL — fonte canônica)
O passo-a-passo detalhado completo (etapas + código) está em **`./reference.md`** (nesta skill).
LER `reference.md` antes de executar este método.

