# Módulo opcional: Vendas

- Slug: `vendas`
- Menu principal: Comercial
- Abas na página: Orçamentos, Pedidos, Entregas, Faturar
- Depende de: cadastros, estoque, contas
- Sidebar: não ganha item novo; entra como aba dentro de Comercial. Se o menu Comercial ainda não existir no tenant, o módulo cria o item principal.

## Escopo

Orçamento e pedido de venda no mesmo registro, diferenciados por estado (rascunho, enviado, venda, cancelado). Linhas de produto com quantidade, preço, desconto e imposto. Entrega parcial e total baixando estoque. Fatura gerada do pedido em contas a receber. Equipes de venda e metas.

## Agregados e entidades

- Pedido (raiz): numero por sequencia SO-, cliente, equipe, condicao de pagamento, estado, linhas
- LinhaPedido: produto, quantidade, preco_unitario, desconto, imposto, quantidade_entregue, quantidade_faturada
- EquipeVendas: nome, lider, membros, meta_mensal

Toda tabela com `tenant_id`, `workspace_id`, `creator_id`, `created_at`, `updated_at`, `deleted_at`, RLS e chave composta. Prefixo de tabela `vendas_`.

## Casos de uso

- CriarOrcamento
- EnviarOrcamento
- ConfirmarPedido
- CancelarPedido
- RegistrarEntrega (baixa estoque via interface publicada de Estoque)
- FaturarPedido (cria documento em Contas a receber)

Comando devolve void e passa por caso de uso; consulta devolve DTO. Entidade e objeto de valor com `create` e `tryCreate`. Result em vez de exceção. Trabalho lento (envio, geração de documento, job recorrente) vai pra fila com outbox.

## Rotas

`/api/v1/vendas/...` descritas em OpenAPI antes do código: uma rota por caso de uso, listagens paginadas com filtro e ordenação, e a interface publicada que outros módulos consomem.

## Interfaces com outros módulos

- Pipeline: oportunidade ganha pode virar orcamento
- Estoque: consulta de saldo e baixa por movimentacao
- Contas a receber: criacao de fatura

Só por interface publicada, nunca por import interno.

## Permissões

`vendas.ver`, `vendas.criar`, `vendas.editar`, `vendas.excluir`, `vendas.aprovar` quando houver aprovação, `vendas.configurar`. Geradas na instalação e ligadas aos papéis existentes conforme a entrevista.

## Telas

Padrão visual do sistema: kicker, título, botão primário rosa, abas na página, cards e tabelas com estados vazio, carregando e erro, mobile sem scroll horizontal, i18n pt, en e es.

## Seeds e dados demo

Registros plausíveis com a marca demo do tenant, suficientes pra demonstrar cada aba.

## Provas exigidas

- Teste de cada caso de uso com repositório em memória.
- Arquivo `.http` com todas as rotas e resposta esperada.
- Screenshot Playwright de cada aba.
- Tentativa de ler registro deste módulo de outro tenant devolvendo 404.
- Instalar e desinstalar pelo painel admin sem erro, com bloqueio quando há dependente.
