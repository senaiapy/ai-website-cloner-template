# Módulo opcional: Assinaturas e recorrência

- Slug: `assinaturas`
- Menu principal: Financeiro
- Abas na página: Planos, Assinaturas, Renovações, Cancelamentos
- Depende de: contas
- Sidebar: não ganha item novo; entra como aba dentro de Financeiro. Se o menu Financeiro ainda não existir no tenant, o módulo cria o item principal.

## Escopo

Planos com preço e periodicidade, assinatura por cliente com data de renovação, geração automática da fatura recorrente em contas a receber, cobrança por Pix ou cartão, cancelamento e reativação, métricas de MRR e churn.

## Agregados e entidades

- Plano (raiz): nome, preco, periodicidade, itens[]
- Assinatura (raiz): cliente, plano, inicio, proxima_renovacao, estado (ativa, inadimplente, cancelada), forma_pagamento

Toda tabela com `tenant_id`, `workspace_id`, `creator_id`, `created_at`, `updated_at`, `deleted_at`, RLS e chave composta. Prefixo de tabela `assinaturas_`.

## Casos de uso

- CriarAssinatura
- RenovarAssinaturas (job diario: gera fatura)
- MarcarInadimplente
- CancelarAssinatura
- ReativarAssinatura

Comando devolve void e passa por caso de uso; consulta devolve DTO. Entidade e objeto de valor com `create` e `tryCreate`. Result em vez de exceção. Trabalho lento (envio, geração de documento, job recorrente) vai pra fila com outbox.

## Rotas

`/api/v1/assinaturas/...` descritas em OpenAPI antes do código: uma rota por caso de uso, listagens paginadas com filtro e ordenação, e a interface publicada que outros módulos consomem.

## Interfaces com outros módulos

- Contas a receber: fatura recorrente
- Conversas ou e-mail: aviso de renovacao e inadimplencia
- Portal do cliente: gestao da assinatura

Só por interface publicada, nunca por import interno.

## Permissões

`assinaturas.ver`, `assinaturas.criar`, `assinaturas.editar`, `assinaturas.excluir`, `assinaturas.aprovar` quando houver aprovação, `assinaturas.configurar`. Geradas na instalação e ligadas aos papéis existentes conforme a entrevista.

## Telas

Padrão visual do sistema: kicker, título, botão primário rosa, abas na página, cards e tabelas com estados vazio, carregando e erro, mobile sem scroll horizontal, i18n pt, en e es.

## Seeds e dados demo

Registros plausíveis com a marca demo do tenant, suficientes pra demonstrar cada aba.

## Provas exigidas

- Teste de cada caso de uso com repositório em memória.
- Arquivo `.http` com todas as rotas e resposta esperada.
- Screenshot Playwright de cada aba.
- Tentativa de ler registro deste módulo de outro tenant devolvendo 404.
- Instalar e desinstalar pelo painel admin sem erro, com bloqueio quando há dependente.
