# Método de Criação de Apresentação de Slides

> Manual operacional para criar apresentações de slides do dono (Cliente Exemplo) no padrão Orquestradora/Premium.
> Stack: HTML estático single-file, Reveal.js 5.x, GSAP 3.x, hospedagem Vercel + Cloudflare DNS, repo GitHub privado.
> Auto-suficiente. Outro agente lendo apenas este arquivo deve conseguir produzir um deck completo do zero.
> Versão 1, 30 de abril de 2026. Baseado nas apresentações reais já no ar (aula1.seudominio.com.br e seusite.com.br).

---

## 1. VISÃO GERAL

### O que é uma apresentação no padrão Orquestradora

Um deck navegável Reveal.js + GSAP, single-file, hospedado em subdomínio próprio (ex: `aula1.seudominio.com.br`). O dono apresenta ao vivo controlando com setas do teclado, em chamada de Zoom ou Google Meet, com a tela compartilhada em fullscreen. Os slides funcionam tanto pra live quanto pra consulta posterior.

### Diferencial visual (o que distingue do slide comum)

1. **Imagens de fundo geradas com IA em estilo anime ultra-realista premium.** Cada slide tem uma imagem 1920x1080 16:9 com os personagens da sua marca (o dono/apresentador e os personagens da marca) e cenário tech.
2. **Layout 50/50 com overlay de texto na metade direita escura.** Personagens à esquerda, conteúdo textual à direita, sem invadir a ilustração.
3. **Animações cinematográficas com GSAP.** Stagger de elementos entrando em cascata. Background com leve zoom contínuo. Sem flash branco entre slides.
4. **Slide-âncora.** Um dos slides centrais quebra o padrão e mostra um infográfico rico (estrutura central com elementos orbitando, diagrama de fluxo, etc) que prende atenção e funciona como mapa visual da aula.
5. **Tipografia agressiva.** Títulos 80-110px, bullets 28-40px. Texto pra ser lido em projetor, TV ou tela compartilhada em live.

### Tempo médio de produção

- **1 a 3 horas** dependendo do escopo:
  - 30 minutos planejando roteiro card a card
  - 30 a 90 minutos gerando imagens via nano-banana-pro (depende do número de tentativas até bater visual)
  - 30 a 60 minutos montando HTML, animações, refinamento

### Output

- Site no ar em `{nome-evento}.seudominio.com.br` ou `{nome-evento}.seudominio.com.br`
- Slides navegáveis com setas, espaço, F (fullscreen) e ESC (overview)
- Repo GitHub privado em `seu-usuario/{nome-evento}`
- Footer fixo com contador `01 / N`
- Mobile responsivo automático (viewport menor que 768px reorganiza)

---

## 2. STACK NECESSÁRIA

### Tecnologia

- **HTML estático single-file.** Um único `index.html` com todo CSS e JS inline. Sem framework, sem build, sem bundler.
- **Reveal.js 5.x via CDN.** Framework de deck navegável. Carregado via `cdn.jsdelivr.net`.
- **GSAP 3.x via CDN.** Engine de animação cinematográfica. Carregado via `cdnjs.cloudflare.com`.
- **Google Fonts via CDN.** Space Grotesk (títulos), Inter (corpo), JetBrains Mono (eyebrow e detalhes).
- **Vercel.** Hospedagem estática. Free tier resolve. Detecta como estático automático.
- **Cloudflare.** DNS para o subdomínio `.seudominio.com.br` ou `.seudominio.com.br`. CNAME proxied=false obrigatório.
- **GitHub privado.** Repo em `seu-usuario/`. Branch `main`. Commits com `author=usuario@exemplo.com` (regra rígida do Vercel).
- **nano-banana-pro (Gemini 3 Pro Image).** Geração de imagens 1920x1080 anime ultra-realista. Script local `/opt/seu-projeto/scripts/generate-image.js` (ou `/opt/seu-projeto/scripts/atualiza-imersao-3sites.py` como referência de uso).

### O que NÃO usar

- Sem `package.json`
- Sem Node.js no projeto
- Sem React, Vue, Svelte, Next.js
- Sem Tailwind (CSS direto, controle total da paleta)
- Sem `npm install`
- Sem build step

Vercel detecta como estático quando não há `package.json`. Sirva `index.html` da raiz.

### Variáveis de ambiente necessárias

```
GITHUB_TOKEN          (PAT classic com escopo repo)
VERCEL_TOKEN          (token de deploy do Vercel)
VERCEL_TEAM_ID        team_l6zSw1lZTlfHqKRIe38paQxY
CLOUDFLARE_API_TOKEN  (com permissão Zone:DNS:Edit)
CLOUDFLARE_ZONE_ID    (zone do domínio raiz, ex: seudominio.com.br)
GOOGLE_AI_API_KEY     (para nano-banana-pro)
```

---

## 3. PIPELINE DE 6 ETAPAS

A produção de uma apresentação segue 6 etapas em ordem. Pular etapas ou inverter ordem custa tempo de retrabalho.

### ETAPA 1 — DEFINIÇÃO DO ROTEIRO (10 a 12 SLIDES)

Antes de gerar qualquer imagem ou linha de código, definir o roteiro completo card a card. Tipicamente 10 slides, podendo ir até 12 quando o tema exige.

#### Estrutura padrão de roteiro

| Slide | Função | Conteúdo |
|---|---|---|
| 01 | Abertura (capa) | Título grande, subtítulo, data, identidade do evento |
| 02 | Mapa do que vai cobrir | Visão geral dos blocos da aula |
| 03 | Conceito-chave principal | Definição do tema central da aula |
| 04 | Slide-âncora (infográfico) | Diagrama visual rico que prende atenção |
| 05 | Pilar 1 / aprofundamento | Detalhe de um aspecto do conceito |
| 06 | Pilar 2 / aprofundamento | Outro aspecto |
| 07 | Pilar 3 / aprofundamento | Mais um |
| 08 | Demonstração prática | Lista, fluxo numerado, exemplo real |
| 09 | Casos reais ou métricas | Prova social, números, demonstração |
| 10 | Próximos passos / CTA | Dever de casa, próxima aula, próxima ação |

#### Como apresentar o roteiro pro dono (ou cliente)

Antes de gerar imagens, levar o roteiro completo em texto pro dono e aguardar OK. Formato sugerido:

```
ROTEIRO APRESENTAÇÃO X (10 slides)

01 · ABERTURA
   Eyebrow: "a comunidade · Semana 1 de 6"
   Título: "Aula 1 · Fundamentos"
   Subtítulo: "A estrutura agêntica por dentro"
   Data: "27 de abril de 2026"

02 · O QUE É ESTRUTURA AGÊNTICA
   Eyebrow: "Definição"
   Título: "O que é Estrutura Agêntica"
   Body: 1 parágrafo curto
   Compare-grid 3 cards: "Não é chatbot" | "Não é workflow" | "É time autônomo"
   Closing: "Funciona enquanto você dorme"

03 · ...
```

Aguardar OK explícito antes de avançar pra Etapa 2. Se o dono pedir ajuste, refazer e pedir OK de novo.

### ETAPA 2 — GERAÇÃO DAS IMAGENS DE FUNDO

Uma vez aprovado o roteiro, gerar 10 a 12 imagens 1920x1080 16:9 em estilo anime ultra-realista premium.

#### Especificação visual padrão

- **Resolução:** 1920x1080 (proporção 16:9)
- **Estilo:** anime ultra-realista premium, qualidade Studio Ghibli + tech edge
- **Personagens em todos os slides (no padrão):**
  - **o dono/apresentador:** descreva aqui o visual da SUA marca (não use a descrição de uma pessoa real)
  - **o personagem da sua marca (orquestradora/assistente):** descreva aqui o visual do personagem da sua marca
  - **o mascote da sua marca:** descreva aqui o visual do mascote da sua marca
- **Layout 50/50:** personagens posicionados na metade esquerda do frame, metade direita preparada com tela tech escura (gradiente preto a vermelho profundo) onde o overlay de texto vai entrar
- **Paleta:**
  - Vermelho profundo `#dc2626` e `#991b1b` (acento principal)
  - Preto `#0a0a0a` (fundo)
  - Cyan `#22d3ee` (acento secundário)
  - Off-white `#f5f5f5` (texto)
  - Glow neon nas bordas e detalhes
- **Cenário padrão:** escritório mega tecnológico, organização empresarial de tecnologia. Hologramas, telas flutuantes mostrando dashboards de resultados, logos discretos de plataformas (Hotmart, seu CRM, Chrome, Instagram, WhatsApp, LinkedIn, X) espalhados como ícones secundários
- **Iluminação:** dramática, contraste alto, glow vermelho neon vindo das telas, luz ambiente azulada, partículas digitais flutuando

#### Slide-âncora (slide 4) é a exceção

O slide-âncora pode ser FULLSCREEN sem o layout 50/50, com layout especial para o infográfico. Exemplos:

- **Modelo "estrutura central + orbitantes":** o personagem central da sua marca em destaque com 6 a 13 agentes em molduras circulares orbitando ao redor. Cada agente identificado com nome embaixo. Linhas finas conectando central aos orbitantes.
- **Modelo "diagrama de fluxo":** caixas conectadas por setas mostrando entrada, processamento, saída.
- **Modelo "pilha vertical":** 3 ou 4 camadas empilhadas com rótulo (ex: o personagem central no topo, execução no meio, mercado embaixo).

#### Comando padrão de geração

```bash
node /opt/seu-projeto/scripts/generate-image.js \
  --prompt "$(cat slide-prompts/slide-01.txt)" \
  --output assets/slide-01.png \
  --width 1920 --height 1080
```

Cada arquivo `slide-prompts/slide-NN.txt` contém um prompt ultra-detalhado descrevendo personagens, ambiente, iluminação, câmera/lente. Estrutura mínima do prompt:

```
Anime ultra-realistic premium illustration, cinematic lighting, 1920x1080 16:9.

LEFT HALF: [descrição dos personagens com pose e ação]

RIGHT HALF: [descrição da tela tech escura, gradiente preto a vermelho profundo, espaço preparado para overlay de texto, sem palavras escritas]

PALETTE: deep red #dc2626, black #0a0a0a, cyan accent #22d3ee, neon glow

ENVIRONMENT: [cenário detalhado, iluminação, partículas, holografia]

CAMERA: medium shot, eye level, 35mm equivalent, shallow depth of field

NO TEXT, NO LOGOS LARGE, NO SUBTITLES.
```

Importante: **o prompt NUNCA pede texto na imagem**. O texto vem por cima via overlay HTML/CSS, não dentro da imagem gerada. Imagens com texto fixo não escalam (não dá pra ajustar copy depois sem regenerar).

#### Iteração

Geralmente o primeiro batch sai 70 a 80% no ponto. Itere por slide, regenerando até o visual bater. Antes de avançar pra Etapa 3, validar visualmente cada slide com o dono (mostra screenshot ou ZIP com as 10 imagens).

### ETAPA 3 — COPY DO TEXTO POR SLIDE

Com imagens prontas, montar a copy de overlay. Regra absoluta: **máximo 50 palavras de texto por slide**.

#### Estrutura de copy por slide

```
EYEBROW (10-15 chars, JetBrains Mono uppercase, vermelho neon)
TÍTULO (4-8 palavras, Space Grotesk 700, off-white)
SUBTÍTULO (1 linha, Inter 500, cinza claro) [opcional]
3-5 BULLETS ou 1 BLOCO DE BODY-TEXT (28-40px, coluna vertical)
FRASE DE FORÇA / CLOSING (1 linha, 28-32px, vermelho neon ou off-white)
```

#### Regras de copy (inflexíveis)

- **ZERO travessões.** Use vírgula, ponto ou quebra de linha. Regra absoluta do dono.
- **Português brasileiro com acentuação completa.** Sem exceções. Texto em produção precisa ter acentos corretos (ã, õ, é, ê, ç, à, etc).
- **Tom direto, brasileiro.** Sem "vamos juntos descobrir", sem entusiasmo artificial.
- **Quotes literais entre aspas duplas** quando referenciar fala de outro.
- **Cada slide ensina algo.** Densidade de informação útil em cada card. Sem slide vazio "transição".

#### Exemplo de copy real (slide 5 da Aula 1)

```
EYEBROW: O cérebro central
TÍTULO: Orquestradora, a orquestradora
SECTION-LABEL: O que ela faz
BULLETS:
  - Recebe tudo que cai no meu Telegram, voz ou texto
  - Decide qual agente é certo pra executar
  - Acompanha enquanto roda, valida o output
  - Entrega de volta pra mim revisado
  - Mantém memória persistente em banco vetorial
  - Coordena 16 projetos paralelos sem se perder
FORCE-LINE: Eu falo com uma só. Ela fala com o time todo. Ponto de entrada único.
```

### ETAPA 4 — MONTAGEM HTML COM REVEAL.JS + GSAP

Com imagens e copy prontos, montar o `index.html`. Estrutura completa abaixo (pronta pra copiar e adaptar).

#### Esqueleto do `index.html`

```html
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>NOME DO EVENTO · Apresentação</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Space+Grotesk:wght@500;600;700&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet">

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/reveal.js@5.1.0/dist/reset.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/reveal.js@5.1.0/dist/reveal.css">

<style>
/* === DESIGN TOKENS === */
:root {
  --red: #dc2626;
  --red-deep: #991b1b;
  --red-glow: #ef4444;
  --cyan: #22d3ee;
  --black: #0a0a0a;
  --off: #f5f5f5;
  --muted: #a3a3a3;
}

/* === BASE: forcar background preto em todos os layers === */
html, body { background: var(--black); color: var(--off); font-family: 'Inter', sans-serif; }
.reveal { font-family: 'Inter', sans-serif; background: var(--black); }
.reveal-viewport { background: var(--black); }
.reveal .slides { text-align: left; background: var(--black); }
.reveal .slides section { background: var(--black); }
.reveal .backgrounds { background: var(--black); }
.reveal section { padding: 0; height: 100vh; width: 100vw; }

/* === IMAGEM DE FUNDO COM ZOOM SUTIL === */
.slide-bg {
  position: absolute; inset: 0;
  background-size: cover; background-position: center; background-repeat: no-repeat;
  z-index: 0;
  will-change: transform, opacity;
}

/* === GRADIENTE OVERLAY: escurece a metade direita pra texto === */
.slide-overlay {
  position: absolute; inset: 0;
  background: linear-gradient(90deg, rgba(0,0,0,0) 0%, rgba(0,0,0,0) 45%, rgba(10,10,10,0.55) 60%, rgba(10,10,10,0.78) 100%);
  z-index: 1;
}

/* === ZONA DE TEXTO: metade direita do slide === */
.text-zone {
  position: absolute;
  top: 0; right: 0; bottom: 0;
  width: 50%;
  padding: 4vh 5vw 8vh 3vw;
  display: flex;
  flex-direction: column;
  justify-content: center;
  z-index: 2;
}

/* === EYEBROW (rotulo superior pequeno) === */
.eyebrow {
  font-family: 'JetBrains Mono', monospace;
  font-size: 1rem;
  color: var(--red-glow);
  letter-spacing: 0.3em;
  text-transform: uppercase;
  margin-bottom: 1.2rem;
  opacity: 0;
  text-shadow: 0 0 12px rgba(239,68,68,0.5);
}

/* === HEADLINE (titulo principal) === */
.headline {
  font-family: 'Space Grotesk', sans-serif;
  font-weight: 700;
  font-size: 4.2rem;          /* 67px desktop */
  line-height: 1.05;
  color: var(--off);
  margin: 0 0 1.5rem 0;
  text-shadow: 0 4px 24px rgba(220,38,38,0.45), 0 0 40px rgba(0,0,0,0.6);
  opacity: 0;
}
.headline.size-md { font-size: 3.6rem; }
.headline.size-sm { font-size: 3rem; }

/* === SUBHEAD === */
.subhead {
  font-size: 1.5rem;
  font-weight: 500;
  color: #d4d4d4;
  line-height: 1.4;
  margin: 0 0 2rem 0;
  text-shadow: 0 2px 12px rgba(0,0,0,0.7);
  opacity: 0;
}

/* === BODY-TEXT (paragrafo) === */
.body-text {
  font-size: 1.35rem;
  font-weight: 400;
  line-height: 1.55;
  color: #e5e5e5;
  margin: 0 0 1.5rem 0;
  text-shadow: 0 2px 10px rgba(0,0,0,0.7);
  opacity: 0;
}

/* === BULLETS EM COLUNA VERTICAL === */
.bullet-list { list-style: none; padding: 0; margin: 0 0 2rem 0; }
.bullet-list li {
  font-size: 1.25rem;
  font-weight: 500;
  line-height: 1.45;
  color: #ededed;
  padding: 0.55rem 0 0.55rem 1.6rem;
  position: relative;
  text-shadow: 0 2px 10px rgba(0,0,0,0.7);
  opacity: 0;
}
.bullet-list li::before {
  content: '';
  position: absolute;
  left: 0;
  top: 1.05rem;
  width: 0.7rem;
  height: 0.7rem;
  background: var(--red);
  border-radius: 1px;
  box-shadow: 0 0 10px rgba(220,38,38,0.7);
}

/* === COMPARE GRID (3 cards horizontais com tag) === */
.compare-grid {
  display: grid;
  grid-template-columns: 1fr 1fr 1fr;
  gap: 1rem;
  margin: 0 0 1.5rem 0;
}
.compare-card {
  border: 1px solid rgba(220,38,38,0.3);
  background: rgba(10,10,10,0.55);
  backdrop-filter: blur(6px);
  padding: 1rem 1rem;
  border-radius: 6px;
  opacity: 0;
}
.compare-card .tag {
  font-family: 'JetBrains Mono', monospace;
  font-size: 0.75rem;
  letter-spacing: 0.2em;
  text-transform: uppercase;
  color: var(--red-glow);
  margin-bottom: 0.6rem;
  display: block;
}
.compare-card.is .tag { color: var(--cyan); }
.compare-card p { font-size: 1rem; line-height: 1.4; color: #e5e5e5; margin: 0; }

/* === TWO-COL GRID (cards lado a lado) === */
.two-col-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1.2rem;
  margin: 0 0 1.5rem 0;
}
.col-card {
  border: 1px solid rgba(220,38,38,0.35);
  background: rgba(10,10,10,0.6);
  backdrop-filter: blur(6px);
  padding: 1.2rem;
  border-radius: 8px;
  opacity: 0;
}
.col-card h4 {
  font-family: 'Space Grotesk', sans-serif;
  font-size: 1.1rem;
  color: var(--red-glow);
  margin: 0 0 0.8rem 0;
  letter-spacing: 0.02em;
  text-transform: uppercase;
}
.col-card ul { list-style: none; padding: 0; margin: 0; }
.col-card ul li {
  font-size: 1rem;
  padding: 0.3rem 0 0.3rem 0.9rem;
  position: relative;
  color: #e0e0e0;
  line-height: 1.4;
}
.col-card ul li::before {
  content: '·';
  color: var(--red);
  position: absolute;
  left: 0;
  font-size: 1.4rem;
  line-height: 1;
}

/* === FORCE-LINE (frase de forca com barra vermelha) === */
.force-line {
  font-family: 'Space Grotesk', sans-serif;
  font-size: 1.25rem;
  font-weight: 500;
  color: #f0f0f0;
  line-height: 1.4;
  border-left: 3px solid var(--red);
  padding-left: 1rem;
  margin-top: 1rem;
  opacity: 0;
  text-shadow: 0 2px 10px rgba(0,0,0,0.6);
}

/* === CLOSING-LINE (frase final em destaque vermelho) === */
.closing-line {
  font-family: 'Space Grotesk', sans-serif;
  font-size: 1.5rem;
  font-weight: 600;
  color: var(--red-glow);
  margin-top: 1rem;
  text-shadow: 0 0 20px rgba(220,38,38,0.4);
  opacity: 0;
  letter-spacing: 0.01em;
}

/* === ORBIT-BOX (slide-ancora: estrutura central com camadas) === */
.orbit-box { margin: 0.5rem 0 1.5rem 0; }
.orbit-center {
  display: inline-block;
  font-family: 'Space Grotesk', sans-serif;
  font-size: 1.4rem;
  font-weight: 700;
  color: var(--off);
  background: linear-gradient(135deg, var(--red) 0%, var(--red-deep) 100%);
  padding: 0.6rem 1.4rem;
  border-radius: 6px;
  box-shadow: 0 0 28px rgba(220,38,38,0.5);
  opacity: 0;
  margin-bottom: 1rem;
}
.orbit-layer { margin-top: 0.7rem; opacity: 0; }
.orbit-layer .layer-label {
  font-family: 'JetBrains Mono', monospace;
  font-size: 0.8rem;
  letter-spacing: 0.2em;
  color: var(--cyan);
  text-transform: uppercase;
  margin-bottom: 0.5rem;
  display: block;
}
.orbit-layer .agents { display: flex; flex-wrap: wrap; gap: 0.5rem; }
.orbit-layer .agent-chip {
  font-family: 'Inter', sans-serif;
  font-size: 0.95rem;
  font-weight: 600;
  padding: 0.4rem 0.85rem;
  background: rgba(220,38,38,0.15);
  border: 1px solid rgba(220,38,38,0.45);
  border-radius: 4px;
  color: #f5f5f5;
  opacity: 0;
}
.orbit-layer.outer .agent-chip {
  background: rgba(34,211,238,0.1);
  border-color: rgba(34,211,238,0.4);
}

/* === ACTION-GRID (lista numerada estilo cards) === */
.action-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 0.6rem 1rem;
  margin: 0.5rem 0 1.2rem 0;
}
.action-grid .item {
  display: flex;
  align-items: flex-start;
  gap: 0.7rem;
  font-size: 1.05rem;
  line-height: 1.4;
  opacity: 0;
}
.action-grid .num {
  font-family: 'JetBrains Mono', monospace;
  font-size: 0.85rem;
  font-weight: 700;
  color: var(--red-glow);
  background: rgba(220,38,38,0.15);
  border: 1px solid var(--red);
  padding: 0.15rem 0.5rem;
  border-radius: 3px;
  min-width: 1.7rem;
  text-align: center;
}
.action-grid .item p { margin: 0; color: #e5e5e5; }
.action-grid .item p strong { color: var(--off); font-weight: 700; }

/* === FLOW-NUMBERED (ordered list com numeros estilo terminal) === */
.flow-numbered { list-style: none; padding: 0; margin: 0 0 1.5rem 0; counter-reset: step; }
.flow-numbered li {
  counter-increment: step;
  padding: 0.5rem 0 0.5rem 2.5rem;
  position: relative;
  font-size: 1.15rem;
  line-height: 1.4;
  color: #ededed;
  opacity: 0;
}
.flow-numbered li::before {
  content: counter(step);
  position: absolute;
  left: 0;
  top: 0.45rem;
  font-family: 'JetBrains Mono', monospace;
  font-size: 0.85rem;
  font-weight: 700;
  color: var(--red-glow);
  background: rgba(220,38,38,0.15);
  border: 1px solid var(--red);
  padding: 0.2rem 0.55rem;
  border-radius: 3px;
}

/* === EXAMPLE-BLOCK (callout cyan com label) === */
.example-block {
  border-left: 3px solid var(--cyan);
  padding: 0.7rem 1rem;
  background: rgba(34,211,238,0.06);
  margin-top: 0.8rem;
  font-size: 1.05rem;
  line-height: 1.5;
  color: #e5e5e5;
  opacity: 0;
}
.example-block .label {
  font-family: 'JetBrains Mono', monospace;
  font-size: 0.7rem;
  letter-spacing: 0.2em;
  color: var(--cyan);
  text-transform: uppercase;
  display: block;
  margin-bottom: 0.4rem;
}

/* === FOOTER FIXO COM CONTADOR === */
footer.site-footer {
  position: fixed;
  bottom: 1.2rem;
  left: 2rem;
  right: 2rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-family: 'JetBrains Mono', monospace;
  font-size: 0.78rem;
  letter-spacing: 0.15em;
  color: rgba(245,245,245,0.55);
  text-transform: uppercase;
  z-index: 50;
  pointer-events: none;
}
footer.site-footer .right { color: var(--red-glow); font-weight: 700; }

/* === SETAS CUSTOM CENTRALIZADAS VERTICAIS === */
.custom-nav {
  position: fixed;
  top: 50%;
  transform: translateY(-50%);
  width: 76px;
  height: 76px;
  border-radius: 50%;
  background: rgba(10,10,10,0.45);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(220,38,38,0.5);
  color: var(--red-glow);
  font-size: 28px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  z-index: 100;
  transition: all 0.2s;
  box-shadow: 0 0 20px rgba(220,38,38,0.3);
}
.custom-nav:hover {
  background: rgba(220,38,38,0.2);
  box-shadow: 0 0 30px rgba(220,38,38,0.6);
}
.custom-nav.left { left: 28px; }
.custom-nav.right { right: 28px; }

/* === ESCONDE CONTROLES DEFAULT DO REVEAL === */
.reveal .controls { display: none !important; }
.reveal .progress { color: var(--red); height: 3px; }

/* === COVER-ZONE (slide capa, mesmo padrao do text-zone) === */
.cover-zone {
  position: absolute;
  top: 0; right: 0; bottom: 0;
  width: 50%;
  padding: 6vh 5vw 10vh 3vw;
  display: flex;
  flex-direction: column;
  justify-content: center;
  z-index: 2;
}

/* === RESPONSIVO MOBILE === */
@media (max-width: 1280px) {
  .headline { font-size: 3.4rem; }
  .headline.size-md { font-size: 3rem; }
  .headline.size-sm { font-size: 2.5rem; }
  .body-text, .subhead { font-size: 1.15rem; }
  .bullet-list li { font-size: 1.1rem; }
}
@media (max-width: 768px) {
  .text-zone, .cover-zone {
    width: 100%;
    padding: 4vh 6vw;
  }
  .slide-overlay {
    background: linear-gradient(180deg, rgba(0,0,0,0.4) 0%, rgba(10,10,10,0.85) 60%, rgba(10,10,10,0.95) 100%);
  }
  .custom-nav { display: none; }
  .compare-grid, .two-col-grid, .action-grid { grid-template-columns: 1fr; }
  .headline { font-size: 2.4rem; }
  .headline.size-md { font-size: 2.1rem; }
}
</style>
</head>
<body>

<div class="reveal">
  <div class="slides">

    <!-- SLIDE 1 / ABERTURA -->
    <section data-slide="1">
      <div class="slide-bg" style="background-image: url('assets/slide-01.png');"></div>
      <div class="slide-overlay"></div>
      <div class="cover-zone">
        <span class="eyebrow anim-el">a comunidade · Semana 1 de 6</span>
        <h1 class="headline anim-el">Aula 1<br/>Fundamentos</h1>
        <p class="subhead anim-el">A Estrutura Agêntica, meu time de agentes de IA por dentro.</p>
        <p class="sub-sub anim-el">27 de abril de 2026 · ao vivo</p>
      </div>
    </section>

    <!-- ... outras 9 sections seguem mesmo padrao ... -->

  </div>
</div>

<!-- SETAS CUSTOM CENTRALIZADAS NAS LATERAIS -->
<button class="custom-nav left" id="navPrev" aria-label="Anterior">‹</button>
<button class="custom-nav right" id="navNext" aria-label="Proximo">›</button>

<!-- FOOTER FIXO -->
<footer class="site-footer">
  <span class="left">Aula 1 · a comunidade · 27 abril 2026</span>
  <span class="right" id="slide-counter">01 / 10</span>
</footer>

<script src="https://cdn.jsdelivr.net/npm/reveal.js@5.1.0/dist/reveal.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js"></script>

<script>
const deck = new Reveal({
  hash: true,
  controls: false,           // controles default desligados
  progress: true,
  center: false,
  embedded: false,
  width: '100%',
  height: '100%',
  margin: 0,
  minScale: 1,
  maxScale: 1,
  transition: 'fade',        // SEM flash branco
  transitionSpeed: 'default',
  backgroundTransition: 'fade',
  keyboard: {
    32: 'next',              // espaco avanca
    70: () => {               // F = fullscreen
      if (document.fullscreenElement) document.exitFullscreen();
      else document.documentElement.requestFullscreen();
    }
  }
});

deck.initialize().then(() => {
  animateSlide(deck.getCurrentSlide());
  updateCounter();
});

deck.on('slidechanged', (event) => {
  animateSlide(event.currentSlide);
  updateCounter();
});

// SETAS CUSTOM controlam o deck
document.getElementById('navPrev').addEventListener('click', () => deck.prev());
document.getElementById('navNext').addEventListener('click', () => deck.next());

function updateCounter() {
  const i = deck.getIndices();
  const total = deck.getTotalSlides();
  const cur = String(i.h + 1).padStart(2, '0');
  const tot = String(total).padStart(2, '0');
  const el = document.getElementById('slide-counter');
  if (el) el.textContent = `${cur} / ${tot}`;
}

function animateSlide(slide) {
  if (!slide) return;

  // Background: leve zoom contínuo
  const bg = slide.querySelector('.slide-bg');
  if (bg) {
    gsap.fromTo(bg,
      { opacity: 0, scale: 1.0 },
      { opacity: 1, scale: 1.025, duration: 8, ease: 'power1.out' }
    );
    gsap.fromTo(bg,
      { opacity: 0 },
      { opacity: 1, duration: 0.9, ease: 'power2.out' }
    );
  }

  // Elementos com classe .anim-el entram em cascata
  const els = slide.querySelectorAll('.anim-el');
  if (els.length) {
    gsap.fromTo(els,
      { opacity: 0, y: 30 },
      {
        opacity: 1,
        y: 0,
        duration: 0.7,
        ease: 'power2.out',
        stagger: 0.13,
        delay: 0.25
      }
    );
  }

  // Chips do slide-âncora entram em cascata mais rápida
  const chips = slide.querySelectorAll('.anim-chip');
  if (chips.length) {
    gsap.fromTo(chips,
      { opacity: 0, x: -20, scale: 0.92 },
      {
        opacity: 1,
        x: 0,
        scale: 1,
        duration: 0.45,
        ease: 'back.out(1.4)',
        stagger: 0.08,
        delay: 0.6
      }
    );
  }
}
</script>

</body>
</html>
```

#### Componentes reusáveis dentro do `.text-zone`

Cada slide pode usar 1 ou mais desses componentes pra estruturar o conteúdo. Lista completa com quando usar cada:

| Componente | CSS class | Quando usar |
|---|---|---|
| Bullets verticais | `.bullet-list` | 4 a 6 itens curtos |
| 3 cards comparativos | `.compare-grid` + `.compare-card` | Comparar 3 conceitos lado a lado (ex: "não é A, não é B, é C") |
| 2 cards lado a lado | `.two-col-grid` + `.col-card` | Comparar 2 caminhos ou opções |
| Lista numerada | `.flow-numbered` | Passo a passo em ordem |
| Cards numerados em grade | `.action-grid` + `.item` + `.num` | Apresentar 4 a 6 elementos com hierarquia de número |
| Bloco de exemplo cyan | `.example-block` | Mostrar um exemplo real destacado |
| Frase de força | `.force-line` | Frase impactante com barra vermelha à esquerda |
| Frase final | `.closing-line` | Última frase do slide, destaque vermelho |
| Estrutura orbital | `.orbit-box` + `.orbit-center` + `.orbit-layer` + `.agent-chip` | Slide-âncora com central + camadas orbitando |

### ETAPA 5 — DEPLOY (workflow padrão)

Repo GitHub privado, projeto Vercel, CNAME Cloudflare, deploy manual via API. Sequência abaixo.

#### Passo 1: Setup local

```bash
mkdir nome-evento && cd nome-evento
git init -b main
mkdir assets
# colocar slide-01.png ... slide-10.png em assets/
printf "node_modules\n.env\n.DS_Store\n*.log\n" > .gitignore
```

#### Passo 2: Criar o `index.html`

Use o esqueleto da Etapa 4 acima. Adapte:
- Título da aba
- Texto do footer
- 10 sections com background da imagem correspondente e overlay de texto

#### Passo 3: Criar repo GitHub privado

```bash
curl -X POST -H "Authorization: token $GITHUB_TOKEN" \
  -H "Accept: application/vnd.github+json" \
  https://api.github.com/user/repos \
  -d '{
    "name":"nome-evento",
    "private":true,
    "description":"Apresentacao slides Reveal.js + GSAP",
    "auto_init":false
  }'
```

Anote o `id` numérico do repo da resposta JSON. Vai precisar no Passo 8.

#### Passo 4: Push inicial

```bash
git add index.html assets/ .gitignore
git -c user.email=usuario@exemplo.com -c user.name="Cliente Exemplo" \
    commit -m "init: apresentacao slides nome-evento"

git remote add origin https://$GITHUB_TOKEN@github.com/seu-usuario/nome-evento.git
git push -u origin main
```

**CRÍTICO:** o `-c user.email=usuario@exemplo.com` no commit é obrigatório. Vercel rejeita deploy de commits cujo email não está vinculado à conta.

#### Passo 5: Criar projeto Vercel

```bash
curl -X POST "https://api.vercel.com/v9/projects?teamId=team_l6zSw1lZTlfHqKRIe38paQxY" \
  -H "Authorization: Bearer $VERCEL_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name":"nome-evento",
    "framework":null,
    "gitRepository":{
      "type":"github",
      "repo":"seu-usuario/nome-evento"
    }
  }'
```

Anote o `id` do projeto da resposta. Use ele nos passos seguintes.

#### Passo 6: Adicionar domínio customizado

```bash
curl -X POST "https://api.vercel.com/v10/projects/PROJECT_ID/domains?teamId=team_l6zSw1lZTlfHqKRIe38paQxY" \
  -H "Authorization: Bearer $VERCEL_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name":"nome-evento.seudominio.com.br"}'
```

#### Passo 7: Criar CNAME no Cloudflare

```bash
curl -X POST "https://api.cloudflare.com/client/v4/zones/$CLOUDFLARE_ZONE_ID/dns_records" \
  -H "Authorization: Bearer $CLOUDFLARE_API_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "type":"CNAME",
    "name":"nome-evento",
    "content":"cname.vercel-dns.com",
    "ttl":1,
    "proxied":false
  }'
```

**CRÍTICO:** `proxied=false`. Se ligar o proxy laranja do Cloudflare, o Vercel não consegue emitir o certificado SSL.

#### Passo 8: Disparar deploy manual

```bash
LAST_SHA=$(git rev-parse HEAD)
REPO_ID=ID_NUMERICO_DO_PASSO_3

curl -X POST "https://api.vercel.com/v13/deployments?teamId=team_l6zSw1lZTlfHqKRIe38paQxY" \
  -H "Authorization: Bearer $VERCEL_TOKEN" \
  -H "Content-Type: application/json" \
  -d "{
    \"name\":\"nome-evento\",
    \"target\":\"production\",
    \"gitSource\":{
      \"type\":\"github\",
      \"repoId\":$REPO_ID,
      \"ref\":\"main\",
      \"sha\":\"$LAST_SHA\"
    }
  }"
```

**CRÍTICO:** o `repoId` é numérico, não use o slug. Pegue do JSON do Passo 3.

#### Passo 9: Validar

```bash
dig +short nome-evento.seudominio.com.br CNAME
# deve retornar: cname.vercel-dns.com.

curl -I https://nome-evento.seudominio.com.br/
# esperar: HTTP/2 200, content-type: text/html
```

### ETAPA 6 — TESTES E AJUSTES PÓS-DEPLOY

Com a apresentação no ar, validar visualmente cada slide e ajustar tipografia se preciso.

#### Checklist de validação

- Cada slide carrega imagem de fundo (sem 404 nas imagens em assets/)
- Texto fica restrito à metade direita escura
- Animações GSAP entram em cascata em cada slide
- Atalhos de teclado funcionam: setas, espaço (avança), F (fullscreen), ESC (overview do Reveal)
- Setas custom nas laterais respondem a clique
- Sem flash branco na transição entre slides
- Footer fixo aparece com contador correto (`01 / 10`, `02 / 10` etc)
- Mobile (viewport menor que 768px): texto ocupa toda largura, setas custom somem, slides empilham
- Tipografia legível a 2 metros de distância em telas grandes (TV, projetor)

Se algum item falhar, voltar pro `index.html`, ajustar, commitar com email correto, push, e disparar novo deploy:

```bash
git add index.html
git -c user.email=usuario@exemplo.com -c user.name="Cliente Exemplo" \
    commit -m "fix: ajuste tipografia slide 4"
git push origin main

# Deploy automático dispara via webhook do Vercel.
# Se não disparar, repete o curl do Passo 8 com novo SHA.
```

---

## 4. DESIGN SYSTEM PADRÃO

### Tipografia

| Elemento | Família | Peso | Tamanho desktop | Observação |
|---|---|---|---|---|
| Headline / título | Space Grotesk | 700 | 80 a 110px (`4.2rem` a `5.5rem`) | Variantes `size-md` (3.6rem) e `size-sm` (3rem) |
| Subhead | Inter | 500 | 24 a 36px (`1.5rem`) | Cinza claro, abaixo do título |
| Body-text | Inter | 400 | 22 a 28px (`1.35rem`) | Parágrafo de explicação |
| Bullets | Inter | 500 | 20 a 28px (`1.25rem`) | Coluna vertical |
| Eyebrow | JetBrains Mono | 500 | 16 a 20px (`1rem`) | Letter-spacing 0.3em, uppercase |
| Section-label | JetBrains Mono | 500 | 13.6px (`0.85rem`) | Cyan, label de seção |
| Force-line / Closing | Space Grotesk | 500-600 | 20 a 24px (`1.25rem` a `1.5rem`) | Frase de impacto |
| Footer counter | JetBrains Mono | 700 | 12.5px (`0.78rem`) | Letter-spacing 0.15em |

Line-height: 1.55 a 1.6 em corpo, 1.05 a 1.2 em títulos grandes. Letter-spacing: títulos em caixa alta ganham 1 a 2px.

### Paleta padrão (terminal Matrix anime tech)

```css
:root {
  --red: #dc2626;       /* vermelho neon principal */
  --red-deep: #991b1b;  /* vermelho profundo */
  --red-glow: #ef4444;  /* vermelho glow brilho */
  --cyan: #22d3ee;      /* cyan acento secundário */
  --black: #0a0a0a;     /* preto fundo */
  --off: #f5f5f5;       /* off-white texto */
  --muted: #a3a3a3;     /* cinza muted */
}
```

Glow padrão usado em títulos:

```css
text-shadow: 0 4px 24px rgba(220,38,38,0.45), 0 0 40px rgba(0,0,0,0.6);
```

### Layout 50/50 (padrão pra slides com personagens)

- Imagem ocupa 100% do slide como `background-image` em `.slide-bg`
- `.slide-overlay` é um gradiente horizontal que escurece a metade direita: `linear-gradient(90deg, rgba(0,0,0,0) 0%, rgba(0,0,0,0) 45%, rgba(10,10,10,0.55) 60%, rgba(10,10,10,0.78) 100%)`
- `.text-zone` tem `right: 0; width: 50%; padding: 4vh 5vw 8vh 3vw`
- Texto fica restrito à metade direita, NUNCA invade os personagens à esquerda

### Slide-âncora (quebra do padrão)

- Pode ser fullscreen sem `.text-zone`
- Layout especial: estrutura central + elementos orbitando (`.orbit-box`)
- Animação cascata GSAP nos chips orbitantes (classe `.anim-chip`)
- Background ainda usa `.slide-bg` mas a imagem é diferente (composição central, sem 50/50)

### Espaçamentos verticais

```css
.text-zone { padding: 4vh 5vw 8vh 3vw; }
.eyebrow { margin-bottom: 1.2rem; }
.headline { margin: 0 0 1.5rem 0; }
.subhead { margin: 0 0 2rem 0; }
.body-text { margin: 0 0 1.5rem 0; }
.bullet-list { margin: 0 0 2rem 0; }
.force-line, .closing-line { margin-top: 1rem; }
```

---

## 5. REGRAS INVIOLÁVEIS DE TIPOGRAFIA E LAYOUT

Lista de regras permanentes do dono. Quebrar qualquer uma custa retrabalho.

### 1. Texto sempre 2 a 3x maior que o "default visual normal"

O dono lê em telas grandes (TV, projetor, share screen em live). Texto pequeno é ilegível. Em dúvida, aumente.

- Títulos: 80 a 120px (não 40 a 50px)
- Subtítulos: 48 a 72px
- Bullets/cards: 32 a 48px
- Detalhes/footer: 20 a 28px (mínimo)

### 2. Texto SEMPRE estritamente dentro da metade escura quando há personagens

Quando o slide tem layout 50/50 (personagens à esquerda + tela tech à direita), o overlay de texto fica APENAS na metade direita, com margem segura interna de 5% pra cada lado. Nunca sobre a foto.

### 3. Elementos múltiplos (3+ caixas/bullets) SEMPRE em coluna vertical

Quando o slide tem layout 50/50 com personagens, bullets e cards entram empilhados verticalmente. Nunca em linha horizontal espremida. O lado escuro tem altura suficiente. Linha horizontal só faz sentido em slides full-width sem personagens.

### 4. Setas de navegação grandes nas laterais

Não usar controles default do Reveal.js no canto inferior. Use setas custom: 70 a 80px círculo glassmorphism com borda neon, posição centralizada vertical (`top: 50%; transform: translateY(-50%)`) na esquerda e direita. Esconder controles default com `controls: false` na config do Reveal e `display: none` na classe `.reveal .controls`.

### 5. Sem flash branco entre slides

Forçar background `#0a0a0a` em:
- `html`, `body`
- `.reveal`
- `.reveal-viewport`
- `.reveal .slides`
- `.reveal .slides section`
- `.reveal .backgrounds`

Configurar `transition: 'fade'` e `backgroundTransition: 'fade'` no Reveal.

### 6. Personagens da sua marca em TODOS os slides (no padrão)

No padrão, os personagens da sua marca aparecem em todos os slides na metade esquerda. Ajuste os personagens conforme a sua marca (o dono/apresentador e os personagens da marca). A regra do layout 50/50 e do overlay de texto à direita continua valendo.

### 7. ZERO travessões no texto

Use vírgula, ponto ou quebra de linha. Regra absoluta do dono.

### 8. Português brasileiro com acentuação completa

Sem exceções. Todo texto público (slides, copy, mensagens) precisa ter acentos corretos. Sem expressões traduzidas literalmente do inglês.

### 9. OG image obrigatória em apresentação compartilhável

Sem `og:image`, link no WhatsApp/Telegram fica sem preview. Adicionar `<meta property="og:image" content="https://nome-evento.seudominio.com.br/assets/og.png">` no `<head>`.

### 10. Mobile responsivo obrigatório

Testar em viewport menor que 768px. Setas custom somem (`display: none`), `.text-zone` ocupa 100% da largura, `.slide-overlay` muda pra gradient vertical em vez de horizontal.

---

## 6. REGRAS DE COPY

### Inflexíveis

- **ZERO travessões.** Use vírgula, ponto, quebra. Sempre.
- **Português brasileiro** com acentuação completa.
- **Cada slide MAX 50 palavras** de overlay de texto.
- **Tom direto, brasileiro.** Sem "vamos juntos descobrir", sem "fico feliz em compartilhar", sem entusiasmo artificial.
- **Quotes literais entre aspas duplas** quando referenciar fala de outro.
- **Cada slide ensina algo.** Densidade de informação em cada card. Sem slide vazio "transição".
- **Verbos no presente, ação direta.** "Orquestradora recebe, decide, delega" em vez de "Orquestradora será capaz de receber, decidir e delegar".
- **Números concretos** quando houver. "16 projetos paralelos" é melhor que "vários projetos".

### Estrutura de copy por slide (mnemônico)

```
EYEBROW (2 a 4 palavras, identificador da seção)
TÍTULO (4 a 8 palavras, headline forte)
SUBTÍTULO (1 linha) [opcional]
CONTEÚDO (3 a 5 bullets OU 1 bloco body-text OU 1 grade de cards)
FORCE-LINE / CLOSING-LINE (1 linha de impacto)
```

### Exemplos de boa copy (extraídos da Aula 1)

```
Slide 2:
EYEBROW: Definição
TÍTULO: O que é Estrutura Agêntica
BODY: Um time de agentes de IA com função própria, memória que não esquece e responsabilidade clara. Cada um faz uma parte. Junto, eles operam o seu negócio.
COMPARE-GRID:
  - Não é: Chatbot que responde pergunta solta.
  - Não é: Workflow do Make ou N8N que só conecta caixinha.
  - É: Time autônomo com função, contexto persistente e dono da entrega.
CLOSING: Funciona enquanto você dorme.
```

```
Slide 4 (slide-âncora):
EYEBROW: Slide-âncora
TÍTULO: A Estrutura da Orquestradora
SUBHEAD: Como meu time de IA funciona por dentro.
ORBIT-CENTER: O personagem da sua marca · Orquestradora
LAYER 1 (execução): Juliana, Paulo, Jonathan, Rafael
LAYER 2 (mercado): Cliente Exemplo Clone, Davi, Lucas, Felipe, Matheus, Amanda, Carolina, Bianca
FORCE-LINE: 14 agentes ativos, 91 mil linhas no CRM, 16 projetos rodando em paralelo. Sem um humano no operacional.
```

---

## 7. ANIMAÇÕES PADRÃO (GSAP)

### Comportamento ao trocar de slide

1. Background da imagem entra com fade `0.9s` e começa zoom contínuo `8s` (de `scale: 1.0` para `scale: 1.025`)
2. Todos elementos com classe `.anim-el` entram em cascata: `opacity 0 -> 1` + `y: 30 -> 0`, com `stagger: 0.13s`, `duration: 0.7s`, `delay: 0.25s`
3. Chips do slide-âncora (`.anim-chip`) entram com `back.out(1.4)`: `opacity 0 -> 1`, `x: -20 -> 0`, `scale: 0.92 -> 1`, `stagger: 0.08s`, `delay: 0.6s`

### Código JS completo

```js
function animateSlide(slide) {
  if (!slide) return;

  // Background com fade-in + zoom continuo
  const bg = slide.querySelector('.slide-bg');
  if (bg) {
    gsap.fromTo(bg,
      { opacity: 0, scale: 1.0 },
      { opacity: 1, scale: 1.025, duration: 8, ease: 'power1.out' }
    );
    gsap.fromTo(bg,
      { opacity: 0 },
      { opacity: 1, duration: 0.9, ease: 'power2.out' }
    );
  }

  // Cascata principal
  const els = slide.querySelectorAll('.anim-el');
  if (els.length) {
    gsap.fromTo(els,
      { opacity: 0, y: 30 },
      {
        opacity: 1,
        y: 0,
        duration: 0.7,
        ease: 'power2.out',
        stagger: 0.13,
        delay: 0.25
      }
    );
  }

  // Chips do slide-âncora (cascata mais rápida com bounce)
  const chips = slide.querySelectorAll('.anim-chip');
  if (chips.length) {
    gsap.fromTo(chips,
      { opacity: 0, x: -20, scale: 0.92 },
      {
        opacity: 1,
        x: 0,
        scale: 1,
        duration: 0.45,
        ease: 'back.out(1.4)',
        stagger: 0.08,
        delay: 0.6
      }
    );
  }
}

// Hook: chamar animateSlide a cada slide muda
deck.on('slidechanged', (event) => {
  animateSlide(event.currentSlide);
  updateCounter();
});

// E no boot inicial
deck.initialize().then(() => {
  animateSlide(deck.getCurrentSlide());
  updateCounter();
});
```

### Convenções de classes pra animar

- `.anim-el` em qualquer elemento do `.text-zone` que deve entrar em cascata. Inclua em: eyebrow, headline, subhead, body-text, bullets (cada `<li>`), cards (cada `.col-card`, `.compare-card`, `.service-card`, `.action-grid .item`), force-line, closing-line.
- `.anim-chip` em chips do slide-âncora (`.agent-chip`).

Cada elemento que tem `.anim-el` começa com `opacity: 0` no CSS, GSAP anima até `opacity: 1`.

---

## 8. EXEMPLO REAL — AULA 1 A COMUNIDADE

Caso real entregue em 27 de abril de 2026.

### Especificação

- **Tema:** A Estrutura Agêntica (time de agentes IA da Orquestradora)
- **Total:** 10 slides
- **Contexto:** Aula 1 da a comunidade (programa de 6 semanas)
- **Audiência:** 100 alunos da comunidade fechada
- **Apresentado em:** Zoom ao vivo + gravação na área de membros

### Roteiro completo

| # | Tema | Componentes principais |
|---|---|---|
| 01 | Abertura | `.cover-zone` + `eyebrow` + `headline` + `subhead` |
| 02 | O que é Estrutura Agêntica | `.body-text` + `.compare-grid` (3 cards) + `.closing-line` |
| 03 | As 2 formas (OpenClaw vs Claude CLI) | `.two-col-grid` (2 cards comparativos) + `.force-line` |
| 04 | Slide-âncora: Estrutura da Orquestradora | `.orbit-box` (Orquestradora central + 2 layers de chips) + `.force-line` |
| 05 | Orquestradora, a orquestradora | `.bullet-list` (6 itens) + `.force-line` |
| 06 | Camada de execução | `.action-grid` (4 itens numerados) + `.closing-line` |
| 07 | Camada de mercado | `.two-col-grid` (Cliente Exemplo Clone + SDRs) + `.force-line` |
| 08 | Stack que vira receita | `.services-grid` (8 services-card numerados) + `.closing-line` |
| 09 | Como usar no dia a dia | `.flow-numbered` (5 passos) + `.example-block` (cyan) |
| 10 | Próximos passos | `.bullet-list` (4 deveres) + `.next-aula` (label próxima aula) + `.force-line` |

### Imagens

10 imagens em `assets/slide-01.png` até `assets/slide-10.png`, geradas via nano-banana-pro (Gemini 3 Pro Image), 1920x1080, anime ultra-realista, layout 50/50 com os personagens da sua marca à esquerda e tela tech à direita.

### Tempo total de produção

- 30 minutos: roteiro card a card aprovado pelo dono
- 90 minutos: geração + iteração das 10 imagens
- 60 minutos: montagem do `index.html` com componentes
- 20 minutos: deploy + validação visual
- **Total:** aproximadamente 3h20

### Repositório e URL

- Repo: `seu-usuario/aula1-comunidade` (privado)
- URL no ar: `https://aula1.seudominio.com.br`
- Branch: `main`
- Single-file: `index.html` (820 linhas, 25KB)

---

## 9. CHECKLIST DE QUALIDADE

Antes de declarar a apresentação pronta e mandar pro dono, validar cada item.

### Conteúdo

- [ ] 10 a 12 slides com roteiro aprovado pelo dono (ou cliente)
- [ ] Cada slide tem eyebrow, título e conteúdo principal
- [ ] Cada slide tem MAX 50 palavras de overlay
- [ ] Slide-âncora (geralmente o 4) tem infográfico rico
- [ ] Slide final (último) tem CTA ou próximos passos claros

### Visual

- [ ] 10 a 12 imagens 1920x1080 em `assets/slide-NN.png`
- [ ] Personagens da sua marca na metade esquerda em todas (no padrão)
- [ ] Cada imagem tem zona escura preparada na metade direita pra texto
- [ ] Estilo anime ultra-realista premium consistente entre slides
- [ ] Paleta vermelho + preto + cyan + neon respeitada

### Tipografia

- [ ] Títulos 80 a 110px desktop
- [ ] Bullets 28 a 40px
- [ ] Texto SOMENTE na metade direita (nunca sobre personagens)
- [ ] Coluna vertical em listas com 3+ itens
- [ ] Eyebrow em JetBrains Mono uppercase
- [ ] Headline em Space Grotesk 700
- [ ] Body em Inter 400-500

### Interação

- [ ] Atalhos teclado: setas, espaço (avança), F (fullscreen), ESC (overview)
- [ ] Setas custom centralizadas vertical nas laterais (esquerda e direita)
- [ ] Setas custom respondem a clique
- [ ] Footer fixo com contador `01 / N` atualizando

### Animações

- [ ] Background com leve zoom contínuo (8s)
- [ ] Elementos `.anim-el` entram em cascata (stagger 0.13s)
- [ ] Chips `.anim-chip` entram com bounce no slide-âncora
- [ ] Sem flash branco na transição entre slides
- [ ] `transition: 'fade'` configurado no Reveal

### Deploy

- [ ] Repo GitHub privado em `seu-usuario/`
- [ ] Commits com `author=usuario@exemplo.com`
- [ ] Projeto Vercel criado e linkado ao repo
- [ ] Domínio customizado adicionado (`{nome}.seudominio.com.br`)
- [ ] CNAME no Cloudflare apontando pra `cname.vercel-dns.com` com `proxied=false`
- [ ] Deploy manual disparado via API
- [ ] HTTPS válido (cert SSL emitido pelo Vercel, não expirado)
- [ ] Sem erro 404 nas imagens em `assets/`

### Mobile

- [ ] Viewport menor que 768px: texto ocupa 100% da largura
- [ ] Setas custom somem em mobile
- [ ] Slides empilham em coluna única
- [ ] Tipografia escala (headline 2.4rem em mobile)

### Texto

- [ ] ZERO travessões em todo o texto
- [ ] Português brasileiro com acentuação 100% correta
- [ ] Quotes literais entre aspas duplas quando aplicável
- [ ] Sem expressões traduzidas literalmente do inglês

Se algum item falhar, corrigir antes de declarar pronto.

---

## 10. CREDENCIAIS NECESSÁRIAS

Tabela de credenciais e onde cada uma é usada no pipeline.

| Credencial | Uso |
|---|---|
| `GITHUB_TOKEN` | Criar repo privado (Etapa 5 Passo 3), push do código (Passo 4) |
| `VERCEL_TOKEN` | Criar projeto Vercel (Passo 5), adicionar domínio (Passo 6), disparar deploy (Passo 8) |
| `VERCEL_TEAM_ID` | `team_l6zSw1lZTlfHqKRIe38paQxY` (ID do time, usar em todas as chamadas Vercel API) |
| `CLOUDFLARE_API_TOKEN` | Criar registro CNAME pra subdomínio (Passo 7) |
| `CLOUDFLARE_ZONE_ID` | Zone ID do domínio raiz (`seudominio.com.br` ou `seudominio.com.br`) usado no Passo 7 |
| `GOOGLE_AI_API_KEY` | Geração de imagens via nano-banana-pro (Etapa 2) |

### Onde estão armazenadas

- Em `/opt/seu-projeto/.env` (carregadas como variáveis de ambiente quando o agente inicia)
- Backup criptografado em `claude-token.env`

### Comandos pra checar se estão presentes

```bash
echo "GITHUB_TOKEN: ${GITHUB_TOKEN:+definida}"
echo "VERCEL_TOKEN: ${VERCEL_TOKEN:+definida}"
echo "CLOUDFLARE_API_TOKEN: ${CLOUDFLARE_API_TOKEN:+definida}"
echo "GOOGLE_AI_API_KEY: ${GOOGLE_AI_API_KEY:+definida}"
```

Se alguma estiver vazia, pedir pro dono ou pegar de `/opt/seu-projeto/.env`.

---

## 11. NOTAS FINAIS PARA O AGENTE QUE FOR USAR ESTE DOCUMENTO

Você é um agente especialista em criação de apresentações de slides Reveal.js + GSAP. Suas regras de operação:

1. **Antes de gerar imagem ou codar, planeje em texto.** Roteiro card a card aprovado pelo dono (ou cliente). Submeta para revisão antes de avançar.
2. **Aguarde OK explícito.** Sem aprovação do roteiro, não gere imagens. Sem aprovação das imagens, não monte HTML.
3. **Use single-file `index.html`.** Não fragmente CSS/JS em arquivos separados a menos que o arquivo passe de 200KB.
4. **Reuse os componentes da Etapa 4 e da seção 4 (Design System) sem reinventar.** A biblioteca de componentes já está pronta. Sua função é montar, não redesenhar.
5. **Teste local primeiro.** Abra o HTML no navegador antes de fazer push. Se quebrou local, vai quebrar em produção também.
6. **Siga o workflow da Etapa 5 na ordem.** Pular passos custa horas de debug. O passo 8 (deploy manual via API) é OBRIGATÓRIO na primeira vez. Sem ele, o webhook do Vercel não conecta no repo.
7. **Reporte para a Orquestradora (orquestradora) ao final** com URL no ar, URL do repo, tempo total, qualquer pendência. Não reporte direto pro dono.
8. **Use português brasileiro 100% do tempo** com acentuação completa. Sem exceções.
9. **Sem travessões. Em hipótese alguma.** Vírgula, ponto, quebra de linha. Sempre.
10. **Tipografia 2 a 3x maior que parece "normal"** em telas web. Bullets, cards, sub-headings. O dono lê em telas grandes.
11. **Texto SOMENTE na metade direita** quando o slide tem layout 50/50 com personagens. Nunca invade a metade esquerda.
12. **Atualize este documento** quando descobrir um padrão novo, componente novo, ou regra nova durante a produção. Outros agentes vão herdar seu aprendizado.

Pronto. Boa entrega.
