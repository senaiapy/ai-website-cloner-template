# Método de Análise BMAD de Instagram + Oferta

Documento autossuficiente para treinar agente especializado em análise estratégica de perfis Instagram, montagem de oferta, plano de crescimento de 30 dias e deploy automático de site de diagnóstico. O agente que ler APENAS esse arquivo deve conseguir executar o método inteiro do zero.

---

## 1. VISÃO GERAL E PROPÓSITO

### O que é BMAD

BMAD é um framework próprio (referência interna MIT) com 4 pilares de análise estratégica de perfil Instagram:

- **B (Brand)**: marca, identidade, arquétipo, tom de voz, pilares de comunicação, diferencial competitivo, gaps de marca.
- **M (Market)**: nicho, sub-nicho, tamanho de mercado, concorrência, posicionamento, tendências, oportunidades, benchmarks do nicho.
- **A (Audit)**: auditoria de performance, autenticidade (compra de seguidores), tipos de conteúdo, gargalos de crescimento, pontos fortes e fracos.
- **D (Direction)**: estratégia central, quick wins, plano 90 dias em 3 fases, estratégia de conteúdo (mix, temas, hooks), monetização básica.

Cada pilar recebe score 0-100. O BMAD Total é a média dos 4.

### Por que esse framework

Junta diagnóstico (B+M+A) com prescrição (D) num único output estruturado. Diferente de consultoria solta, é determinístico, replicável, e gera dados estruturados em JSON pra alimentar outros sistemas (SDR IA, automação de tráfego, geração de conteúdo).

### O que o agente entrega no fim

1. Site dark mode em USERNAME.seudominio.com.br com 7-8 abas navegáveis (B, M, A, D, Monetização, Plano 90 dias, Plano 30 dias, opcionalmente Resumo Executivo).
2. Dossiê markdown completo com a análise (pode virar base de treinamento de SDR depois).
3. Dados estruturados em JSON (BMAD core, monetização, plano 30 dias) salvos localmente.
4. Registro no PostgreSQL pra histórico e busca semântica.

### Tempo médio

2 a 4 minutos por perfil (numa execução limpa, sem retries de API).

### Limites operacionais

- Máximo 3 perfis por hora (proteção da conta Instagram autenticada).
- Máximo 30 perfis por dia.
- Perfis privados só funcionam se a conta autenticada (@seudominio.com.br) já segue o alvo.
- Não rodar simultaneamente mais de 1 análise pelo mesmo usuário Instaloader.

---

## 2. STACK NECESSÁRIA

### Linguagem e bibliotecas

- Python 3.10 ou superior.
- Pacotes Python: `instaloader`, `requests`, `psycopg2-binary`, `google-generativeai`.

### IA generativa

- Gemini API (Google AI Studio Key).
- Modelo: `gemini-3.1-pro-preview` (modelo com janela longa e raciocínio bom para análise estratégica).
- Configuração: temperature 0.7 nas 3 chamadas, max output tokens 8192.

### Deploy

- Vercel CLI instalado globalmente (`npm i -g vercel`).
- Vercel Token + Org ID (vinculado ao email usuario@exemplo.com).
- Cloudflare API Token + Zone ID (zona seudominio.com.br).

### Coleta de dados

- Instaloader instalado.
- Sessão Instagram autenticada (@seudominio.com.br) salva em `/root/.config/instaloader/session-seudominio.com.br`. Sessão pré-logada permite buscar perfis privados que a conta segue.

### Armazenamento

- PostgreSQL com extensão pgvector. Banco `naia_memory`. Tabela `memory_chunks` (com colunas `content`, `metadata jsonb`, `source`, `created_at`).
- Diretório local: `/root/.openclaw/workspace/projeto/` para `.html` e `.json`.

---

## 3. PIPELINE DAS 10 ETAPAS

### ETAPA 1, COLETA DE DADOS DO PERFIL

**Ferramenta**: Instaloader.

**Objetivo**: pegar metadados do perfil + 12 posts mais recentes.

**Dados coletados**:

- Username, full_name, biography, followers, followees, mediacount.
- is_verified, is_business_account, business_category_name.
- profile_pic_url.
- external_url (link da bio).
- 12 posts mais recentes com: shortcode, likes, comments, is_video, video_view_count (se vídeo), date_local, caption (200 chars).

**Exemplo de código Python**:

```python
import instaloader

L = instaloader.Instaloader()
L.load_session_from_file("seudominio.com.br", "/root/.config/instaloader/session-seudominio.com.br")

profile = instaloader.Profile.from_username(L.context, username)

dados_perfil = {
    "username": profile.username,
    "full_name": profile.full_name,
    "bio": profile.biography,
    "followers": profile.followers,
    "following": profile.followees,
    "posts_total": profile.mediacount,
    "verificado": profile.is_verified,
    "business": profile.is_business_account,
    "categoria": profile.business_category_name,
    "external_url": profile.external_url,
    "is_private": profile.is_private,
}

posts = []
for i, post in enumerate(profile.get_posts()):
    if i >= 12:
        break
    posts.append({
        "shortcode": post.shortcode,
        "likes": post.likes,
        "comments": post.comments,
        "is_video": post.is_video,
        "views": post.video_view_count if post.is_video else None,
        "date": post.date_local.isoformat(),
        "caption": (post.caption or "")[:200],
    })

dados_perfil["posts"] = posts
```

**Tratamento de privados**: se `profile.is_private` e a conta autenticada não segue, marcar `dados_perfil["limited"] = True` e seguir com dados parciais (sem posts).

**Tratamento de erros**: se Instaloader retornar 401 ou 429, esperar 60s e tentar novamente. Se falhar 3 vezes, abortar e notificar.

---

### ETAPA 2, SCORE DE AUTENTICIDADE (COMPRA DE SEGUIDORES)

**Cálculo local, sem API externa**. Score de 0 (totalmente orgânico) a 100 (alta probabilidade de compra).

**Indicador 1, Taxa de engajamento vs benchmark por faixa**:

| Faixa de seguidores | Engajamento esperado |
|---|---|
| Menos de 10K | 4 a 8 por cento |
| 10K a 100K | 2 a 4 por cento |
| 100K a 1M | 1 a 2 por cento |
| Mais de 1M | 0,5 a 1 por cento |

Cálculo da taxa:

```
engajamento_atual = (média_likes_últimos_12 + média_comments_últimos_12) / followers * 100
```

Pontuação:
- Se engajamento atual menor que 30 por cento do mínimo esperado da faixa, somar **40 pontos**.
- Se engajamento atual menor que 60 por cento do mínimo esperado, somar **20 pontos**.

**Indicador 2, Coeficiente de variação das curtidas (mínimo 4 posts)**:

```
CV = desvio_padrão_likes / média_likes
```

Pontuação:
- CV maior que 2,5, somar **25 pontos** (picos artificiais).
- CV maior que 1,5, somar **10 pontos** (inconsistência).

**Indicador 3, Proporção seguidores/seguindo**:
- Se ratio (followers/following) maior que 50 e perfil tem mais de 50K seguidores, somar **10 pontos**.

**Indicador 4, Média de likes vs seguidores**:
- Se média de likes menor que 0,2 por cento dos seguidores e perfil tem mais de 10K, somar **15 pontos**.

**Score final**: soma dos pontos, capeado em 100.

**Veredicto**:

| Faixa de score | Veredicto |
|---|---|
| 0 a 30 | LIMPO (orgânico) |
| 31 a 60 | SUSPEITO |
| 61 a 100 | ALTA PROBABILIDADE DE COMPRA |

**Output desta etapa**: dict com `score_autenticidade` (int), `veredicto` (string) e `indicadores_detalhados` (dict com cada cálculo, pra usar na análise BMAD).

---

### ETAPA 3, ANÁLISE BMAD COM GEMINI (PRIMEIRA CHAMADA)

**Modelo**: gemini-3.1-pro-preview, temperature 0.7, max_tokens 8192.

**Input**: dados do perfil (etapa 1) + score de autenticidade (etapa 2).

**Output esperado**: JSON estruturado com 4 pilares (B, M, A, D), cada um com score 0-100, mais resumo executivo e conclusão estratégica.

**Estrutura B (Brand)**:
- score (0-100), identidade, arquétipo (Herói/Sábio/Criador/Mago/Inocente/Explorador/Cuidador/Rebelde/Amante/Bobo/Governante/Cara_Comum), 3 pilares de comunicação, tom de voz, consistência visual (Alta/Média/Baixa), diferencial competitivo, 3 gaps de marca.

**Estrutura M (Market)**:
- score, nicho, sub_nicho, tamanho_mercado_brasil, nivel_concorrencia, posicionamento (líder/seguidor/nicho), 3 tendencias_relevantes, 3 oportunidades_mercado, benchmarks_nicho (engajamento_ideal, frequencia_posts_semanal, formatos_dominantes, horarios_pico).

**Estrutura A (Audit)**:
- score, performance_geral, avaliacao_engajamento, autenticidade (integra score etapa 2 + explicação), auditoria_conteudo (tipos, qualidade_producao, frequencia_atual, consistencia_temas), 3 gargalos_crescimento, 3 pontos_fortes, 3 pontos_fracos.

**Estrutura D (Direction)**:
- score, estrategia_central (2-3 frases), quick_wins (lista com acao, impacto_esperado, passo_a_passo), plano_90_dias (3 fases: 30/60/90, cada com objetivo, 5 acoes, kpis, meta_seguidores), estrategia_conteudo (pilares, mix_formatos_pct, temas_por_dia_semana, hooks_recomendados), monetizacao_basica (potencial, modelo_primario, modelo_secundario, produto_ideal, faixa_preco, ticket_medio, canais_venda, tempo_para_monetizar).

**BMAD Total**: média aritmética dos 4 scores.

**Outputs adicionais**: `resumo_executivo` (3-5 frases) e `conclusao_estrategica` (3 movimentos urgentes).

(Prompt completo dessa chamada está na seção 4.1, com placeholders prontos pra preencher.)

---

### ETAPA 4, NAVEGAÇÃO DO LINK DA BIO

**Ferramenta**: requests (HTTP) + parser HTML simples (BeautifulSoup ou regex).

**Objetivo**: mapear produtos/ofertas existentes acessíveis pelo link da bio.

**Procedimento**:

1. Pegar `external_url` do perfil.
2. Fazer GET com User-Agent de browser real (Mozilla/5.0...).
3. Se for página tipo Linktree, Beacons, Stan Store, Gumroad: extrair todos os links externos (até 20).
4. Coletar até 30 trechos de texto visível (h1, h2, p, button, span).
5. Se algum link aponta para Hotmart, Eduzz, Kiwify, Monetizze: marcar como produto e extrair título.

**Output**: `dados_bio = { "links": [...], "textos": [...], "produtos_detectados": [...] }`.

**Tratamento de erros**: timeout 15s. Se falhar, seguir com `dados_bio = None` e a etapa 5 trabalha sem essa info.

---

### ETAPA 5, MONETIZAÇÃO TURBINADA (SEGUNDA CHAMADA GEMINI)

**Modelo**: gemini-3.1-pro-preview, temperature 0.7, max_tokens 8192.

**Input**: dados do perfil + análise BMAD completa (etapa 3) + dados_bio (etapa 4).

**Output esperado**: JSON com escada de valor, recorrência, projeção de faturamento, stack tech.

**Estrutura escada_valor (4 níveis mínimos)**:

Para cada produto:
- nome, status (existente/sugerido), faixa_preco, publico_alvo, proposta_valor.
- funis (lista, 2 a 3 por produto):
  - tipo (Tráfego_Direto / Lançamento_Semente / Lançamento_Interno / Webinário_Gravado / VSL / Desafio / Perpétuo / Isca_Digital).
  - descricao_funcionamento, 4 etapas_funil, metricas (conversao_pct, cac_brl, roas), investimento_trafego_mensal_brl.
- precisa_sdr_ia (true/false), precisa_closer_humano (true/false), stack_tech_necessario (lista).

**Estrutura recorrencia_mrr**:
- modelo (clube, comunidade, mentoria recorrente, curso por assinatura, etc), produtos_recorrentes, ticket_medio_brl.

**Estrutura projecao_faturamento**:
- conservador (mensal_brl, anual_brl, premissas).
- moderado (mensal_brl, anual_brl, premissas).
- agressivo (mensal_brl, anual_brl, premissas).

**Estrutura stack_tecnologico**:
- lista de itens com categoria, ferramenta, motivo.

**Output adicional**: `insight_estrategico` (frase única, matadora).

(Prompt completo na seção 4.2.)

---

### ETAPA 6, PLANO DE AÇÃO 30 DIAS (TERCEIRA CHAMADA GEMINI)

**Modelo**: gemini-3.1-pro-preview, temperature 0.7, max_tokens 8192.

**Input**: dados do perfil + análise BMAD + monetização.

**Meta padrão**: crescimento de **10 por cento de seguidores em 30 dias**.

**REGRA INVIOLÁVEL**: meta padrão é crescimento de seguidores. Foco em vendas/faturamento só quando o usuário do método pedir explicitamente. Nunca trocar o padrão sem ordem direta.

**Output esperado**: JSON com calendário detalhado dia a dia.

**Estrutura**:

1. **estrategia_geral**: diagnostico_rapido, 3 alavancas_principais, orcamento_trafego_brl, kpis_semanais.

2. **calendario_semanal** (4 semanas, semana 1 a 4). Cada semana:
   - tema_central, meta_seguidores_semana.
   - dias (seg, ter, qua, qui, sex, sab, dom). Cada dia:
     - formato (Reel / Carrossel / Story / Feed / Live).
     - hook (primeira frase de impacto).
     - conteudo (descrição do que postar).
     - cta (chamada pra ação).
     - hashtags (lista com 6 ou mais).
     - horario_ideal.
     - inspiracao_referencia (perfil ou tipo de post a se inspirar).
   - stories_diarios_semana (5 a 10 ideias).
   - growth_hack_semana.

   Total: 28 dias preenchidos no mínimo.

3. **estrategia_reels**: 3 formatos_virais_recomendados, roteiros_resumidos (1 por semana), dicas_edicao, duracao_ideal.

4. **trafego_pago**: investimento_semanal_brl, tipo_campanha, publicos_alvo, posts_para_impulsionar.

5. **collabs**: 5 perfis_ideais (com nome ou nicho), formato_collab, como_abordar.

6. **metricas**: kpis_diarios, checkpoints_semanais, plano_b (se 14 dias sem crescimento esperado).

(Prompt completo na seção 4.3.)

---

### ETAPA 7, GERAÇÃO DO SITE HTML

**Layout**: dark mode premium, glassmorphism, 7 a 8 abas navegáveis.

**Estrutura geral do HTML**:

```
<header>
  Avatar com inicial do username
  @username
  Badges: verificado, business, veredicto autenticidade
  Data da análise + modelo (Gemini 3.1 Pro)
</header>

<section class="bmad-bar">
  4 cards: B score, M score, A score, D score
  1 card destacado: BMAD Total
</section>

<section class="stats-bar">
  Seguidores, Seguindo, Posts, Engajamento, Média Likes, Performance Geral
</section>

<nav class="tabs">
  Botões pra cada aba
</nav>

<main>
  Conteúdo de cada aba (escondidas por default, mostrar com JS)
</main>
```

**Abas obrigatórias**:

1. **B, Brand**: resumo executivo, identidade, arquétipo, tom de voz, 3 pilares, diferencial, 3 gaps.
2. **M, Market**: nicho, sub-nicho, concorrência, posicionamento, 3 tendências, 3 oportunidades, benchmarks.
3. **A, Audit**: bloco autenticidade com barra visual 0-100, 3 pontos fortes, 3 pontos fracos, 3 gargalos, auditoria de conteúdo.
4. **D, Direction**: estratégia central, quick wins, estratégia de conteúdo (mix, temas, hooks), conclusão estratégica.
5. **Monetização**: escada de valor com cards expansíveis (funis dentro), recorrência, projeção (3 cenários), stack tech, insight estratégico.
6. **Plano 90 dias**: 3 fases (30/60/90), cada uma com objetivo, ações, KPIs, meta seguidores.
7. **Plano 30 dias**: calendário visual semana 1 a 4, com cada dia em card, mais reels, tráfego, collabs, métricas.
8. (opcional) **Resumo Executivo**: aba inicial com diagnóstico geral em 3-5 parágrafos.

**Design tokens**:

- Background base: `#07070f`.
- Background cards: `#0e0e1a` com borda `rgba(255,255,255,0.08)`.
- Cor B (Brand): `#6366f1` (indigo).
- Cor M (Market): `#a855f7` (purple).
- Cor A (Audit): `#3b82f6` (blue).
- Cor D (Direction): `#10b981` (green).
- Texto principal: `#e8e8f0`.
- Texto secundário: `#a0a0b0`.
- Acento: `#fbbf24` (gold) pra BMAD Total e CTAs.
- Tipografia: Inter ou system-ui, 16px base, headings com `font-weight: 700`.
- Cards: `border-radius: 12px`, `padding: 24px`, `backdrop-filter: blur(8px)`.
- Transições: 200ms ease nos hovers.

**JavaScript**: navegação simples entre abas via troca de classe `active`. Sem framework, vanilla JS.

**Responsividade**: media query em 768px. Em mobile, abas viram dropdown ou scroll horizontal.

**Geração**: o HTML é montado via template string em Python (f-string) ou template engine simples. Salvar em `/tmp/USERNAME.html` antes do deploy.

---

### ETAPA 8, DEPLOY VERCEL + CLOUDFLARE

**Procedimento**:

1. **Vercel deploy file-based** (sem GitHub):

```bash
cd /tmp/build-USERNAME
mv USERNAME.html index.html
echo '{"version": 2}' > vercel.json
vercel deploy --prod --yes --token=$VERCEL_TOKEN --scope=$VERCEL_ORG_ID --name=ig-USERNAME
```

Vercel retorna URL temporária `ig-USERNAME-xxxx.vercel.app`.

2. **Cloudflare DNS, criar CNAME**:

```bash
curl -X POST "https://api.cloudflare.com/client/v4/zones/$CF_ZONE_ID/dns_records" \
  -H "Authorization: Bearer $CF_TOKEN" \
  -H "Content-Type: application/json" \
  --data '{
    "type": "CNAME",
    "name": "USERNAME",
    "content": "cname.vercel-dns.com",
    "proxied": true,
    "ttl": 1
  }'
```

Atenção: nessa pipeline, `proxied=true` é OK (diferente das landing pages que ficam `proxied=false` pra Vercel funcionar bem com SSL). Para análises BMAD, proxied ON dá performance e proteção bot extra.

3. **Vercel alias**:

```bash
vercel alias set ig-USERNAME-xxxx.vercel.app USERNAME.seudominio.com.br --token=$VERCEL_TOKEN --scope=$VERCEL_ORG_ID
```

4. **Validação**: aguardar 30s e fazer `curl -I https://USERNAME.seudominio.com.br`. Se retornar 200, deploy ok. Se retornar 404 ou 526, esperar mais 30s e retentar.

**Resultado**: site permanente em `https://USERNAME.seudominio.com.br`.

---

### ETAPA 9, SALVAR NO POSTGRESQL

**Banco**: `naia_memory`. **Tabela**: `memory_chunks`.

**Conteúdo a salvar** (texto pra busca semântica):

```
Análise BMAD de @USERNAME concluída em DATA.
Seguidores: NNN. Engajamento: XX por cento. Autenticidade: VEREDICTO (score Y).
BMAD Total: Z/100. B=A, M=B, A=C, D=D.
Diferencial: ...
Insight estratégico: ...
URL do diagnóstico: https://USERNAME.seudominio.com.br.
```

**Metadado JSONB**: `{"username": "USERNAME", "bmad_total": Z, "veredicto_autenticidade": "...", "url": "...", "data_analise": "..."}`.

**Source**: `instagram-analyzer-bmad`.

**Comando SQL**:

```sql
INSERT INTO memory_chunks (content, metadata, source, created_at)
VALUES ($1, $2::jsonb, 'instagram-analyzer-bmad', NOW());
```

(Embedding é gerado por trigger automático ou job separado, não é responsabilidade dessa pipeline.)

---

### ETAPA 10, SALVAR ARQUIVOS LOCAIS

**Diretório**: `/root/.openclaw/workspace/projeto/`.

| Arquivo | Conteúdo |
|---|---|
| `USERNAME.html` | Site completo gerado na etapa 7 |
| `USERNAME-bmad.json` | Output bruto da chamada Gemini 1 (BMAD core) |
| `USERNAME-monetizacao.json` | Output bruto da chamada Gemini 2 (Monetização) |
| `USERNAME-plano30.json` | Output bruto da chamada Gemini 3 (Plano 30 dias) |
| `USERNAME-perfil.json` | Dados crus do Instaloader (etapa 1 + score etapa 2) |

Esses arquivos são a fonte de verdade. Se algo dá errado num passo posterior, dá pra reconstruir tudo a partir deles.

---

## 4. PROMPTS COMPLETOS DAS 3 CHAMADAS GEMINI

### 4.1, PROMPT 1, BMAD CORE

```
Você é um analista estratégico sênior de Instagram com 10 anos de experiência em consultoria
de marca pessoal e perfis de creators no Brasil. Recebeu os dados de um perfil pra fazer
análise BMAD completa (Brand, Market, Audit, Direction).

DADOS DO PERFIL:
{dados_perfil}

SCORE DE AUTENTICIDADE (calculado por algoritmo próprio):
Score: {score_autenticidade}/100
Veredicto: {veredicto}
Indicadores: {indicadores_detalhados}

INSTRUÇÕES:
Retorne APENAS um JSON válido, sem markdown, sem comentários, sem texto antes ou depois.
Use português brasileiro 100 por cento, sem travessões. Frases diretas.

ESTRUTURA DO JSON:
{
  "B_brand": {
    "score": int (0-100),
    "identidade": string,
    "arquétipo": "Herói" | "Sábio" | "Criador" | "Mago" | "Inocente" | "Explorador" | "Cuidador" | "Rebelde" | "Amante" | "Bobo" | "Governante" | "Cara_Comum",
    "pilares_comunicacao": [string, string, string],
    "tom_de_voz": string,
    "consistencia_visual": "Alta" | "Média" | "Baixa",
    "diferencial_competitivo": string,
    "gaps_marca": [string, string, string]
  },
  "M_market": {
    "score": int,
    "nicho": string,
    "sub_nicho": string,
    "tamanho_mercado_brasil": string,
    "nivel_concorrencia": "Alta" | "Média" | "Baixa",
    "posicionamento": "líder" | "seguidor" | "nicho",
    "tendencias_relevantes": [string, string, string],
    "oportunidades_mercado": [string, string, string],
    "benchmarks_nicho": {
      "engajamento_ideal_pct": float,
      "frequencia_posts_semanal": int,
      "formatos_dominantes": [string],
      "horarios_pico": [string]
    }
  },
  "A_audit": {
    "score": int,
    "performance_geral": "Excelente" | "Bom" | "Regular" | "Fraco",
    "avaliacao_engajamento": string,
    "autenticidade": {
      "score_calculado": int,
      "veredicto": string,
      "explicacao_detalhada": string
    },
    "auditoria_conteudo": {
      "tipos": [string],
      "qualidade_producao": string,
      "frequencia_atual": string,
      "consistencia_temas": string
    },
    "gargalos_crescimento": [string, string, string],
    "pontos_fortes": [string, string, string],
    "pontos_fracos": [string, string, string]
  },
  "D_direction": {
    "score": int,
    "estrategia_central": string,
    "quick_wins": [
      {"acao": string, "impacto_esperado": string, "passo_a_passo": [string]}
    ],
    "plano_90_dias": {
      "fase_30": {"objetivo": string, "acoes": [string × 5], "kpis": [string], "meta_seguidores": string},
      "fase_60": {"objetivo": string, "acoes": [string × 5], "kpis": [string], "meta_seguidores": string},
      "fase_90": {"objetivo": string, "acoes": [string × 5], "kpis": [string], "meta_seguidores": string}
    },
    "estrategia_conteudo": {
      "pilares": [string],
      "mix_formatos_pct": {"reels": int, "carrossel": int, "feed": int, "story": int},
      "temas_por_dia_semana": {"seg": string, "ter": string, "qua": string, "qui": string, "sex": string, "sab": string, "dom": string},
      "hooks_recomendados": [string × 5]
    },
    "monetizacao_basica": {
      "potencial": "Alto" | "Médio" | "Baixo",
      "modelo_primario": string,
      "modelo_secundario": string,
      "produto_ideal": string,
      "faixa_preco_brl": string,
      "ticket_medio_brl": int,
      "canais_venda": [string],
      "tempo_para_monetizar_meses": int
    }
  },
  "bmad_total": int (média de B, M, A, D),
  "resumo_executivo": string (3 a 5 frases, diagnóstico geral),
  "conclusao_estrategica": [string, string, string] (3 movimentos mais urgentes)
}

REGRAS:
- ZERO travessões em todo o conteúdo.
- Português brasileiro 100 por cento.
- Não inventar dados que não estão no input. Se não souber, escreva "dados insuficientes".
- Scores devem refletir realidade. Não inflar.
- Seja crítico mas construtivo.
```

---

### 4.2, PROMPT 2, MONETIZAÇÃO TURBINADA

```
Você é um estrategista de monetização digital especialista em creators e infoprodutores
no Brasil. Recebeu uma análise BMAD pronta de um perfil Instagram + os dados de produtos
existentes na bio. Agora vai turbinar a monetização.

DADOS DO PERFIL:
{dados_perfil}

ANÁLISE BMAD COMPLETA (output da chamada anterior):
{bmad_output}

PRODUTOS/LINKS DA BIO MAPEADOS:
{dados_bio}

INSTRUÇÕES:
Retorne APENAS um JSON válido, sem markdown, sem texto antes ou depois.
Use português brasileiro 100 por cento, sem travessões.

REGRAS DE NEGÓCIO OBRIGATÓRIAS:
1. Escada de valor deve ter NO MÍNIMO 4 níveis (front-end → mid-ticket → back-end → high-ticket).
2. Cada produto deve ter 2 ou 3 funis sugeridos (não menos).
3. Todo produto high-ticket (acima de R$ 2.000) DEVE marcar precisa_sdr_ia=true E precisa_closer_humano=true.
4. Produtos abaixo de R$ 500 podem rodar com tráfego direto puro.
5. Pelo menos 1 produto na escada deve ser SUGERIDO (não existente). Não copiar só o que já tem.
6. Projeção tem que ser realista: conservador, moderado, agressivo. Sem promessa irreal.

ESTRUTURA DO JSON:
{
  "escada_valor": [
    {
      "nivel": "front-end" | "mid-ticket" | "back-end" | "high-ticket",
      "nome_produto": string,
      "status": "existente" | "sugerido",
      "faixa_preco_brl": string,
      "publico_alvo": string,
      "proposta_valor": string,
      "funis": [
        {
          "tipo": "Tráfego_Direto" | "Lançamento_Semente" | "Lançamento_Interno" | "Webinário_Gravado" | "VSL" | "Desafio" | "Perpétuo" | "Isca_Digital",
          "descricao_funcionamento": string,
          "etapas_funil": [string × 4],
          "metricas_esperadas": {"conversao_pct": float, "cac_brl": int, "roas": float},
          "investimento_trafego_mensal_brl": int
        }
      ],
      "precisa_sdr_ia": bool,
      "precisa_closer_humano": bool,
      "stack_tech_necessario": [string]
    }
  ],
  "recorrencia_mrr": {
    "modelo": string,
    "produtos_recorrentes": [string],
    "ticket_medio_brl": int
  },
  "projecao_faturamento": {
    "conservador": {"mensal_brl": int, "anual_brl": int, "premissas": string},
    "moderado": {"mensal_brl": int, "anual_brl": int, "premissas": string},
    "agressivo": {"mensal_brl": int, "anual_brl": int, "premissas": string}
  },
  "stack_tecnologico_recomendado": [
    {"categoria": string, "ferramenta": string, "motivo": string}
  ],
  "insight_estrategico": string (frase única matadora, alta densidade)
}
```

---

### 4.3, PROMPT 3, PLANO 30 DIAS

```
Você é um estrategista de conteúdo Instagram especialista em crescimento orgânico no Brasil.
Recebeu análise BMAD + monetização. Agora vai montar o plano de 30 dias detalhado.

DADOS DO PERFIL:
{dados_perfil}

ANÁLISE BMAD:
{bmad_output}

MONETIZAÇÃO:
{monetizacao_output}

META PADRÃO: crescimento de 10 por cento de seguidores em 30 dias.
OBJETIVO: aumentar a base e fortalecer a marca, não vender produtos diretamente.
Foco em conteúdo viral, autoridade, comunidade.

INSTRUÇÕES:
Retorne APENAS um JSON válido, sem markdown, sem texto antes ou depois.
Use português brasileiro 100 por cento, sem travessões.

REGRAS:
1. Calendário deve ter 28 dias preenchidos no mínimo (4 semanas completas).
2. Cada dia tem formato, hook, conteúdo, CTA, hashtags (mínimo 6), horário, inspiração.
3. Mix sugerido: 60 por cento Reels, 25 por cento Carrossel, 10 por cento Story (destaque), 5 por cento Live ou Feed.
4. Stories diários são adicionais ao post principal do dia.
5. Hooks devem ser específicos do nicho do perfil, não genéricos.
6. Investimento de tráfego deve ser realista pro tamanho atual do perfil.
7. Collabs sugeridas devem ser perfis reais ou perfis-tipo do nicho.

ESTRUTURA DO JSON:
{
  "estrategia_geral": {
    "diagnostico_rapido": string,
    "alavancas_principais": [string × 3],
    "orcamento_trafego_mensal_brl": int,
    "kpis_semanais": [string]
  },
  "calendario_semanal": {
    "semana_1": {
      "tema_central": string,
      "meta_seguidores_semana": string,
      "dias": {
        "seg": {"formato": string, "hook": string, "conteudo": string, "cta": string, "hashtags": [string × 6+], "horario_ideal": string, "inspiracao": string},
        "ter": {...},
        "qua": {...},
        "qui": {...},
        "sex": {...},
        "sab": {...},
        "dom": {...}
      },
      "stories_diarios_semana": [string × 5+],
      "growth_hack_semana": string
    },
    "semana_2": {... mesma estrutura ...},
    "semana_3": {... mesma estrutura ...},
    "semana_4": {... mesma estrutura ...}
  },
  "estrategia_reels": {
    "formatos_virais": [string × 3],
    "roteiros_resumidos": [
      {"semana": int, "titulo": string, "roteiro": string}
    ],
    "dicas_edicao": [string],
    "duracao_ideal_segundos": "string (ex: 7-15 ou 30-60)"
  },
  "trafego_pago": {
    "investimento_semanal_brl": int,
    "tipo_campanha": string,
    "publicos_alvo": [string],
    "posts_para_impulsionar": [string]
  },
  "collabs": {
    "perfis_ideais": [
      {"nome_ou_nicho": string, "motivo": string}
    ] (mínimo 5),
    "formato_collab": string,
    "como_abordar": string
  },
  "metricas": {
    "kpis_diarios": [string],
    "checkpoints_semanais": [string],
    "plano_b_se_14_dias_sem_crescimento": string
  }
}
```

---

## 5. CHECKLIST DE QUALIDADE

Antes de entregar o resultado pro usuário/cliente, validar:

- [ ] Score de autenticidade calculado e exibido com veredicto.
- [ ] BMAD com 4 scores individuais (B, M, A, D) e BMAD Total (média).
- [ ] Resumo executivo presente com 3 a 5 frases.
- [ ] Conclusão estratégica com 3 movimentos urgentes.
- [ ] Escada de valor com pelo menos 4 níveis preenchidos.
- [ ] Cada produto da escada com 2 ou 3 funis (não menos).
- [ ] Produtos high-ticket marcados com precisa_sdr_ia=true.
- [ ] Projeção de faturamento com 3 cenários (conservador/moderado/agressivo).
- [ ] Plano 30 dias com calendário dia a dia, mínimo 28 dias preenchidos.
- [ ] Cada dia tem formato, hook, conteúdo, CTA, hashtags, horário, inspiração.
- [ ] Stories diários e growth hack semanal em cada uma das 4 semanas.
- [ ] Site responsivo, 7 a 8 abas funcionando, navegação JS sem travar.
- [ ] Deploy em USERNAME.seudominio.com.br retornando 200, com SSL ativo.
- [ ] Dados salvos em PostgreSQL (memory_chunks com source=instagram-analyzer-bmad).
- [ ] Arquivos .html e .json salvos em /root/.openclaw/workspace/projeto/.
- [ ] Zero travessões em todo o conteúdo gerado.
- [ ] Português brasileiro consistente.

Se algum item falhar, refazer o passo correspondente antes de entregar.

---

## 6. REGRAS INVIOLÁVEIS

1. **Meta padrão do plano 30 dias é +10 por cento de seguidores**. Foco em vendas só quando solicitado explicitamente. Não inverter sem ordem direta.
2. **Produtos high-ticket (acima de R$ 2.000) sempre marcam precisa_sdr_ia=true E precisa_closer_humano=true**. Não tem exceção.
3. **Cada produto na escada de valor deve ter 2 ou 3 funis sugeridos**. Não menos.
4. **Limites Instagram**: máximo 3 perfis por hora, 30 por dia. Estourar isso bana a conta autenticada.
5. **Perfis privados**: dados limitados, só funciona se @seudominio.com.br segue. Comunicar isso ao usuário se for o caso.
6. **Cloudflare DNS**: nessa pipeline, `proxied=true` é OK (proteção bot). Diferente da regra das landing pages Vercel onde fica `proxied=false`.
7. **ZERO travessões** em todo conteúdo gerado, em todos os JSONs, no HTML, no markdown. Usar vírgula, ponto, ou quebra de linha.
8. **Não inventar dados**. Se Gemini não tem informação suficiente, retornar "dados insuficientes" no campo. Não chutar números.
9. **Salvar tudo localmente antes do deploy**. Se Vercel falhar, dá pra reaproveitar HTML e JSONs.
10. **Não rodar análise simultânea do mesmo perfil em paralelo**. Um por vez por usuário Instaloader.

---

## 7. CASOS DE USO

### Cliente novo da consultoria
Oferecer análise BMAD como diagnóstico grátis de entrada. Lead vê o resultado, percebe valor, e abre porta pra vender consultoria, agente SDR, mentoria.

### Análise de concorrente
Rodar BMAD num concorrente direto pra mapear o que ele faz, gaps, oportunidades. Vira inteligência competitiva.

### Auditoria pré-tráfego
Antes de gastar dinheiro em ads pra um perfil, rodar BMAD pra saber se o ativo Instagram aguenta receber tráfego. Se score baixo, ajustar conteúdo antes.

### Treinamento de agente SDR
A análise BMAD vira a Fase 1 do método SDR CLAW (criação de agente SDR conectado ao seu CRM). O dossiê markdown serve de base de treinamento do agente. Sem BMAD, não dá pra criar SDR.

### Análise de portfólio
Rodar BMAD em vários perfis de um mesmo grupo (ex: time de creators de uma agência) e comparar scores. Vira benchmark interno.

---

## 8. INTEGRAÇÃO COM OUTROS PROCESSOS

### Método SDR CLAW (Instagram/WhatsApp)
A análise BMAD é a **Fase 1** do método SDR CLAW. Após análise, o expert pode contratar a continuação:

- Fase 2: Infraestrutura do agente.
- Fase 3: Criação do agente.
- Fase 4: Rede e SSL.
- Fase 5: Conexão com seu CRM.
- Fase 6: Tracking nas páginas de venda.
- Fase 7: Webhook de vendas.
- Fase 8: Tráfego pago (opcional).
- Fase 9: Validação e go-live.

A análise BMAD entrega:
- Dossiê completo do expert (quem é, números, nicho, produtos).
- Mapeamento de produtos com links da bio.
- Estratégia de comunicação (tom de voz, pilares).
- Escada de valor (qual produto pra qual lead).

Esses 4 outputs viram input direto da Fase 3 (criação do agente).

### Geração automática de conteúdo
O calendário do plano 30 dias pode alimentar outro agente especializado em geração de carrossel/reel. Cada dia do calendário vira briefing pra um content agent que gera as artes finais.

### Tráfego pago automatizado
A seção de "trafego_pago" do plano 30 dias pode alimentar um agente de gestão de Meta Ads. Briefing já pronto: investimento, tipo de campanha, públicos.

---

## 9. EXEMPLO DE EXECUÇÃO REAL

**Cenário**: usuário pede análise do perfil @marciabaraldi (consultora estética).

**Sequência**:

1. Agente recebe comando `analisar @marciabaraldi`.
2. Inicializa Instaloader com sessão @seudominio.com.br.
3. Coleta dados (etapa 1): 245K seguidores, 1.890 posts, business=true, categoria "Profissional de saúde".
4. Calcula score autenticidade (etapa 2): score 22 (LIMPO), engajamento 1,8 por cento (dentro do benchmark 100K-1M).
5. Chama Gemini com prompt 1 (etapa 3): retorna BMAD com B=78, M=82, A=71, D=74. Total=76. Resumo executivo destaca autoridade no nicho de estética avançada e gap de produto digital.
6. Navega link da bio (etapa 4): detecta Linktree com 8 links, sendo 3 cursos Hotmart já existentes.
7. Chama Gemini com prompt 2 (etapa 5): escada de valor com 5 níveis, sendo 3 existentes (cursos R$ 197 a R$ 497) e 2 sugeridos (mentoria R$ 5K + clube de assinatura R$ 47/mês). Projeção moderada: R$ 180K/mês.
8. Chama Gemini com prompt 3 (etapa 6): plano 30 dias com 28 dias preenchidos, meta de +24K seguidores em 30 dias, orçamento de tráfego R$ 2K/semana.
9. Gera HTML (etapa 7): site dark mode com 7 abas, BMAD bar destacando 76/100.
10. Deploy Vercel + Cloudflare (etapa 8): URL final `https://marciabaraldi.seudominio.com.br`.
11. Salva no Postgres (etapa 9) e arquivos locais (etapa 10).
12. Retorna pro usuário: URL + resumo executivo + 3 movimentos urgentes.

**Tempo total**: 3 minutos e 12 segundos.

---

## 10. CREDENCIAIS NECESSÁRIAS

| Credencial | Onde obter | Uso na pipeline |
|---|---|---|
| Google AI Key | aistudio.google.com | Chamadas Gemini (etapas 3, 5, 6) |
| Vercel Token | vercel.com/account/tokens | Deploy do site (etapa 8) |
| Vercel Org ID | dashboard Vercel, settings | Deploy do site (etapa 8) |
| Cloudflare API Token | dash.cloudflare.com/profile/api-tokens, escopo Zone:DNS:Edit | DNS CNAME (etapa 8) |
| Cloudflare Zone ID | dashboard Cloudflare, overview da zona seudominio.com.br | DNS CNAME (etapa 8) |
| Sessão Instagram @seudominio.com.br | login interativo Instaloader uma vez, salvo em /root/.config/instaloader/session-seudominio.com.br | Coleta de dados (etapa 1) |
| PostgreSQL credentials | banco naia_memory, user e senha do servidor | Persistência (etapa 9) |

Variáveis de ambiente sugeridas:

```
GOOGLE_AI_KEY=...
VERCEL_TOKEN=...
VERCEL_ORG_ID=...
CF_TOKEN=...
CF_ZONE_ID=...
PG_CONN_STRING=postgres://...
```

---

## 11. ANEXO, FLUXO RESUMIDO VISUAL

```
@USERNAME recebido
    ↓
Etapa 1, Coleta perfil (instaloader) → seguidores, posts, bio
    ↓
Etapa 2, Score autenticidade (cálculo local) → 0-100, veredicto
    ↓
Etapa 3, Análise BMAD (Gemini chamada 1) → 4 pilares + scores + resumo
    ↓
Etapa 4, Navegar link da bio (requests) → mapear produtos
    ↓
Etapa 5, Monetização turbinada (Gemini chamada 2) → escada de valor + funis + projeção
    ↓
Etapa 6, Plano 30 dias (Gemini chamada 3) → calendário completo + reels + collabs
    ↓
Etapa 7, Gerar HTML → site dark mode com 7-8 abas
    ↓
Etapa 8, Deploy (Vercel + Cloudflare) → USERNAME.seudominio.com.br
    ↓
Etapa 9, Salvar no PostgreSQL → memória permanente
    ↓
Etapa 10, Salvar arquivos locais → .html + .json + .md
    ↓
PRONTO, entregar URL + resumo executivo
```

---

## 12. TROUBLESHOOTING COMUM

**Problema**: Instaloader retorna 401 (Unauthorized).
**Causa**: sessão expirada.
**Fix**: rodar `instaloader --login=seudominio.com.br` interativamente uma vez pra renovar.

**Problema**: Instaloader retorna 429 (Too Many Requests).
**Causa**: estourou limite (mais de 3/hora).
**Fix**: aguardar 15 minutos. Se persistir, rotacionar IP ou aguardar 1 hora.

**Problema**: Gemini retorna JSON inválido.
**Causa**: temperature alta ou prompt confuso.
**Fix**: re-prompt com `Retorne APENAS JSON válido, sem markdown, sem comentários`. Se falhar 2 vezes, baixar temperature pra 0.3.

**Problema**: Vercel deploy falha com erro 401.
**Causa**: Token Vercel expirado ou Org ID errado.
**Fix**: verificar VERCEL_TOKEN e VERCEL_ORG_ID. Vercel Org ID dessa conta é vinculado ao email usuario@exemplo.com.

**Problema**: Cloudflare DNS retorna 81057 (record já existe).
**Causa**: registro de USERNAME já existe pra outro projeto.
**Fix**: deletar registro antigo (DELETE na API) ou usar nome alternativo (USERNAME-bmad).

**Problema**: site retorna 526 (SSL handshake fail).
**Causa**: cert SSL Vercel ainda não propagou.
**Fix**: aguardar 60s e retentar. Se persistir após 5 min, verificar se alias Vercel apontou correto.

**Problema**: PostgreSQL insert falha com erro de tipo.
**Causa**: metadata JSONB malformado.
**Fix**: validar metadata com `json.dumps()` antes do insert. Conferir aspas duplas.

---

*Documento autossuficiente gerado para treinamento de agente especializado em análise BMAD de Instagram. Última revisão pra padrão atual de pipeline com 10 etapas, 3 chamadas Gemini, deploy Vercel + Cloudflare proxied=ON.*
