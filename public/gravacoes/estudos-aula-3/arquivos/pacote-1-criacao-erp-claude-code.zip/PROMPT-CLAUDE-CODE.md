# Prompt · construir a fase 1 do ERP modular

Cole no Claude Code, na raiz da pasta onde este pacote foi descompactado. Preencha os campos entre colchetes.

---

Aciona a skill `loop-mestre-erp-modular` (está em `.claude/skills/`) e constrói, do zero, a fase 1 de um ERP modular multi-tenant chamado [NOME DO SISTEMA], no domínio [subdominio.seudominio.com], para o cliente [NOME DO CLIENTE], nicho [clínica | escritório | restaurante | loja | agência | outro].

## Fontes do escopo (leia todas antes de começar)

1. `specs/ESPECIFICACAO-ITEM-A-ITEM.md` · o que será construído, item por item. É a fonte da verdade do escopo.
2. `specs/CATALOGO-MODULOS.md` · módulos, abas, dependências e perfis por nicho.
3. `specs/INTEGRACOES-API-MCP.md` · o módulo Integrações, construído exatamente como está lá.
4. `docs/MANUAL-CONSTRUCAO-ERP-MODULAR.md` · as nove camadas e a organização de código.

## Como trabalhar

- Siga o passo a passo da skill: pergunta zero, entrevista dos módulos iniciais, spec, arquitetura, build (esqueleto andante, núcleo à mão, receita de módulo, um agente por módulo), review em quatro lentes e entrega.
- Copie todos os códigos de item da especificação para `docs/LOOP-STATE.md` e mantenha o estado de cada um (pendente, feito, verificado).
- Construa só os módulos padrão escolhidos na entrevista e gravados em `specs/modulos.json`. Os opcionais NÃO entram nesta fase; se eu pedir algum, anote em `opcionais_desejados` para o pacote 2.
- Stack fixa: Node 22, TypeScript, Fastify com OpenAPI, PostgreSQL 16 com RLS e pgvector, Redis com BullMQ e outbox, React com Vite, Caddy, systemd, segredos no cofre, repositório privado no GitHub antes da primeira linha.
- Padrão visual fixo da especificação (itens F1 a F10): tema escuro padrão, acento rosa, sidebar só com menus principais, submenus como abas, zero gradiente, zero emoji, zero travessão, pt, en e es.

## Definição de concluído

A fase 1 só termina com as provas P1 a P13 da especificação verdes e reportadas com evidência. Ao final, me diga que o pacote 2 (módulos opcionais) já pode ser aplicado.

Comece pela pergunta zero. Não me pergunte nada que já esteja escrito nestes arquivos.
