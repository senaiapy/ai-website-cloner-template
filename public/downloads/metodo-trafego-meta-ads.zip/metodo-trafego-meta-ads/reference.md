# reference.md — Tráfego pago Meta Ads (documentação oficial + mapa do MCP)

> Memória de gestor de tráfego oficial. Documentação oficial da Meta + os 29 tools do MCP oficial + workflows + anti-patterns. A Naia consulta isto pra operar campanhas.

## 0. Documentação oficial da Meta (fontes)
- **Meta Ads AI Connectors** (o produto: MCP server + CLI, beta aberto desde 29/04/2026): https://www.facebook.com/business/news/meta-ads-ai-connectors
- **Como gerenciar anúncios de um agente de IA** (help center oficial): https://www.facebook.com/business/help/1456422242197840
- **Marketing API** (documentação de desenvolvedor): https://developers.facebook.com/docs/marketing-api/
- **Criação básica de anúncio**: https://developers.facebook.com/docs/marketing-api/get-started/basic-ad-creation/
- **MCP oficial (endpoint):** `https://mcp.facebook.com/ads`

O conector é **autenticado pela Meta** (OAuth), sem developer credentials, sem API key, sem código. Cobre Facebook + Instagram Ads (não cobre Google/LinkedIn/TikTok). ~200 chamadas/hora por conta de anúncios. Acesso de ESCRITA total (sem rascunho/undo/confirmação): a Naia confirma com o dono antes de ativar/gastar.

## 1. Estrutura oficial de uma campanha (Marketing API)
Hierarquia: **Campanha → Conjunto de anúncios (ad set) → Anúncio (ad) → Criativo**.
- **Campanha:** define o objetivo (ODAX) e, se CBO, o orçamento. Objetivos ODAX: `OUTCOME_AWARENESS`, `OUTCOME_TRAFFIC`, `OUTCOME_ENGAGEMENT`, `OUTCOME_LEADS`, `OUTCOME_SALES`, `OUTCOME_APP_PROMOTION`. Nunca usar objetivo legado (LINK_CLICKS, BRAND_AWARENESS, etc.).
- **Ad set:** público (targeting), posicionamentos, agenda, e o orçamento se ABO. `promoted_object` com `pixel_id` é OBRIGATÓRIO pra `OUTCOME_SALES` + site. CBO (budget na campanha) e budget no ad set são mutuamente exclusivos.
- **Ad:** liga o ad set ao criativo. Required: `ad_set_id`, `ad_name`, `creative`.
- **Criativo:** a peça (imagem/vídeo + texto). Precisa de `page_id` (Página do Facebook/Instagram).
- **IDs envolvidos:** conta de anúncios (`act_<id>`), Página (`page_id`), Pixel/Dataset (conversões). Tudo descoberto pelos tools de descoberta abaixo.

## 2. Os 29 tools do MCP oficial
**Descoberta:**
- `ads_get_ad_accounts` — lista contas (cada item tem `is_ads_mcp_enabled`; se false, NÃO usar).
- `ads_get_pages_for_business` — pega `page_id` pra montar o criativo.

**Criação (tudo nasce PAUSED; ativar é call separada COM confirmação do dono):**
- `ads_create_campaign` — objetivos ODAX. CBO se setar budget aqui; ABO se deixar vazio e setar no ad set.
- `ads_create_ad_set` — `promoted_object` com pixel obrigatório pra OUTCOME_SALES+WEBSITE.
- `ads_create_ad` — required: ad_set_id, ad_name, creative.
- `ads_update_entity` — modifica campaign/ad_set/ad. Pra pausar: `fields={"status":"PAUSED"}`.
- `ads_activate_entity` — PAUSED→ACTIVE. Hierarquia inteira precisa estar ativa pra entregar; ativar de cima pra baixo. SEMPRE com confirmação do dono.

**Reporting:**
- `ads_get_ad_entities` — leitura principal. Setar `level`, `fields` (incluir id+name), `filtering`, `sort`, `breakdowns`, `time_range`. Pra topo+fundo, 2 calls com sort invertido.

**Insights analíticos:**
- `ads_insights_advertiser_context` — overview business+funil (usar no início).
- `ads_insights_performance_trend` — série temporal CPC/CPM/CPR/ROAS/CTR/CVR.
- `ads_insights_anomaly_signal` — desvios (observação, não causa).
- `ads_insights_auction_ranking_benchmarks` — competitividade de leilão + audiência sobreposta.
- `ads_insights_industry_benchmark` — vs indústria.
- `ads_get_opportunity_score` — score 0-100 da conta. Recs por `opportunity_score_lift` (pontos). NUNCA atribuir a campanha.

**Diagnóstico:**
- `ads_get_errors` — só hard-stops de entrega (não performance/pacing).
- `ads_get_help_article` — help center da Meta pra conceitos/políticas.

**Catalog (precisa permissão `catalog_management`):**
- `ads_catalog_get_catalogs` (listar antes de criar — regra "one catalog"), `ads_catalog_create` (feed_url XOR items XOR feed_file_content base64), `ads_catalog_get_details`, `ads_catalog_get_diagnostics` (MUST_FIX vs OPPORTUNITY), `ads_catalog_get_feed_rules`, `ads_catalog_get_products` (filtro `retailer_id` = SKU alfanumérico), `ads_catalog_get_product_details` (só FBID numérico), `ads_catalog_get_product_sets`, `ads_catalog_get_product_set_products`, `ads_catalog_get_product_feed_details`.

**Datasets / Pixel / CAPI:**
- `ads_get_dataset_details` (config + status; flag last_fired_time velho), `ads_get_dataset_quality` (EMQ + match keys + freshness), `ads_get_dataset_stats` (lookback MÁX 28 dias; timestamps Unix string, não ISO).

## 3. Workflows típicos
- **Auditoria:** get_ad_accounts → get_opportunity_score → anomaly_signal → auction_ranking_benchmarks → industry_benchmark → get_errors.
- **Criar campanha SALES com pixel:** get_ad_accounts → get_pages_for_business → create_campaign(ABO, sem budget) → create_ad_set(promoted_object com pixel) → create_ad → revisar → (com OK do dono) activate_entity (campanha→ad set→ad em ordem).
- **Não-entrega:** get_ad_entities (filhos com 0 impressões) → get_errors → auction_ranking_benchmarks → dataset_quality+stats se for conversão.
- **Catálogo:** get_catalogs → get_details → get_diagnostics(MUST_FIX) → get_diagnostics(OPPORTUNITY) → product_feed_details + feed_rules.

## 4. Anti-patterns críticos
- Ativar/mudar budget sem confirmação do dono (gasta dinheiro real).
- Objetivo legado (só ODAX).
- CBO + budget no ad set (mutuamente exclusivo).
- OUTCOME_SALES+WEBSITE sem pixel no `promoted_object`.
- Atribuir Opportunity Score a campaign/ad set/ad (é nível de conta).
- Criar catálogo sem listar primeiro (perde signal).
- Confundir `retailer_id` (SKU alfanumérico) com FBID (numérico longo).
- Lookback >28d em dataset_stats / timestamp em ISO 8601 (é Unix string).
