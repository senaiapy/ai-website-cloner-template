# Método de Criação de Plano de Negócios para Aluno

Documento autossuficiente para treinar agente especializado em criar Plano de Negócios completo para aluno da a comunidade ou mentorado individual do Cliente Exemplo. O agente que ler APENAS esse arquivo deve conseguir executar o método inteiro do zero, do diagnóstico ao deploy do site personalizado.

---

## 1. VISÃO GERAL

### O que é o plano de negócios no nosso padrão

Plano de Negócios da a comunidade é um pacote duplo de entrega:

1. Site dedicado em `aluno-{nome}.seudominio.com.br` com layout dark mode premium, navegação por abas, todas as seções estratégicas visíveis e clicáveis para o aluno consultar quando quiser.
2. Dossiê markdown completo com toda a estratégia, escada de valor, funis, projeções, roadmap, métricas, e checklists. Esse arquivo serve de fonte de verdade e pode alimentar agentes futuros (SDR CLAW, geração de conteúdo, gestão de tráfego).

O plano não é genérico. Cada aluno recebe diagnóstico individual baseado em nicho, faturamento atual, recursos disponíveis, perfil pessoal. O método é replicável, o conteúdo é único.

### Quando criar

Dois momentos principais:

1. Quando aluno entra na a comunidade (onboarding obrigatório, faz parte da matrícula).
2. Quando aluno contrata mentoria individual ou consultoria 1-1 com o dono.

Em ambos os casos, é o ponto de partida. Sem plano de negócios estruturado, o aluno fica girando em círculo. Com o plano, ele tem mapa claro do que fazer, em que ordem, com que métricas medir.

### Tempo médio

1 a 2 horas para o pacote completo: call de diagnóstico (30-45 min) mais geração do dossiê e do site (30-60 min). Pode rodar em modo express (40 min) ou modo aprofundado (até 3 horas) dependendo do nível de personalização.

### Output final

- Site em `aluno-{nome}.seudominio.com.br` no ar com SSL ativo, navegação responsiva.
- Arquivo `aluno-{nome}-plano.md` com diagnóstico completo, salvo no GitHub privado.
- Arquivos JSON estruturados (`bmad.json`, `escada.json`, `funis.json`, `projecao.json`) para alimentar outros agentes.
- Registro no PostgreSQL (banco `naia_memory`, tabela `memory_chunks`, source `plano-negocios-aluno`) para busca semântica futura.

---

## 2. INPUTS NECESSÁRIOS DO ALUNO

Coletar via call de diagnóstico ou formulário estruturado. Antes de começar a criar qualquer coisa, esses dados devem estar 100 por cento completos. Sem dado, sem plano. Não chutar.

### Identificação

- Nome completo.
- Apelido (como aluno gosta de ser chamado).
- Email principal.
- WhatsApp.
- @ Instagram principal.
- @ outras redes (TikTok, YouTube, LinkedIn, X).
- Site existente, se tiver.
- Cidade e estado.

### Situação financeira atual

- Faturamento mensal médio dos últimos 3 meses (em reais).
- Margem líquida estimada (porcentagem).
- Custos fixos mensais (estrutura, salários, ferramentas).
- Reserva financeira disponível para investir no negócio.
- Tem capital para tráfego pago? Quanto por mês?

### Estrutura atual

- Quantas pessoas no time hoje (incluindo terceirizados).
- Funções de cada pessoa.
- Trabalha sozinho ou tem sócio?
- Já usa agentes de IA? Quais e para quê?
- Stack atual (CRM, ferramentas, plataformas).

### Nicho e produtos

- Nicho atual de atuação.
- Nicho que gostaria de atuar (se diferente).
- Produtos ou serviços ativos hoje.
- Preço de cada produto.
- Volume de vendas mensal de cada um.
- Algum produto está dando errado e quer descontinuar?

### Histórico e expertise

- Há quanto tempo está nesse nicho?
- Qual sua história pessoal de origem (por que entrou nesse mercado).
- Maiores resultados obtidos (de aluno, cliente, próprio).
- Diferencial pessoal real (o que só você tem ou faz).
- Já gravou conteúdo? Tem audiência?

### Objetivos

- Faturamento meta em 6 meses (em reais).
- Faturamento meta em 12 meses (em reais).
- Estilo de vida desejado (quanto trabalhar, onde morar, que tipo de cliente atender).
- O que quer parar de fazer?
- O que quer começar a fazer?

### Recursos

- Quantas horas semanais disponíveis pro projeto.
- Tem equipamento de gravação? Estúdio? Edição?
- Tem alguém pra editar conteúdo?
- Já tem comunidade ou grupo próprio?
- Conexões estratégicas (clientes grandes, parceiros, mídia).

### Habilidades

- Sabe falar em público / gravar vídeo (Sim / Mais ou menos / Não).
- Sabe escrever / fazer copy (Sim / Mais ou menos / Não).
- Sabe vender / negociar (Sim / Mais ou menos / Não).
- Sabe dar aula / ensinar (Sim / Mais ou menos / Não).
- Domina estratégia / posicionamento (Sim / Mais ou menos / Não).
- Domínio técnico em IA / automações (Sim / Mais ou menos / Não).

### Resistências e medos

- O que mais te trava hoje?
- Tem medo de gravar vídeo? De cobrar caro? De vender? De delegar?
- Já tentou escalar antes e deu errado? Por quê?
- O que NÃO quer fazer de jeito nenhum?

### Posicionamento atual

- Como se apresenta hoje em uma frase?
- O que sua audiência atual acha que você faz?
- Está satisfeito com como o mercado te enxerga?

---

## 3. PIPELINE DE 8 ETAPAS

### ETAPA 1, DIAGNÓSTICO BMAD ADAPTADO PARA ALUNO

BMAD adaptado para perfil de aluno empreendedor (não só perfil de Instagram). Quatro pilares com score 0-100 cada. Média final é o BMAD Total.

#### B (Brand) Pessoal e Empresarial

- Identidade pessoal e/ou empresarial atual.
- Arquétipo de marca (Herói, Sábio, Criador, Mago, Inocente, Explorador, Cuidador, Rebelde, Amante, Bobo, Governante, Cara_Comum).
- Tom de voz natural do aluno.
- 3 pilares de comunicação atuais.
- Consistência visual atual (Alta, Média, Baixa).
- Diferencial competitivo real (o que ele tem que mais ninguém tem).
- 3 gaps de marca (pontos onde a marca está fraca).
- Score 0-100.

Critério de score:
- 0-30, marca pessoal genérica, sem diferencial claro, indistinguível de concorrentes.
- 31-60, marca em formação, alguma identidade mas sem consistência.
- 61-80, marca clara, diferencial perceptível, reconhecível no nicho.
- 81-100, marca dominante no nicho, autoridade indiscutível.

#### M (Market) Análise de Mercado

- Nicho macro atual.
- Sub-nicho (onde tem menos concorrência).
- Tamanho do mercado no Brasil (estimativa).
- Nível de concorrência (Alta, Média, Baixa).
- Posicionamento dele hoje (líder, seguidor, nicho de boutique).
- 3 tendências relevantes do nicho.
- 3 oportunidades de mercado mal exploradas.
- Benchmarks do nicho (ticket médio, volume típico, ciclo de venda).
- Score 0-100.

Critério de score:
- 0-30, nicho saturado e ele sem diferenciação.
- 31-60, nicho competitivo com algumas brechas.
- 61-80, nicho com oportunidade clara e ele bem posicionado.
- 81-100, sub-nicho azul com liderança natural ou potencial alto.

#### A (Audit) Auditoria do Negócio Atual

- Performance geral (Excelente, Bom, Regular, Fraco).
- Avaliação do faturamento vs potencial do nicho.
- Auditoria de produtos: o que vende, o que não vende, por quê.
- Auditoria de operação: o que está funcionando e o que está travado.
- 3 gargalos de crescimento atuais.
- 3 pontos fortes do negócio.
- 3 pontos fracos do negócio.
- Score 0-100.

Critério de score:
- 0-30, negócio em estágio inicial ou estagnado, gargalos críticos.
- 31-60, negócio rodando mas com gargalos sérios.
- 61-80, negócio saudável, alguns ajustes pra escalar.
- 81-100, negócio escalável, pronto pra próximo patamar.

#### D (Direction) Estratégia e Direção

- Estratégia central recomendada (2-3 frases que resumem o caminho).
- Quick wins (3 ações imediatas com impacto rápido).
- Plano 90 dias em 3 fases (30/60/90 dias).
- Estratégia de monetização principal recomendada.
- Estratégia de operação com agentes recomendada.
- Score 0-100.

Critério de score:
- 0-30, estratégia ausente ou contraditória.
- 31-60, estratégia em formação, falta clareza.
- 61-80, estratégia clara, falta execução.
- 81-100, estratégia robusta com execução em andamento.

BMAD Total é a média aritmética dos 4 pilares. Esse score guia o tom do plano: aluno com BMAD 30 precisa de plano fundacional, aluno com BMAD 70 precisa de plano de escala.

---

### ETAPA 2, DEFINIÇÃO DE NICHO

Decidir o nicho final em que o aluno vai atuar. Pode ser:

- Manter o nicho atual.
- Ajustar o sub-nicho dentro do mesmo macro.
- Mudar de nicho (raro, só com base sólida).

Aplicar 5 critérios objetivos. Cada critério recebe score 0-10. Soma máxima é 50. Nicho com score abaixo de 30 é fraco e deve ser repensado.

#### Critério 1, Dor Latente (0-10)

Quão dolorosa é a dor que esse nicho enfrenta? Quanto o cliente sofre se não resolver?

- 0-3, dor leve, cliente convive com ela sem urgência.
- 4-7, dor média, cliente quer resolver mas não é prioridade.
- 8-10, dor aguda, cliente busca solução ativamente, cliente paga rápido.

#### Critério 2, Disposição a Pagar (0-10)

Esse mercado paga bem? Existem casos comprovados de ticket alto?

- 0-3, mercado paga pouco, aceita só preços baixos, alta sensibilidade.
- 4-7, mercado paga médio, aceita ticket de 1k a 5k.
- 8-10, mercado paga muito bem, aceita ticket alto, premium é regra.

#### Critério 3, Recorrência (0-10)

Esse cliente compra de novo? Existe modelo de assinatura ou serviço continuado?

- 0-3, compra única, sem retorno previsível.
- 4-7, recorrência possível mas precisa engenharia.
- 8-10, recorrência natural, cliente fica meses ou anos.

#### Critério 4, Conexão Pessoal (0-10)

O aluno tem história, expertise, vivência real nesse nicho?

- 0-3, sem conexão, está no nicho por acaso ou interesse passageiro.
- 4-7, conexão razoável, conhece o nicho mas não vive ele.
- 8-10, conexão profunda, vive o nicho, tem história de origem ali.

#### Critério 5, Tamanho de Mercado e Concorrência (0-10)

O nicho é grande o suficiente para sustentar o crescimento? Há espaço para ele entrar?

- 0-3, nicho pequeno demais ou super saturado.
- 4-7, nicho médio, concorrência alta mas com brechas.
- 8-10, nicho grande, concorrência razoável, espaço claro.

#### Score Final do Nicho

Soma dos 5 critérios. Faixas:

- 0-20, nicho ruim. Repensar antes de seguir.
- 21-30, nicho fraco. Seguir só com argumento forte.
- 31-40, nicho bom. Seguir com confiança.
- 41-50, nicho ouro. Foco total.

#### Sub-nicho Recomendado

Se nicho macro tem score 30-40, geralmente o caminho é encontrar sub-nicho com score 41-50. Exemplo: macro "consultoria" tem score 35 (saturado). Sub-nicho "consultoria pra dentistas escalarem clínica de implante" tem score 47 (específico, dor aguda, paga bem).

A regra: o aluno só sobe na escada quando reduz a largura do nicho.

---

### ETAPA 3, POSICIONAMENTO

Como o aluno deve se apresentar ao mercado para virar referência. Posicionamento mal feito é a causa número um de aluno que não fatura.

#### Princípio Central

Posicionamento de RESULTADO, não de tecnologia. O aluno NUNCA se posiciona como "especialista em IA" ou "expert em automação". Isso é commodity. Posiciona como especialista no resultado que entrega.

Exemplos:
- Errado: "Especialista em IA pra advogados".
- Certo: "Ajudo escritórios de advocacia a captar 30 novos casos por mês com agentes de IA".

- Errado: "Consultor de automação pra dentistas".
- Certo: "Lotando agendas de implante há 18 meses sem precisar de mais um vendedor".

A IA é o COMO, não o O QUÊ. O aluno vende resultado, e usa IA pra entregar.

#### Frase de Posicionamento

Estrutura padrão: "Eu ajudo [PÚBLICO ESPECÍFICO] a [RESULTADO MENSURÁVEL] em [PRAZO ou MÉTODO] sem [DOR EVITADA]."

Exemplos:
- "Eu ajudo dentistas com clínica de implante a lotar a agenda em 90 dias sem contratar mais vendedores".
- "Eu ajudo coaches a fazer 10 vendas de mentoria por mês com 3 horas de trabalho semanal".
- "Eu ajudo agências de marketing a dobrar margem sem aumentar time".

#### Nome de Marca Pessoal

Padrão recomendado: nome próprio + sobrenome. Marca pessoal vende mais que marca empresa em mercado de consultoria/mentoria.

Exceções:
- Aluno introvertido que não quer ser figura pública pode usar marca empresa.
- Aluno com nome difícil ou já saturado pode usar pseudônimo.

#### Tom de Voz

Definir entre 4 arquétipos principais:

- Autoridade Direta. Falas curtas, dados, resultados, sem rodeio. Bom pra B2B alto-ticket.
- Mentor Próximo. Conversa, exemplo, história pessoal. Bom pra coaches e infoprodutores.
- Provocador. Quebra padrão, polarização, conteúdo viral. Bom pra atrair atenção rápido.
- Educador Calmo. Didático, paciente, técnico. Bom pra nichos técnicos ou conservadores.

#### Pilares de Comunicação

Definir 3 pilares que o aluno vai bater 80 por cento das vezes. Exemplo de aluno em nicho "consultoria pra dentistas":

- Pilar 1, Marketing pra clínica odontológica.
- Pilar 2, Operação e gestão de clínica de implante.
- Pilar 3, Casos reais e bastidores de mentorias.

3 pilares evitam dispersão. Conteúdo fora dos pilares só com motivo claro.

---

### ETAPA 4, ESCADA DE VALOR

Estrutura completa de produtos do aluno em 4 níveis. Cada produto serve um momento da jornada do cliente.

#### Front-end (R$ 0 a R$ 300)

Produto de entrada. Objetivo é entregar valor rápido e gerar prova social. Geralmente:

- Lead magnet grátis (e-book, planilha, mini-aula, diagnóstico grátis).
- Tripwire de R$ 27 a R$ 97 (curso curto, ferramenta, template).
- Produto de entrada R$ 197 a R$ 297 (curso 8-12 horas).

Função: capturar lead, qualificar, criar primeira transação. Não dá pra escalar negócio só com isso.

#### Core (R$ 500 a R$ 3.000)

Produto principal de volume. Geralmente:

- Curso completo de 4-8 semanas (R$ 497 a R$ 1.997).
- Comunidade ou clube com mensalidade (R$ 47 a R$ 297/mês).
- Mentoria em grupo de 3-6 meses (R$ 1.497 a R$ 2.997).

Função: gerar caixa recorrente, sustentar operação, gerar clientes pra escala maior.

#### Back-end (R$ 5.000 a R$ 25.000)

Produto premium de transformação profunda. Geralmente:

- Mentoria 6-12 meses em grupo pequeno (R$ 5.000 a R$ 15.000).
- Mastermind ou imersão presencial (R$ 8.000 a R$ 25.000).
- Implementação assistida com equipe (R$ 10.000 a R$ 25.000).

Função: gerar margem alta, casos de transformação real, depoimentos premium.

#### High-ticket (R$ 50.000 ou mais)

Produto top de linha. Acesso restrito. Geralmente:

- Consultoria 1-1 trimestral ou semestral (R$ 30.000 a R$ 100.000).
- Implementação done-for-you completa (R$ 50.000 a R$ 200.000).
- Equity ou rev share em projetos grandes (variável).

Função: clientes pagam pelo acesso direto ao aluno e/ou execução completa. Volume baixo, margem altíssima.

#### Regras de Construção da Escada

1. Mínimo 4 níveis. Sem isso, não é escada.
2. Cada nível serve para vender o próximo. Comunidade vende mentoria, mentoria vende consultoria.
3. Não inventar produto. Se aluno não tem como entregar back-end, marca como "fase 2" e foca core primeiro.
4. Pelo menos 1 produto deve ser SUGERIDO (novo, não existe ainda). Mostra evolução.
5. Cada produto recebe descrição completa: nome, faixa de preço, público-alvo, proposta de valor, transformação prometida.

#### Detalhamento por Produto

Para cada produto da escada, gerar:

- Nome final do produto.
- Status (existente ou sugerido).
- Faixa de preço em reais.
- Público-alvo específico (quem compra).
- Proposta de valor (em uma frase).
- Transformação prometida (do estado A pro estado B).
- Conteúdo entregue (módulos, encontros, materiais).
- Duração ou acesso.
- Bônus inclusos.
- Garantia.
- Estrutura de entrega (ao vivo, gravado, presencial, online).

---

### ETAPA 5, FUNIS DE VENDA

Para cada produto da escada, sugerir 2-3 funis ideais. Cada funil tem estrutura completa.

#### Funis Possíveis

1. **Tráfego Direto**. Anúncio leva direto pra página de venda. Funciona pra produtos de R$ 27 a R$ 297. CAC baixo, conversão 1-3 por cento.

2. **Isca Digital + Esteira de Email**. Anúncio leva pra captura de email com lead magnet, depois sequência de 7-21 emails que vende o produto. Funciona pra core (R$ 497 a R$ 1.997).

3. **Lançamento Semente**. Aluno avisa lista interna, abre carrinho de 3-5 dias, vende sem tráfego pago. Funciona pra core e back-end. Aluno precisa ter audiência mínima.

4. **Lançamento Interno**. Sequência de 3-5 conteúdos gratuitos (CPL) seguidos de carrinho aberto. Funciona pra back-end e high-ticket. Conversão 5-15 por cento da audiência aquecida.

5. **VSL ou Webinário Automatizado**. Vídeo de 30-90 minutos que vende automaticamente, 24/7. Funciona pra back-end. Conversão 1-5 por cento dependendo da qualidade.

6. **Aplicação + Closer Humano**. Lead preenche formulário, agente SDR qualifica via DM/WhatsApp, closer humano fecha em call. Funciona pra back-end e high-ticket (qualquer produto acima de R$ 5.000). CAC alto mas conversão 20-40 por cento das aplicações qualificadas.

7. **DM Outbound (Social Selling)**. Agente SDR prospecta no DM do Instagram, qualifica, agenda call. Funciona pra back-end e high-ticket B2B. Volume baixo, margem altíssima.

8. **Tráfego para Comunidade Aberta**. Anúncio leva pra grupo gratuito (Telegram, Discord, WhatsApp) onde aluno faz aquecimento e converte para core/back-end. Funciona pra qualquer ticket.

#### Estrutura de Cada Funil

Para cada funil sugerido, gerar:

- Tipo do funil (um dos 8 acima).
- Descrição de funcionamento em 2-3 frases.
- 4 etapas explícitas do funil.
- Métricas esperadas (taxa de conversão, CAC, ROAS).
- Investimento mensal de tráfego sugerido.
- Stack tech necessário (ferramentas).
- Precisa SDR IA? (sim/não).
- Precisa closer humano? (sim/não).

#### Regra Crítica de High-Ticket

Todo produto acima de R$ 2.000 OBRIGATORIAMENTE precisa de SDR IA + closer humano no funil. Sem exceção. Tentar vender high-ticket via tráfego direto é desperdício de dinheiro.

---

### ETAPA 6, OPERAÇÃO COM AGENTES

Quais agentes o aluno deve montar e em que ordem. Agentes são o diferencial da a comunidade. Aluno que não monta agentes vira mais um consultor genérico.

#### Ordem de Implementação

1. **Mês 1, Agente SDR**. Atende DM do Instagram e/ou WhatsApp 24h. Aplica SPIN Selling, qualifica, agenda call. Esse é o primeiro agente sempre. Sem SDR, aluno perde lead nas mãos.

2. **Mês 2, Agente de Conteúdo**. Cria carrosseis, reels, posts diários a partir de briefings curtos. Acelera produção de conteúdo de 10x. Liberar tempo do aluno é prioridade.

3. **Mês 3, Agente de Tráfego**. Gestão de Meta Ads e Google Ads, otimização de campanha, alocação de budget. Substitui gestor de tráfego humano.

4. **Mês 4 ou depois, Agente de Pré-qualificação para Closer**. Se aluno tem high-ticket, agente faz triagem profunda antes da call humana. Closer só fala com lead já aquecido e qualificado.

#### Stack Recomendada

Para aluno iniciante (até R$ 30k/mês):
- Plataforma: agente de IA rodando em VPS (Hetzner ou Hostinger).
- LLM: Claude Sonnet ou Opus dependendo do nível de complexidade.
- CRM: Premium (white label do seu CRM).
- Ferramentas: Instaloader, ManyChat, n8n para automações simples.

Para aluno em escala (R$ 30k+/mês):
- Plataforma: OpenClaw em produção.
- Múltiplos agentes orquestrados via serviços systemd.
- seu CRM com pipeline customizado.
- Banco PostgreSQL com pgvector pra memória e histórico.

#### Custos Mensais Estimados

| Item | Faixa de custo (R$/mês) |
|---|---|
| VPS dedicada | 200 a 800 |
| APIs LLM (Claude Sonnet, Gemini, GPT-4) | 200 a 2.000 dependendo do volume |
| seu CRM | 297 a 997 |
| ManyChat ou Manyrobot | 50 a 300 |
| Ferramentas auxiliares (Instaloader, n8n, etc) | 100 a 500 |
| Tráfego pago (variável) | 1.000 a 50.000 ou mais |
| Total operação (sem tráfego) | 850 a 4.600 |

Aluno deve provisionar pelo menos R$ 2.000 mensais de orçamento operacional fixo, fora tráfego.

#### Princípio Central

Aluno NUNCA escala com mais gente. Escala com mais agentes. Substituir vendedor por agente SDR. Substituir copywriter por agente de conteúdo. Substituir gestor de tráfego por agente de tráfego. Time humano fica restrito a quem agrega valor estratégico (estratégia, criativo, fechamento high-ticket, atendimento VIP).

---

### ETAPA 7, PROJEÇÃO DE FATURAMENTO

Três cenários (conservador, moderado, agressivo) com mensal, anual, e premissas explícitas. Sem premissas, projeção é fantasia.

#### Cenário Conservador

Premissas:
- Aluno executa 60 por cento do plano.
- Tráfego pago no patamar mínimo.
- Conversões abaixo do benchmark.
- Sem alavanca externa (collab, viralização, parceria).

Cálculo:
- Volume mensal de leads qualificados (conservador).
- Conversão por funil (1 a 2 por cento de tráfego direto, 5 a 10 por cento de aplicação humana).
- Ticket médio (mais peso em produtos de baixo ticket).
- Faturamento mensal R$ X.
- Faturamento anual R$ X * 12 (sem crescimento mensal).

#### Cenário Moderado

Premissas:
- Aluno executa 80 por cento do plano.
- Tráfego pago crescente mês a mês.
- Conversões dentro do benchmark.
- Algum efeito de bola de neve (depoimento gera depoimento).

Cálculo:
- Volume crescente de leads qualificados.
- Conversão dentro do benchmark do nicho.
- Ticket médio com peso equilibrado entre níveis da escada.
- Faturamento mensal R$ X em mês 12.
- Faturamento anual cumulativo.

#### Cenário Agressivo

Premissas:
- Aluno executa 100 por cento do plano com agentes 24/7.
- Tráfego pago no teto do orçamento.
- Conversões acima do benchmark (otimização contínua).
- Alavancas externas ativas (viralização, parceria estratégica, indicação).
- Pelo menos 1 venda high-ticket por mês.

Cálculo:
- Volume alto de leads.
- Conversão otimizada.
- Mix com peso em back-end e high-ticket.
- Faturamento mensal R$ X em mês 12.
- Faturamento anual com curva de crescimento exponencial.

#### Curva Mês a Mês

Para cada cenário, projetar 12 meses de faturamento. Curva típica:

- Mês 1-2, validação. Faturamento baixo, primeiros testes.
- Mês 3-4, primeiras vendas consistentes. Curva começa.
- Mês 5-8, escala progressiva. Faturamento dobra a cada 2 meses se otimização funciona.
- Mês 9-12, plataforma consolidada. Crescimento estabilizado em ritmo sustentável.

Apresentar como tabela ou gráfico de barras no site do aluno.

#### Realismo Obrigatório

A regra inviolável: NUNCA prometer faturamento sem base. Se aluno fatura R$ 15k/mês hoje, projeção agressiva pode chegar em R$ 80k a R$ 150k em 12 meses. Não em R$ 500k. Sustentar com benchmarks reais do nicho. Se não tem dado concreto, marcar "estimativa baseada em casos similares".

---

### ETAPA 8, ROADMAP DE EXECUÇÃO 90 DIAS

Plano operacional concreto para os primeiros 90 dias. Cada mês tem objetivo, ações semanais, métricas, e checkpoint.

#### Mês 1, Setup Fundacional

Objetivo: deixar a casa em ordem. Aluno termina o mês com infraestrutura pronta e produto/oferta validados.

Semana 1:
- Definir produto principal (usar escada como guia).
- Criar landing page do produto principal (deploy em domínio personalizado).
- Configurar seu CRM (pipeline, formulários, automações básicas).
- Comprar VPS e configurar ambiente operacional.

Semana 2:
- Implementar Agente SDR (primeira versão).
- Conectar SDR ao seu CRM via webhook.
- Conectar Instagram DM ao SDR.
- Testar fluxo completo (mensagem chega, agente responde, qualifica, agenda call).

Semana 3:
- Criar 7 conteúdos pilares para Instagram (3 reels, 2 carrosseis, 2 stories pinados).
- Iniciar publicação diária seguindo os pilares definidos.
- Configurar Pixel + UTMs nas páginas de venda.

Semana 4:
- Lançar primeira campanha de tráfego de teste (R$ 50/dia).
- Validar funil completo (anúncio → DM → SDR → call → fechamento).
- Primeira tentativa de venda real.

Métricas mês 1:
- 1 funil completo funcionando.
- 30 leads no CRM.
- Pelo menos 1 venda do produto principal.

Checkpoint mês 1: aluno tem infraestrutura no ar, agente respondendo, primeira venda fechada (mesmo que pequena).

#### Mês 2, Validação e Primeiros Resultados

Objetivo: validar oferta, ajustar funil, gerar primeiros depoimentos.

Semana 5-6:
- Aumentar tráfego para R$ 100-200/dia.
- Otimizar copy do anúncio com base nos primeiros dados.
- Refinar treinamento do SDR com base nas conversas reais.
- Coletar primeiros depoimentos dos clientes.

Semana 7-8:
- Implementar Agente de Conteúdo (primeira versão).
- Aumentar produção de conteúdo de 7 pra 15 conteúdos por semana.
- Lançar primeiro produto recorrente (comunidade, clube ou mensalidade) se ainda não tiver.
- Primeiro lançamento semente do core (carrinho 3-5 dias para lista interna).

Métricas mês 2:
- 100 leads no CRM.
- 5-10 vendas do produto principal.
- 1-2 depoimentos em vídeo.
- Primeiro lançamento semente fechado.

Checkpoint mês 2: oferta validada com vendas repetidas, funil otimizado, primeiros casos reais documentados.

#### Mês 3, Escala e Validação de High-Ticket

Objetivo: escalar tráfego, aumentar conversão, validar oferta high-ticket.

Semana 9-10:
- Aumentar tráfego para R$ 300-500/dia.
- Implementar Agente de Tráfego (gestão de Meta Ads automatizada).
- Lançar funil de aplicação para back-end (R$ 5k+).
- Primeiras calls de aplicação high-ticket.

Semana 11-12:
- Lançamento interno do back-end (sequência de 3-5 CPLs + carrinho).
- Otimizar conversão geral (página, anúncio, SDR, closer).
- Primeira venda high-ticket validada.
- Documentar processo replicável para próximos 90 dias.

Métricas mês 3:
- 300 leads no CRM.
- Faturamento total trimestre dentro do cenário moderado projetado.
- Pelo menos 1 venda back-end (R$ 5k+) confirmada.
- Funil completo automatizado (mínima intervenção manual).

Checkpoint mês 3: aluno tem máquina funcionando, primeiros resultados consistentes, oferta high-ticket validada (mesmo que com 1-2 vendas).

#### Pós 90 Dias

Plano detalhado de meses 4-12 vira responsabilidade do mentor + aluno em revisão trimestral. Os primeiros 90 dias são o que está estruturado no plano de negócios.

---

## 4. ESTRUTURA DO SITE DO ALUNO

Site dedicado em `aluno-{nome}.seudominio.com.br`. Layout dark mode premium, glassmorphism, navegação por abas. Mesmo padrão visual das análises BMAD, adaptado para conteúdo de plano de negócios.

### Header

- Avatar com inicial do primeiro nome do aluno.
- Nome completo + @ Instagram.
- Badge do nicho final escolhido.
- Meta de faturamento 12 meses em destaque.
- Data de criação do plano.

### BMAD Bar

- 4 cards com scores B, M, A, D.
- 1 card destacado com BMAD Total.
- Hover mostra critério resumido de cada score.

### Stats Bar

- Faturamento atual mensal.
- Meta 6 meses.
- Meta 12 meses.
- Crescimento projetado em porcentagem.
- Investimento mensal sugerido.
- ROAS alvo.

### Abas Obrigatórias

1. **Resumo Executivo**. Diagnóstico geral em 3-5 parágrafos. Foco em movimentos urgentes.

2. **B, Brand**. Identidade pessoal, arquétipo, tom de voz, pilares de comunicação, diferencial competitivo, gaps de marca.

3. **M, Market**. Nicho final, sub-nicho, tamanho de mercado, concorrência, tendências, oportunidades, benchmarks.

4. **A, Audit**. Performance atual, gargalos de crescimento, pontos fortes, pontos fracos, auditoria de produtos.

5. **D, Direction**. Estratégia central, quick wins, estratégia de monetização, plano 90 dias resumido.

6. **Posicionamento**. Frase de posicionamento, nome de marca, tom de voz definitivo, 3 pilares.

7. **Escada de Valor**. Cards expansíveis para cada produto da escada (4 níveis mínimo). Detalhes completos: público, preço, proposta de valor, transformação, funis sugeridos.

8. **Funis de Venda**. Visual dos funis recomendados para cada produto. Diagramas, métricas esperadas, stack tech.

9. **Operação com Agentes**. Cronograma de implementação dos agentes, stack tecnológico, custos mensais estimados.

10. **Projeção 12 Meses**. 3 cenários (conservador, moderado, agressivo) com gráfico de curva mês a mês. Premissas explícitas.

11. **Roadmap 90 Dias**. Mês 1, 2, 3 com ações semanais, métricas e checkpoints visuais.

12. **Próximos Passos**. 3-5 ações imediatas para o aluno fazer essa semana.

### Design Tokens

- Background base: `#07070f`.
- Background cards: `#0e0e1a` com borda `rgba(255,255,255,0.08)`.
- Cor B (Brand): `#6366f1` (indigo).
- Cor M (Market): `#a855f7` (purple).
- Cor A (Audit): `#3b82f6` (blue).
- Cor D (Direction): `#10b981` (green).
- Cor destaque (CTAs e BMAD Total): `#fbbf24` (gold).
- Texto principal: `#e8e8f0`.
- Texto secundário: `#a0a0b0`.
- Tipografia: Inter ou system-ui, 16px base, headings com `font-weight: 700`.
- Cards: `border-radius: 12px`, `padding: 24px`, `backdrop-filter: blur(8px)`.
- Transições: 200ms ease nos hovers.

### JavaScript

Navegação simples entre abas via troca de classe `active`. Sem framework, vanilla JS. Responsivo com media query em 768px (em mobile, abas viram dropdown ou scroll horizontal).

### Geração

HTML montado via template Python (f-string) ou Jinja2. Salvar em `/tmp/build-aluno-{nome}/index.html` antes do deploy.

---

## 5. STACK NECESSÁRIA

Mesma stack das landing pages e análises BMAD. Padrão da casa.

### Linguagem e Ferramentas

- Python 3.10 ou superior.
- Pacotes Python: `requests`, `psycopg2-binary`, `google-generativeai`, `jinja2` (opcional).
- Node 18+ para Vercel CLI.

### Geração de Conteúdo

- Gemini 3.1 Pro Preview para análises estratégicas (BMAD, Escada, Projeção).
- Temperature 0.7, max output tokens 8192.
- 4 chamadas Gemini sugeridas: BMAD Adaptado, Escada e Funis, Projeção, Roadmap.

### Deploy

- Vercel CLI instalado globalmente.
- Vercel Token + Org ID vinculado ao email `usuario@exemplo.com`.
- Cloudflare API Token + Zone ID (zona `seudominio.com.br`).
- GitHub privado para versionar o markdown e o HTML.

### Banco de Dados

- PostgreSQL com pgvector. Banco `naia_memory`.
- Tabela `memory_chunks` (colunas: `content`, `metadata jsonb`, `source`, `created_at`).

### Diretório Local

- `/opt/seu-projeto/workspace/projeto/{nome}/` para arquivos do plano.

### Variáveis de Ambiente

```
GOOGLE_AI_KEY=...
VERCEL_TOKEN=...
VERCEL_ORG_ID=...
CF_TOKEN=...
CF_ZONE_ID=...
PG_CONN_STRING=postgres://...
GITHUB_TOKEN=...
```

---

## 6. REGRAS DE PERSONALIZAÇÃO

Cada aluno é único. Plano genérico é plano fracassado. As regras abaixo são absolutas.

### Personalização Obrigatória

1. **Conteúdo reflete o NICHO específico**. Termos, exemplos, benchmarks, casos reais devem ser do nicho do aluno. Não usar exemplo de "consultor genérico". Usar "consultor de implante odontológico" se for o nicho.

2. **Linguagem reflete o TOM do aluno**. Aluno formal, plano formal. Aluno descontraído, plano descontraído. Usar tom captado na call de diagnóstico.

3. **Considerar tempo e dinheiro disponível**. Aluno com 5h/semana e R$ 500/mês NUNCA recebe plano que exige 30h/semana e R$ 5k/mês. Adaptar realisticamente.

4. **Considerar habilidades reais**. Aluno que não sabe gravar vídeo NÃO recebe plano com 5 reels por semana. Adapta para carrossel. Ou plano de gradação que comece com 1 reel/mês.

5. **Considerar resistências e medos**. Se aluno tem medo de cobrar caro, o plano constrói progressão de ticket (entrar com R$ 497, depois R$ 1.997, depois R$ 5k+). Não joga em high-ticket no mês 1.

6. **Validar histórico para o nicho escolhido**. Aluno que nunca trabalhou com dentista NÃO posiciona como "especialista em clínica odontológica". Sem histórico, sem nicho. Voltar pra etapa 2 e refazer.

### Realismo Obrigatório

7. **Não prometer faturamento sem base**. Projeções amarradas a benchmarks reais do nicho. Se não tem dado, marca "estimativa baseada em casos similares" e ajusta para baixo.

8. **Próximos passos imediatos sempre concretos**. 3-5 ações que aluno pode fazer essa semana. Não "estudar mais" ou "pensar melhor". Ações específicas, mensuráveis, datadas.

### Estrutura, Não Conteúdo

9. **Copiar template é proibido**. A estrutura (10 etapas, 12 abas no site, 4 níveis na escada) é fixa. O CONTEÚDO de cada bloco é único pra cada aluno. Plano A não pode ter os mesmos exemplos do plano B.

---

## 7. REGRAS INVIOLÁVEIS

Lista canônica. Quebrar uma dessas regras invalida o plano.

1. **Repo SEMPRE privado**. Plano de negócios contém dados sensíveis (faturamento, estratégia). Nunca subir em repo público.

2. **Commits author/committer obrigatoriamente `usuario@exemplo.com`**. Vercel rejeita commits de outros emails na conta do dono. Sem exceção.

3. **Português brasileiro CORRETO com ACENTUAÇÃO COMPLETA**. Regra permanente do dono. Todo texto público (site, dossiê, copy) precisa ter acentuação 100 por cento correta. Sem exceções.

4. **ZERO travessões em todo conteúdo**. Usar vírgula, ponto, ou quebra de linha. Travessão é proibido em qualquer texto gerado.

5. **Cloudflare DNS com `proxied=false`**. Vercel exige `proxied=false` no CNAME. Diferente das análises BMAD que usam proxied=true. Para plano de aluno, sempre proxied=false.

6. **High-ticket (acima de R$ 2.000) sempre com SDR IA + closer humano**. Sem exceção. Vender high-ticket via tráfego direto puro é desperdício de orçamento.

7. **Cada produto da escada deve ter 2-3 funis sugeridos**. Mínimo 2, máximo 3. Não menos, não mais.

8. **Validar histórico/expertise pro nicho escolhido**. Se aluno não tem conexão real, voltar pra etapa 2. Não criar nicho fictício no plano. Não viajar.

9. **Mínimo 4 níveis na escada de valor**. Front-end + Core + Back-end + High-ticket. Sem isso, não é escada.

10. **Projeção sempre em 3 cenários com premissas explícitas**. Conservador, moderado, agressivo. Cada um com premissas escritas. Sem premissa, projeção é fantasia.

11. **Site precisa estar no ar antes da entrega**. Aluno recebe URL funcional, não promessa. Validar com `curl -I https://aluno-{nome}.seudominio.com.br` retornando 200.

12. **Salvar tudo localmente antes de deploy**. Se Vercel falhar, dá pra reaproveitar HTML e JSONs. Backup é obrigatório.

13. **Roadmap 90 dias com ações por semana**. Não plano vago de mês inteiro. Semana a semana, 12 semanas detalhadas.

14. **Próximos passos imediatos no fim do plano**. 3-5 ações concretas para essa semana. Aluno sai com tarefa.

---

## 8. EXEMPLO REAL HIPOTÉTICO

Caso fictício para ilustrar aplicação completa do método.

### Perfil do Aluno

- Nome: Ana Pereira.
- @ Instagram: @anapereirabusiness.
- Idade: 34.
- Cidade: Belo Horizonte.
- Faturamento atual: R$ 15.000/mês.
- Time: trabalha sozinha, terceiriza editor de vídeo (R$ 1.500/mês).
- Reserva: R$ 30.000.
- Nicho atual: "consultoria pra dentistas" (genérico).
- Produto atual: mentoria 3 meses por R$ 4.500 (vende 3-5 por mês).
- Histórico: dentista formada 10 anos, virou consultora há 4 anos.
- Meta 12 meses: R$ 80.000/mês.
- Disponibilidade: 25h/semana.
- Habilidades: fala bem (10/10), escreve OK (6/10), vende OK (7/10), dá aula bem (9/10).
- Resistência: tem medo de cobrar mais que R$ 5k.

### ETAPA 1, BMAD Adaptado

- B (Brand): score 58. Marca em formação, identidade clara como ex-dentista mas falta diferencial sólido.
- M (Market): score 65. Nicho competitivo mas com sub-nichos quentes.
- A (Audit): score 52. Negócio rodando, gargalo é falta de funil estruturado e dependência da própria Ana em todas as etapas.
- D (Direction): score 41. Estratégia atual é difusa, sem escada clara, sem agentes.

BMAD Total: 54.

Diagnóstico: aluna sólida em entrega mas com operação amadora. Precisa de escada, funil, agentes.

### ETAPA 2, Definição de Nicho

Nicho atual "consultoria pra dentistas": score 38 (saturado, ticket médio, recorrência média, conexão alta, mercado grande).

Sub-nicho recomendado: "consultoria pra dentistas com clínica de implante escalarem volume sem aumentar time". Score 47.

Critérios:
- Dor latente 9 (clínica trava em volume sem mais funcionários).
- Disposição a pagar 9 (dentista paga bem, ticket médio R$ 8k+).
- Recorrência 8 (mentoria recorrente é natural no nicho).
- Conexão pessoal 10 (Ana é dentista, tem clínica, vive isso).
- Tamanho de mercado 11 (mais de 100k clínicas de implante no Brasil).

Total: 47/50. Nicho ouro.

### ETAPA 3, Posicionamento

Frase: "Eu ajudo dentistas com clínica de implante a dobrar a receita em 6 meses sem contratar mais um vendedor."

Nome de marca: Ana Pereira (marca pessoal).

Tom de voz: Mentor Próximo (combinação de autoridade técnica e empatia humana). Ana fala bem e tem humor, manter naturalidade.

Pilares:
- Pilar 1, Marketing pra clínica de implante.
- Pilar 2, Operação e gestão de clínica em escala.
- Pilar 3, Bastidores reais (cases dela e de mentoradas).

### ETAPA 4, Escada de Valor

| Nível | Produto | Status | Preço | Público |
|---|---|---|---|---|
| Front-end | E-book "10 estratégias para lotar agenda de implante" | Sugerido | Grátis (lead magnet) | Dentista curioso |
| Front-end | Curso "Marketing pra Clínica de Implante" | Sugerido | R$ 297 | Dentista iniciante em digital |
| Core | Mentoria em Grupo "Clínica em Escala" | Existente, ajustado | R$ 4.997 (era R$ 4.500) | Dentista com clínica rodando |
| Core | Comunidade "Implante Pro" | Sugerido | R$ 197/mês | Aluna de qualquer produto |
| Back-end | Mentoria 1-1 12 meses | Sugerido | R$ 18.000 | Dentista com 5+ funcionários |
| High-ticket | Consultoria Done-for-You (implementação completa) | Sugerido | R$ 60.000 | Clínica faturando R$ 200k+ |

### ETAPA 5, Funis Sugeridos

Para Mentoria em Grupo (Core, R$ 4.997):
1. Lançamento Semente trimestral (carrinho 5 dias para lista interna).
2. Lançamento Interno semestral (CPL de 5 vídeos + carrinho).
3. Aplicação contínua via SDR IA (Instagram DM).

Para Comunidade Implante Pro (Core recorrente, R$ 197/mês):
1. Tráfego direto pra página de venda (Meta Ads).
2. Upsell pós-curso de R$ 297.

Para Mentoria 1-1 (Back-end, R$ 18.000):
1. Aplicação + Closer Humano (Ana fecha pessoalmente).
2. Lista interna premium (alunas que terminaram mentoria em grupo).

Para Consultoria DFY (High-ticket, R$ 60.000):
1. Aplicação + 2 Calls + Closer Humano.
2. Indicação direta de clientes back-end satisfeitas.

### ETAPA 6, Operação com Agentes

Cronograma:
- Mês 1: Agente SDR (Instagram DM + WhatsApp). Atende 24h, qualifica, agenda calls.
- Mês 2: Agente de Conteúdo (carrosseis e legendas a partir de briefings).
- Mês 3: Agente de Tráfego (gestão de Meta Ads).
- Mês 6: Agente de Pré-qualificação para High-Ticket (triagem antes da call humana).

Stack:
- agente de IA em VPS Hetzner.
- seu CRM.
- ManyChat para automações de DM.
- n8n para integração de webhooks.

Custo operacional: R$ 1.800/mês (sem tráfego). Tráfego inicial: R$ 3.000/mês.

### ETAPA 7, Projeção

Cenário Conservador:
- Mês 12: R$ 32.000/mês.
- Anual: R$ 280.000.
- Premissa: 60 por cento de execução, tráfego mínimo, 1 venda back-end/trimestre.

Cenário Moderado:
- Mês 12: R$ 60.000/mês.
- Anual: R$ 540.000.
- Premissa: 80 por cento de execução, tráfego crescente, 1 venda back-end/mês, primeira venda high-ticket no mês 9.

Cenário Agressivo:
- Mês 12: R$ 110.000/mês.
- Anual: R$ 920.000.
- Premissa: execução plena, tráfego no teto, 2-3 vendas back-end/mês, 1 venda high-ticket/trimestre.

Curva mês a mês na aba Projeção do site.

### ETAPA 8, Roadmap 90 Dias

Mês 1, Setup. Semana a semana detalhado: criar landing das mentorias, configurar seu CRM, montar SDR Instagram, testar fluxo completo.

Mês 2, Validação. Lançamento semente de Mentoria em Grupo, primeira leva de comunidade Implante Pro, primeiros depoimentos.

Mês 3, Escala. Aumentar tráfego para R$ 200/dia, primeira aplicação para 1-1 R$ 18k, validar funil high-ticket.

Próximos passos imediatos para Ana:
1. Comprar VPS Hetzner essa semana (R$ 200/mês).
2. Gravar 7 reels piloto em 2 dias seguindo os 3 pilares.
3. Configurar seu CRM e enviar lista atual de leads (importação CSV).
4. Marcar primeira call comigo (dono) para iniciar o setup do SDR.
5. Estudar curso de fundamentos de SPIN Selling para revisar o tom da Mentoria em Grupo.

---

## 9. CHECKLIST DE QUALIDADE

Antes de entregar o plano para o aluno, validar todos os itens. Se algum falhar, refazer o passo correspondente.

### Diagnóstico

- [ ] BMAD completo (4 pilares com scores explicados).
- [ ] BMAD Total calculado (média aritmética dos 4).
- [ ] Resumo executivo com 3-5 parágrafos.
- [ ] Diagnóstico fala dos pontos fortes E pontos fracos.

### Nicho

- [ ] Nicho final escolhido.
- [ ] Sub-nicho identificado (se aplicável).
- [ ] 5 critérios pontuados (dor, disposição, recorrência, conexão, tamanho).
- [ ] Score total do nicho calculado.
- [ ] Histórico do aluno valida o nicho.

### Posicionamento

- [ ] Frase de posicionamento clara e específica.
- [ ] Nome de marca definido (pessoal ou empresa).
- [ ] Tom de voz escolhido (1 dos 4 arquétipos).
- [ ] 3 pilares de comunicação definidos.

### Escada

- [ ] Mínimo 4 níveis preenchidos (front-end, core, back-end, high-ticket).
- [ ] Cada produto com nome, preço, público, proposta de valor, transformação.
- [ ] Pelo menos 1 produto SUGERIDO (não existe ainda).
- [ ] Produtos high-ticket (>R$ 2k) marcam SDR IA + closer humano.

### Funis

- [ ] 2-3 funis sugeridos para cada produto da escada.
- [ ] Cada funil com tipo, descrição, 4 etapas, métricas.
- [ ] Investimento de tráfego sugerido por funil.
- [ ] Stack tech identificado por funil.

### Operação

- [ ] Cronograma de implementação dos agentes (mês a mês).
- [ ] Stack tecnológico detalhado.
- [ ] Custos mensais estimados (operação + tráfego).
- [ ] Princípio de escala via agentes claro no plano.

### Projeção

- [ ] 3 cenários (conservador, moderado, agressivo).
- [ ] Cada cenário com mensal e anual.
- [ ] Cada cenário com premissas explícitas.
- [ ] Curva de crescimento mês a mês visualizada.
- [ ] Realismo: não promete faturamento sem base.

### Roadmap

- [ ] 90 dias detalhados em 12 semanas.
- [ ] Cada semana com ações concretas.
- [ ] Cada mês com objetivo e métricas.
- [ ] Cada mês com checkpoint claro.
- [ ] Adaptado às horas e budget disponíveis do aluno.

### Site

- [ ] HTML gerado e responsivo.
- [ ] Mínimo 12 abas funcionando.
- [ ] Navegação JS sem travar.
- [ ] Deploy em `aluno-{nome}.seudominio.com.br` retornando 200.
- [ ] SSL ativo (HTTPS).

### Persistência

- [ ] Arquivos salvos em `/opt/seu-projeto/workspace/projeto/{nome}/`.
- [ ] Markdown commitado em GitHub privado (commit author/committer usuario@exemplo.com).
- [ ] Registro no PostgreSQL (memory_chunks com source `plano-negocios-aluno`).

### Qualidade Geral

- [ ] Acentuação 100 por cento correta em todo o conteúdo.
- [ ] ZERO travessões em qualquer parte do plano.
- [ ] Português brasileiro consistente.
- [ ] Próximos passos imediatos no final (3-5 ações concretas).

---

## 10. INTEGRAÇÃO COM OUTROS PROCESSOS

O plano de negócios é o ponto de partida. Outros processos da a comunidade começam a partir dele.

### Próxima Fase, Implementação via SDR CLAW

Depois do plano aprovado, próxima fase obrigatória é implementar o agente SDR conforme método SDR CLAW (9 fases). O plano alimenta diretamente:

- Fase 1 do SDR CLAW (dossiê de treinamento) já tem 80 por cento dos dados prontos vindos do plano.
- Fase 2 (infraestrutura) usa a stack definida no plano.
- Fase 3 (criação do agente) usa o tom de voz, pilares e produtos da escada.

### Geração Automática de Conteúdo

Os 3 pilares de comunicação definidos viram briefing direto para agente de conteúdo. Cada pilar gera 1-2 conteúdos por semana. Aluno só aprova e publica.

### Tráfego Pago Automatizado

A seção de funis com investimento de tráfego sugerido alimenta agente de gestão de Meta Ads. Briefing já pronto: produto, público, copy de anúncio, budget.

### Revisão e Atualização

- Aluno consulta o plano semanalmente nos primeiros 90 dias.
- Mentor revisa progresso a cada checkpoint mensal.
- A cada 90 dias, plano é atualizado com base nos resultados reais.
- Após 12 meses, novo plano completo é gerado considerando o aprendizado do ano.

### Banco de Casos

Todos os planos de aluno ficam no banco PostgreSQL com busca semântica. Permite:

- Encontrar casos similares quando criar plano novo.
- Comparar trajetórias de alunos em mesmos nichos.
- Identificar padrões de sucesso e padrões de fracasso.
- Treinar próximas versões de agentes com base em casos reais.

### Marketing Interno

Plano bem-sucedido vira case da a comunidade. Com permissão do aluno, vira material de prova social para atrair novos alunos.

---

## 11. PIPELINE OPERACIONAL RESUMIDO

```
INPUTS DO ALUNO RECEBIDOS
    ↓
ETAPA 1, BMAD adaptado → 4 scores + total
    ↓
ETAPA 2, Definição de Nicho → 5 critérios + score do nicho
    ↓
ETAPA 3, Posicionamento → frase + tom + pilares
    ↓
ETAPA 4, Escada de Valor → 4 níveis com detalhes completos
    ↓
ETAPA 5, Funis de Venda → 2-3 funis por produto
    ↓
ETAPA 6, Operação com Agentes → cronograma + stack + custos
    ↓
ETAPA 7, Projeção → 3 cenários com premissas
    ↓
ETAPA 8, Roadmap 90 Dias → 12 semanas detalhadas
    ↓
GERAR HTML → site dark mode 12 abas
    ↓
DEPLOY VERCEL + CLOUDFLARE → aluno-{nome}.seudominio.com.br
    ↓
COMMIT GitHub privado → versionamento
    ↓
REGISTRO PostgreSQL → busca semântica
    ↓
ENTREGA AO ALUNO → URL + dossiê + próximos passos
```

---

## 12. TROUBLESHOOTING COMUM

**Problema**: Aluno não consegue responder os inputs essenciais.
**Causa**: Falta clareza sobre o próprio negócio.
**Fix**: Marcar call de diagnóstico de 60-90 minutos com mentor humano antes de tentar gerar plano. Sem dado, não tem plano.

**Problema**: Nicho escolhido tem score muito baixo.
**Causa**: Aluno está em nicho saturado sem diferencial real.
**Fix**: Voltar pra etapa 2 e procurar sub-nicho com score 41+. Se não tem opção viável, considerar mudança de nicho com base em conexão pessoal real.

**Problema**: Projeção parece otimista demais.
**Causa**: Premissas frouxas ou benchmarks sem fundamento.
**Fix**: Reduzir 30-50 por cento dos números. Ajustar premissas pra serem mais realistas. Se ainda assim ficar fantasia, ajustar nicho ou produto.

**Problema**: Aluno tem objeção ao high-ticket.
**Causa**: Medo de cobrar caro ou síndrome do impostor.
**Fix**: Construir gradação de ticket no plano. Mês 1-3 foca core. Mês 4-6 valida back-end. Só mês 9+ entra high-ticket. Não força, deixa progressão natural.

**Problema**: Aluno tem 5h/semana só.
**Causa**: Empregado ou outras obrigações.
**Fix**: Plano adaptado para baixa disponibilidade. Foco em 1 funil só, 1 produto só, conteúdo concentrado em 2 dias. Resto vai pra agentes 100 por cento. Honesto sobre crescimento mais lento.

**Problema**: Vercel deploy falha.
**Causa**: Token expirado ou Org ID errado.
**Fix**: Verificar VERCEL_TOKEN e VERCEL_ORG_ID. Conferir se commit author é `usuario@exemplo.com`.

**Problema**: Cloudflare DNS retorna erro de registro existente.
**Causa**: Subdomínio `aluno-{nome}` já existe pra outro projeto.
**Fix**: Deletar registro antigo (DELETE na API) ou usar nome alternativo (ex: `aluno-{nome}-v2`).

**Problema**: Site retorna 526 (SSL handshake fail).
**Causa**: Cert SSL ainda não propagou.
**Fix**: Aguardar 60s e retentar. Se persistir após 5 minutos, verificar `proxied=false` no CNAME do Cloudflare.

---

## 13. CREDENCIAIS NECESSÁRIAS

| Credencial | Onde obter | Uso na pipeline |
|---|---|---|
| Google AI Key | aistudio.google.com | Chamadas Gemini (4 chamadas estratégicas) |
| Vercel Token | vercel.com/account/tokens | Deploy do site |
| Vercel Org ID | dashboard Vercel, settings | Deploy do site |
| Cloudflare API Token | dash.cloudflare.com/profile/api-tokens, escopo Zone:DNS:Edit | DNS CNAME |
| Cloudflare Zone ID | dashboard Cloudflare, overview da zona seudominio.com.br | DNS CNAME |
| GitHub Token | github.com/settings/tokens (escopo repo) | Versionamento do plano |
| PostgreSQL credentials | banco naia_memory, user e senha do servidor | Persistência |

---

## 14. MENSAGEM FINAL PARA O ALUNO

Ao final do plano, sempre enviar para o aluno (via Telegram ou email) uma mensagem padrão de entrega:

```
Plano de Negócios pronto.

Site: https://aluno-{nome}.seudominio.com.br
Dossiê completo: link do GitHub privado (acesso restrito).

Diagnóstico geral:
[3-5 frases do resumo executivo]

3 movimentos urgentes pra essa semana:
1. [ação 1]
2. [ação 2]
3. [ação 3]

Próximo checkpoint: 30 dias.
Mentor responsável: [nome].

Bons resultados.
```

Mensagem direta, sem rodeio. Aluno tem acesso, sabe o que fazer, sabe quando volta a falar com o mentor.

---

*Documento autossuficiente para treinamento de agente especializado em criar Plano de Negócios para aluno da a comunidade e mentorados individuais. Versão 1.0, padrão atual de pipeline com 8 etapas estratégicas, 12 abas no site, 4 níveis na escada de valor, projeção em 3 cenários, roadmap 90 dias.*
