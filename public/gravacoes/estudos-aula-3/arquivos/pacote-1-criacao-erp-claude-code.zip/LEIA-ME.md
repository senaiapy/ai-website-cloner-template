# Pacote 1 · Criação do ERP modular com o Claude Code

Este pacote constrói a fase 1 do sistema: infraestrutura, núcleo e os módulos iniciais (os 14 padrão). Os 14 módulos opcionais vêm depois, no pacote 2, quando a fase 1 estiver no ar.

## Conteúdo

- `PROMPT-CLAUDE-CODE.md` · o prompt que você cola no Claude Code.
- `specs/ESPECIFICACAO-ITEM-A-ITEM.md` · tudo o que será construído, item por item, com código (I, B, N, F, M, D, P) e as provas de concluído.
- `specs/CATALOGO-MODULOS.md` · os módulos padrão e opcionais, abas, dependências e perfis por nicho.
- `specs/INTEGRACOES-API-MCP.md` · conectores, webhooks, API REST e servidor MCP.
- `docs/MANUAL-CONSTRUCAO-ERP-MODULAR.md` · o manual das nove camadas.
- `.claude/skills/loop-mestre-erp-modular/SKILL.md` · a skill loop mestre com o passo a passo de construção (spec, arquitetura, build, review, entrega).

## Como usar

1. Crie uma pasta vazia para o projeto.
2. Descompacte este ZIP dentro dela. A pasta `.claude/skills/` já deixa a skill instalada no projeto, e `specs/` e `docs/` ficam no lugar que a skill espera.
3. Abra o Claude Code na raiz da pasta (`claude`).
4. Abra `PROMPT-CLAUDE-CODE.md`, preencha os campos entre colchetes e cole o prompt.
5. Responda a pergunta zero e a entrevista de módulos. Depois disso o loop roda até a entrega com as provas P1 a P13.
