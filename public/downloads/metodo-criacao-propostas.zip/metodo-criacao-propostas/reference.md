# Método de Criação de Propostas Comerciais

> Documento operacional autossuficiente para reproduzir o padrão de propostas do Cliente Exemplo (a empresa).
> Versão: 1.0. Atualizado em abril de 2026.
> Idioma: português brasileiro com acentuação completa, sem travessões.

---

## 1. VISÃO GERAL

### O que é uma proposta no nosso padrão

Uma proposta comercial no padrão do dono não é PDF nem slide. É um SITE DEDICADO em HTML estático, hospedado em um SUBDOMÍNIO ÚNICO do cliente, dentro do domínio mestre `seudominio.com.br`.

Cada cliente recebe um endereço próprio no formato `https://nomedocliente.seudominio.com.br`. Ao abrir o link, o prospect vê uma experiência interativa, premium, com layout escuro ou claro, animações sutis, abas de navegação, gráficos, simuladores, checkboxes persistentes e tudo o que foi discutido na call de venda materializado em conteúdo.

A proposta é um vendedor silencioso. Funciona 24 horas por dia. Substitui a apresentação cara a cara. Permite que o cliente abra no celular, no tablet, no notebook, mostre para sócios, leia com calma e decida com clareza. Cada parágrafo é estratégico. Cada métrica é credibilidade. Cada CTA é convite à decisão.

### Quando criar

A proposta é gerada após uma call de vendas conclusiva, geralmente em três cenários principais.

| Cenário | Quem fecha | Tipo de proposta |
|---------|------------|------------------|
| Mentoria individual | Cliente Exemplo ou closer | Mentoria 6 meses |
| Consultoria estratégica | Cliente Exemplo ou closer | Consultoria entregue pelo time |
| Implementação de IA / SaaS | Cliente Exemplo | Projeto técnico |
| Mentoria + Consultoria combinada | Cliente Exemplo | Dois pacotes na mesma proposta |
| Sócio ou parceria de equity | Cliente Exemplo | Documento estratégico interno |
| Plano de ação para mentorado já ativo | Cliente Exemplo | Plano sem investimento |
| Briefing pré-call | Uso interno | Pesquisa estratégica |

### Tempo médio de produção

Com o método rodando bem, o ciclo completo (transcrição até link entregue) leva de 1 a 3 horas. A maior parte do tempo é a etapa 2 (geração do HTML personalizado). O resto da pipeline (deploy, DNS, dashboard) é mecânico e leva no máximo 15 minutos somando tudo.

### Output final

Site no ar em `https://nomedocliente.seudominio.com.br` com:
- URL única e memorável.
- Layout premium dark ou light.
- Conteúdo 100% personalizado com nome, números e dores reais do cliente.
- Tabs interativas, checkboxes persistentes, progress bar, gráfico Gantt.
- Toggle dark/light (quando aplicável).
- Responsivo no mobile.
- Dashboard de propostas atualizado em `propostas.seudominio.com.br`.

---

## 2. STACK NECESSÁRIA

A stack inteira é simples, leve e roda sem nenhum framework JavaScript. O segredo é manter tudo single-file e estático.

| Camada | Ferramenta | Uso |
|--------|------------|-----|
| Frontend | HTML5 + CSS inline + JavaScript inline | Single-file, zero build |
| Hospedagem | Vercel (static deploy) | Deploy automático em cada push |
| DNS | Cloudflare (zona seudominio.com.br) | Subdomínio personalizado |
| Versionamento | GitHub (conta seu-usuario) | Repositório privado por proposta |
| Fontes | Google Fonts | Cormorant Garamond + DM Sans |
| Persistência | localStorage do navegador | Checkboxes do cliente, tema escolhido |
| Dashboard | API REST em propostas.seudominio.com.br | Registro centralizado |

### Pré-requisitos no servidor

Comandos disponíveis no shell (testar antes de começar):
- `git`
- `gh` (GitHub CLI autenticado na conta seu-usuario)
- `vercel` (CLI Vercel)
- `curl`

### Tokens essenciais

Anotados na seção 10 deste documento. Sempre verificar a validade antes de iniciar a pipeline. Os tokens são:
- Vercel API Token (escopo seu-projeto).
- Cloudflare DNS Token (zona seudominio.com.br).
- GitHub CLI já autenticado como seu-usuario.

### Regra crítica de commits

TODOS os commits feitos via API ou via gh CLI devem ter `author` e `committer` igual a `usuario@exemplo.com`. Vercel rejeita deploys quando o committer não está vinculado ao time `seu-projeto`. Já aconteceu de quebrar deploy por isso. Sempre conferir.

```bash
git config user.email "usuario@exemplo.com"
git config user.name "Cliente Exemplo"
```

---

## 3. PIPELINE DE 7 ETAPAS

### ETAPA 1. TRANSCRIÇÃO DA REUNIÃO/CALL

Toda proposta começa pela call de vendas gravada. Sem call, sem proposta. Sem transcrição, sem proposta.

#### Como obter a transcrição

1. A call é gravada (Google Meet, Zoom, ou qualquer ferramenta de reunião).
2. O arquivo de áudio ou vídeo é baixado.
3. A transcrição é feita por uma das ferramentas abaixo (em ordem de preferência):
   - Whisper (OpenAI) localmente ou via API.
   - Tactiq, Fathom ou Otter (transcrição automática durante a call).
   - Modal de transcrição interna do Premium.
4. A transcrição bruta é salva como input para a etapa 2.

#### O que validar antes de avançar

- A transcrição cobriu a call inteira (sem cortes no início ou fim).
- Os falantes estão identificados (Cliente Exemplo, cliente, closer).
- Não há trechos com áudio inaudível bloqueando o entendimento.

Se a transcrição vier confusa, é melhor pedir refinamento manual antes de seguir. Proposta gerada em cima de transcrição ruim sai com erros graves de atribuição.

---

### ETAPA 2. EXTRAÇÃO DE INFORMAÇÕES-CHAVE

Esta é a etapa mais importante de todas. A diferença entre uma proposta excelente e uma proposta medíocre está na qualidade da extração feita aqui.

#### O que extrair da transcrição

Ler do começo ao fim, palavra por palavra, e identificar:

1. **Nome do cliente e da empresa.** Confirmar grafia exata.
2. **Nicho ou segmento.** O cliente atua em qual mercado, com qual público.
3. **Produtos e serviços atuais.** O que ele já vende, ticket médio, volumes.
4. **Faturamento atual ou potencial.** Números mencionados na call.
5. **Time atual e estrutura.** Quantas pessoas, quem faz o quê.
6. **Dor central.** O que o cliente disse que precisa resolver.
7. **Objetivo de 12 meses.** Onde ele quer estar no fim do contrato.
8. **Sugestões dadas pelo Cliente Exemplo.** O que foi proposto como solução.
9. **Preço oferecido.** Mentoria, consultoria ou os dois, com valores.
10. **Reação do cliente.** Interessado, com objeção, fechou na hora, pediu prazo.
11. **Próximos passos.** Combinados ao final da call.
12. **Personalizações específicas.** Cor preferida, paleta da marca, tom de comunicação.

#### Regras críticas de atribuição

NUNCA atribuir falas do Cliente Exemplo ao cliente. Esse erro já aconteceu antes. Se o Cliente Exemplo disse "eu faturei 96k em fevereiro", isso é do Cliente Exemplo, não do cliente. A proposta com atribuição errada quebra confiança imediatamente.

SEPARAR o que o cliente quer DE FATO do que foi sugerido como possibilidade. São coisas diferentes. A proposta precisa refletir essa distinção. Se o cliente disse que quer um app de oráculos e o Cliente Exemplo sugeriu também uma comunidade paga, a proposta apresenta o app como entrega central e a comunidade como upsell sugerido.

TANGIBILIZAR tudo o que foi discutido. Se a call mencionou app, a proposta detalha o app (telas, funcionalidades, valor de mercado). Se mencionou agente de IA, a proposta detalha o agente (papel, ferramentas, integrações). Se mencionou evento presencial, a proposta detalha o evento (local sugerido, formato, ticket).

PRECIFICAR valor de mercado sempre que o escopo incluir software, app ou SaaS. Adicionar uma seção mostrando quanto custaria contratar uma empresa de desenvolvimento separadamente para fazer o mesmo. Isso justifica o investimento de mentoria/consultoria pela ótica do "se fosse contratar separado custaria X".

#### Formato do diagnóstico de extração

Antes de partir para o HTML, montar um documento curto neste formato e validar com o dono:

```
NOME DO CLIENTE | Nicho

Quem é: descrição em uma frase

Situação atual:
| Item | Status |
|------|--------|
| Produto 1 | Descrição + ticket |
| Produto 2 | Descrição + ticket |

Dor principal: o que o cliente disse com as palavras dele.

O que quer: lista do que ele pediu.

O que foi sugerido: lista do que o Cliente Exemplo propôs.

Preços: Mentoria R$X / Consultoria R$Y

Reação: interessado, com objeção, fechou, pediu prazo.

Personalização: cor da marca, tom desejado, observações.
```

Esse documento é a fundação. A partir dele a proposta inteira é montada.

---

### ETAPA 3. GERAÇÃO DO HTML PERSONALIZADO

Aqui o template Layout Designer Exemplo entra em ação. É um arquivo HTML único, autocontido, com CSS inline e JavaScript inline. Sem build, sem dependências externas além das fontes do Google Fonts.

#### Estrutura do arquivo

O `index.html` segue exatamente esta ordem:

```
<!DOCTYPE html>
<html lang="pt-br" data-theme="dark">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Proposta NOME DO CLIENTE | Cliente Exemplo</title>

  Fontes Google: Cormorant Garamond + DM Sans
  CSS Variables (paleta dark + override light)
  Estilos globais
  Componentes (header, tabs, cards, callouts, ladder, gantt)
  Animações
  Responsivo
</head>
<body>
  Header (badge, título, subtítulo, métricas)
  Sticky navbar (aparece ao scroll)
  Tabs container
    Tab 1: Visão Geral
    Tab 2 a N: Personalizadas
    Tab final: Investimento (ou Parceria)
  Toggle dark/light (canto inferior esquerdo)
  Back to top (canto inferior direito)
  Footer
  JavaScript inline:
    Tab switching
    Header scroll
    Back to top
    Checkboxes persistentes (localStorage)
    Toggle tema (localStorage)
</body>
</html>
```

#### Sections obrigatórias

Toda proposta tem 8 sections principais. Algumas viram tabs separadas, outras se combinam.

1. **Hero (header).** Nome do cliente em destaque, badge identificador, subtítulo com posicionamento, métricas-âncora (3 a 5 números). Ocupa 100vh ou similar. Gradient navy ou cor da marca.

2. **Diagnóstico.** Two-column. Esquerda: o que funciona hoje (border-left verde). Direita: o que precisa mudar (border-left vermelho). Bullets com bolinhas coloridas. Mostra que a proposta entende o negócio.

3. **Proposta de solução.** 3 a 5 pilares. Cada pilar é um card com ícone, título, descrição e tag colorida.

4. **Entregáveis.** Lista detalhada com checkboxes interativos. O cliente marca conforme lê e a marcação persiste no localStorage. Progress bar no topo conta o percentual marcado.

5. **Cronograma.** Fases mensais com gráfico Gantt. Cada fase tem número circular, título, lista de entregas, período. Fases podem ser colapsáveis com chevron.

6. **Investimento.** Two-column. Card de mentoria à esquerda, card de consultoria à direita. Preços em destaque, lista de inclusos, badge "MAIS COMPLETO" no plano premium. Validade da proposta (7 dias). Forma de pagamento.

7. **Prova social.** Cards com números do Cliente Exemplo (mentorados, alunos, lançamentos, anos de mercado). Equipe que entrega (foto e nome de cada um). Casos de sucesso quando aplicável.

8. **CTA final + FAQ.** Convite à decisão (próximos passos, contato direto). FAQ com 4 a 6 perguntas frequentes (formato accordion ou simples).

#### Design geral

- Paleta dark: bg `#0a0a0a` ou `#080b14`, cards `#0d1117` ou `#131a27`, dourado/âmbar `#c49a4c` ou cor da marca, off-white `#e2e8f0`.
- Paleta light alternativa: bg `#ffffff`, cards `#f1f3f8`, navy `#1a3a6b` como primária, texto `#0f1d3a`.
- Tipografia: Cormorant Garamond para títulos e números grandes, DM Sans para corpo (17px, line-height 1.7).
- Animações sutis: fade-in entrance via IntersectionObserver, transições 0.3s ease.
- Layout responsivo: max-width 1200 a 1280px, padding lateral 24px, mobile 1 coluna.
- Hero ocupa 100vh com nome do cliente em destaque.
- Sections com max-width 1280px e padding generoso.

#### Personalização por nicho

A cor accent secundária muda conforme o nicho:
- Espiritualidade: roxo (#7c3aed) ou tons místicos.
- Arte: dourado dominante (#c49a4c).
- Saúde: verde (#16a34a) ou teal.
- Tech/SaaS: azul (#2563eb) ou cyan.
- Vinícola/luxo: tons vinho (#722F37) com gold.
- Marketing político: navy + cores institucionais.
- Imobiliário: teal + gold em dark mode.

O gradient do header também muda. Espiritualidade tem gradient roxo, arte tem gradient gold, tech tem gradient azul.

#### Salvar o arquivo

```bash
mkdir -p /tmp/proposta-NOMECLIENTE
# Salvar o HTML gerado em /tmp/proposta-NOMECLIENTE/index.html
```

---

### ETAPA 4. CRIAR REPO GITHUB PRIVADO

Cada proposta tem o próprio repositório. Sempre privado. Sempre na conta `seu-usuario`. Sempre com prefixo correto.

#### Nomenclatura

| Tipo de documento | Prefixo | Exemplo |
|-------------------|---------|---------|
| Proposta de venda | `proposta-` | proposta-edilson-superbrain |
| Plano para mentorado | `plano-` | plano-phcorridas |
| Briefing pré-call | `briefing-` | briefing-bcvl |
| Projeto de sócio | `projeto-` | projeto-mauricio |

#### Comandos

```bash
cd /tmp/proposta-NOMECLIENTE

# Configurar autoria correta (CRÍTICO)
git init
git config user.email "usuario@exemplo.com"
git config user.name "Cliente Exemplo"

# Adicionar e commitar
git add index.html
git commit -m "Proposta NOMECLIENTE - NICHO"

# Criar repo privado e subir
gh repo create seu-usuario/proposta-NOMECLIENTE --private --source=. --push
```

#### Validação

Após o push, conferir no GitHub que:
- O repositório está privado.
- O arquivo `index.html` está no root.
- O commit aparece com `usuario@exemplo.com` como author E committer.
- A branch padrão é `main`.

---

### ETAPA 5. DEPLOY VERCEL

A Vercel faz deploy estático e serve o HTML diretamente. O custom domain é configurado em seguida.

#### Comandos

```bash
cd /tmp/proposta-NOMECLIENTE

# Deploy direto pra produção
vercel --token VERCEL_TOKEN --yes --prod --scope seu-projeto

# Adicionar domínio customizado
vercel domains add NOMECLIENTE.seudominio.com.br --token VERCEL_TOKEN --scope seu-projeto
```

#### Verificações

- Deploy retornou status READY.
- A URL temporária `proposta-NOMECLIENTE.vercel.app` está acessível.
- O domínio customizado foi adicionado ao projeto.
- O Vercel exibe a mensagem de aguardar configuração de DNS.

#### Auto-deploy futuro

Após a primeira conexão, qualquer `git push` na main do GitHub dispara redeploy automático na Vercel. Não precisa rodar `vercel --prod` de novo. Isso é útil para correções rápidas após validação do dono.

---

### ETAPA 6. CONFIGURAR DNS CLOUDFLARE

O DNS é apontado da Cloudflare para a Vercel via registro CNAME ou A. O padrão atual usa A record apontando para o IP fixo da Vercel.

#### Comando

```bash
curl -s -X POST "https://api.cloudflare.com/client/v4/zones/CLOUDFLARE_ZONE_ID/dns_records" \
  -H "Authorization: Bearer CLOUDFLARE_TOKEN" \
  -H "Content-Type: application/json" \
  --data '{
    "type": "A",
    "name": "NOMECLIENTE",
    "content": "76.76.21.21",
    "ttl": 1,
    "proxied": false
  }'
```

#### Configuração detalhada

| Campo | Valor |
|-------|-------|
| Tipo | A |
| Nome | apenas o subdomínio (ex: `edilson`, sem `.seudominio.com.br`) |
| Conteúdo | `76.76.21.21` (IP da Vercel) |
| TTL | 1 (Auto) |
| Proxy | OFF (DNS only) |

A regra `proxied=false` é OBRIGATÓRIA. Se a Cloudflare proxar a requisição, o SSL da Vercel não funciona e o site quebra.

#### Subdomínios com hífen

Quando o nome do cliente tem mais de uma palavra ou pode confundir, usar hífen. Exemplos: `tiago-prefeituras`, `paulo-marcelo`, `dr-fernando`.

#### Tempo de propagação

- DNS leva de 1 a 5 minutos para propagar.
- SSL da Vercel leva de 2 a 10 minutos para provisionar.
- Se o link customizado não funcionar imediatamente, usar o link Vercel direto como backup: `https://proposta-NOMECLIENTE.vercel.app`.

---

### ETAPA 7. REGISTRAR NO DASHBOARD DE PROPOSTAS

Toda proposta entregue é registrada na dashboard interna em `propostas.seudominio.com.br`. Isso garante visibilidade do pipeline e métricas de conversão.

#### Comando

```bash
curl -s -X POST "https://propostas.seudominio.com.br/api/proposals" \
  -H "Content-Type: application/json" \
  --data '{
    "client_name": "Nome do Cliente",
    "proposal_type": "mentoria",
    "value_display": "R$20.000",
    "value_cents": 2000000,
    "description": "Breve descrição do nicho e projeto",
    "proposal_url": "https://nomedocliente.seudominio.com.br",
    "closer": "Cliente Exemplo",
    "status": "enviada"
  }'
```

#### Campos obrigatórios

| Campo | Tipo | Descrição |
|-------|------|-----------|
| client_name | string | Nome completo do cliente |
| proposal_type | string | mentoria, consultoria, mentoria/consultoria, agência, projeto |
| value_display | string | Valor formatado para exibição (R$20.000) |
| value_cents | integer | Valor em centavos (2000000 para R$20.000) |
| description | string | Nicho + projeto em uma frase |
| proposal_url | string | URL final da proposta com https |
| closer | string | Quem fechou: Cliente Exemplo, Davi, ou outro nome |
| status | string | enviada, negociando, fechada, perdida |

#### Entregar o link

Formato obrigatório com `https://`:

```
https://nomedocliente.seudominio.com.br
```

Mensagem padrão de envio (adaptar tom conforme contato):

```
Olá NOME, sua proposta está pronta.

Acesse: https://nomedocliente.seudominio.com.br

A proposta tem validade de 7 dias. Qualquer dúvida me chama por aqui.

Abraço,
Cliente Exemplo
```

---

## 4. LAYOUT MAICON (TEMPLATE PREMIUM)

O Layout Designer Exemplo é o nome interno do template padrão usado em todas as propostas. Foi nomeado em homenagem à proposta do cliente Designer Exemplo, primeira a consolidar a estrutura definitiva.

Existem duas gerações do template em uso. A escolha depende do nicho do cliente.

### Geração 1: Dark Premium

Usado em propostas de luxo, arte, tech, espiritualidade, ou qualquer nicho que pede sofisticação visual. Cliente Exemplo (Superbrain) é exemplo dessa geração.

```css
/* Variáveis CSS - Dark Premium */
:root {
  --bg: #080b14;
  --bg2: #0d1117;
  --bg3: #131a27;
  --bg4: #1a2235;
  --gold: #c49a4c;
  --gold2: #d4aa5c;
  --accent: #0891b2;
  --accent2: #06b6d4;
  --text: #e2e8f0;
  --text2: #94a3b8;
  --text3: #64748b;
  --border: #1e293b;
}

[data-theme="light"] {
  --bg: #ffffff;
  --bg2: #f8fafc;
  --bg3: #f1f5f9;
  --text: #0f172a;
  --text2: #475569;
  --border: #e2e8f0;
}
```

Características:
- Fundo escuro principal `#080b14`.
- Toggle dark/light no canto inferior esquerdo.
- Glassmorphism nos cards (backdrop-filter blur).
- Gold (`#c49a4c`) como accent de destaque.
- Cor secundária variável por nicho (cyan, teal, vinho).

### Geração 2: Light Corporate

Usado em propostas B2B, médicas, corporativas, ou para clientes mais conservadores. Eric (agência supermercados) e Cris (FuturiHealth) são exemplos.

```css
/* Variáveis CSS - Light Corporate */
:root {
  --navy: #1a3a6b;
  --navy-light: #244d8a;
  --bg: #ffffff;
  --bg-card: #f1f3f8;
  --bg-hover: #e8ebf2;
  --text: #0f1d3a;
  --text-sec: #4a5578;
  --text-muted: #8891a8;
  --border: #dfe3ed;
  --green: #16a34a;
  --blue: #2563eb;
  --purple: #7c3aed;
  --orange: #ea580c;
  --gold: #b8860b;
  --teal: #0d9488;
  --red: #dc2626;
  --cyan: #0891b2;
}
```

Características:
- Fundo branco principal.
- Sem toggle dark/light (fica light fixo).
- Sem glassmorphism, mais limpo.
- Navy (`#1a3a6b`) como cor primária.
- Sistema de 8+ cores para tags e callouts.

### Tipografia (ambas as gerações)

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;500;600;700&family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">

<style>
  body {
    font-family: 'DM Sans', sans-serif;
    font-size: 17px;
    line-height: 1.7;
  }

  h1, h2, h3, .price, .stat-number {
    font-family: 'Cormorant Garamond', serif;
    font-weight: 700;
  }

  /* Responsivo via clamp */
  h1 {
    font-size: clamp(36px, 6vw, 56px);
  }
  h2 {
    font-size: clamp(28px, 4vw, 42px);
  }
  .price {
    font-size: clamp(36px, 6vw, 52px);
  }
</style>
```

### Componentes obrigatórios

Toda proposta no Layout Designer Exemplo contém os 15 componentes abaixo. Cada um tem padrão visual fechado.

#### 1. Header com Badge e Métricas

```css
.header {
  background: linear-gradient(135deg, #0f1d3a, #1a3a6b, #244d8a);
  padding: 80px 24px 60px;
  text-align: center;
  position: relative;
}
.badge {
  display: inline-block;
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 2px;
  background: rgba(255,255,255,0.1);
  padding: 6px 14px;
  border-radius: 6px;
  margin-bottom: 20px;
}
.metrics {
  display: flex;
  gap: 40px;
  justify-content: center;
  margin-top: 30px;
}
.metric-number {
  font-family: 'Cormorant Garamond';
  font-size: 36px;
  font-weight: 700;
}
```

#### 2. Sistema de Tabs

```css
.tab-btn {
  padding: 10px 20px;
  border-radius: 8px 8px 0 0;
  background: transparent;
  border: none;
  cursor: pointer;
}
.tab-btn.active {
  background: white;
  color: var(--navy);
}
.sticky-nav {
  position: fixed;
  top: 0;
  z-index: 1000;
  width: 100%;
  background: white;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
  display: none;
}
.sticky-nav.visible {
  display: flex;
}
```

JavaScript:
```javascript
const tabs = document.querySelectorAll('.tab-btn');
tabs.forEach(tab => {
  tab.addEventListener('click', () => {
    tabs.forEach(t => t.classList.remove('active'));
    tab.classList.add('active');
    const target = document.querySelector(tab.dataset.tab);
    document.querySelectorAll('.tab-content').forEach(c => c.style.display = 'none');
    target.style.display = 'block';
    target.style.animation = 'fadeUp 0.4s ease';
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
});
```

#### 3. Cards Padrão

```css
.card {
  background: var(--bg-card);
  border: 1px solid var(--border);
  border-radius: 14px;
  padding: 20px;
  transition: all 0.3s ease;
}
.card:hover {
  transform: translateY(-2px);
  background: var(--bg-hover);
}
```

#### 4. Card Grids (3 variantes)

```css
.card-grid-2 {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: 20px;
}
.card-grid-3 {
  grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
}
.card-grid-4 {
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
}
```

#### 5. Callout Boxes (6 cores)

```css
.callout {
  padding: 16px 20px;
  border-radius: 14px;
  display: flex;
  gap: 12px;
  align-items: flex-start;
}
.callout-green { background: rgba(22,163,74,0.08); border-left: 3px solid #16a34a; }
.callout-blue { background: rgba(37,99,235,0.08); border-left: 3px solid #2563eb; }
.callout-orange { background: rgba(234,88,12,0.08); border-left: 3px solid #ea580c; }
.callout-purple { background: rgba(124,58,237,0.08); border-left: 3px solid #7c3aed; }
.callout-teal { background: rgba(13,148,136,0.08); border-left: 3px solid #0d9488; }
.callout-red { background: rgba(220,38,38,0.08); border-left: 3px solid #dc2626; }
```

#### 6. Tags Coloridas (8 cores)

```css
.tag {
  display: inline-block;
  font-size: 11px;
  text-transform: uppercase;
  font-weight: 700;
  padding: 3px 10px;
  border-radius: 6px;
}
.tag-navy { background: rgba(26,58,107,0.08); color: #1a3a6b; }
.tag-green { background: rgba(22,163,74,0.08); color: #16a34a; }
.tag-blue { background: rgba(37,99,235,0.08); color: #2563eb; }
.tag-purple { background: rgba(124,58,237,0.08); color: #7c3aed; }
.tag-orange { background: rgba(234,88,12,0.08); color: #ea580c; }
.tag-gold { background: rgba(184,134,11,0.08); color: #b8860b; }
.tag-teal { background: rgba(13,148,136,0.08); color: #0d9488; }
.tag-red { background: rgba(220,38,38,0.08); color: #dc2626; }
```

#### 7. Escada de Valor (Ladder)

```css
.ladder {
  display: flex;
  flex-direction: column;
  gap: 0;
}
.ladder-step {
  display: flex;
  align-items: stretch;
  border: 1px solid var(--border);
  border-radius: 12px;
  margin-bottom: 8px;
  overflow: hidden;
}
.ladder-num {
  width: 56px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(26,58,107,0.1);
  font-family: 'Cormorant Garamond';
  font-size: 24px;
  font-weight: 700;
}
.ladder-info {
  flex: 1;
  padding: 16px 20px;
}
.ladder-step.gold {
  background: linear-gradient(135deg, #0f1d3a, #1a3a6b);
  color: white;
}
```

#### 8. Offer Boxes (Investimento)

```css
.offer-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 24px;
  margin: 40px 0;
}
.offer {
  background: linear-gradient(135deg, #0f1d3a, #1a3a6b);
  color: white;
  padding: 40px 32px;
  border-radius: 16px;
  position: relative;
}
.offer.featured {
  border: 2px solid var(--gold);
  box-shadow: 0 0 40px rgba(196,154,76,0.3);
}
.offer .price {
  font-family: 'Cormorant Garamond';
  font-size: clamp(36px, 6vw, 52px);
  margin: 16px 0;
}
.offer .badge-featured {
  position: absolute;
  top: -12px;
  right: 20px;
  background: var(--gold);
  color: #0f1d3a;
  font-size: 10px;
  font-weight: 700;
  padding: 4px 10px;
  border-radius: 4px;
}

@media (max-width: 700px) {
  .offer-grid { grid-template-columns: 1fr; }
}
```

#### 9. Diagnóstico Two-Column

```css
.diagnostic-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 24px;
}
.diagnostic-card {
  padding: 24px;
  border-radius: 12px;
  background: var(--bg-card);
}
.diagnostic-card.works { border-left: 3px solid #16a34a; }
.diagnostic-card.change { border-left: 3px solid #dc2626; }
.diagnostic-bullet {
  display: flex;
  gap: 12px;
  align-items: flex-start;
  margin: 12px 0;
}
.diagnostic-bullet::before {
  content: '';
  display: block;
  width: 8px;
  height: 8px;
  border-radius: 50%;
  margin-top: 8px;
  flex-shrink: 0;
}
.works .diagnostic-bullet::before { background: #16a34a; }
.change .diagnostic-bullet::before { background: #dc2626; }
```

#### 10. Fases (Timeline)

```css
.phase {
  position: relative;
  padding: 24px;
  padding-left: 80px;
  background: var(--bg-card);
  border-radius: 12px;
  margin-bottom: 16px;
}
.phase-num {
  position: absolute;
  left: 20px;
  top: 24px;
  width: 36px;
  height: 36px;
  border-radius: 50%;
  background: var(--navy);
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  font-family: 'Cormorant Garamond';
  font-size: 18px;
  font-weight: 700;
}
.phase-period {
  color: var(--text-muted);
  font-size: 13px;
  margin-top: 8px;
}
.phase-toggle {
  cursor: pointer;
  position: absolute;
  right: 20px;
  top: 24px;
}
```

#### 11. Progress Bar

```css
.progress-container {
  background: var(--bg-card);
  border: 1px solid var(--border);
  border-radius: 6px;
  height: 12px;
  overflow: hidden;
  margin: 16px 0;
}
.progress-fill {
  height: 100%;
  background: linear-gradient(90deg, var(--navy), var(--navy-light));
  width: 0%;
  transition: width 0.6s ease;
}
.progress-text {
  font-size: 13px;
  color: var(--text-sec);
}
```

JavaScript:
```javascript
function updateProgress() {
  const checkboxes = document.querySelectorAll('.entrega-check');
  const checked = Array.from(checkboxes).filter(c => c.checked).length;
  const total = checkboxes.length;
  const pct = total > 0 ? Math.round((checked / total) * 100) : 0;
  document.querySelector('.progress-fill').style.width = pct + '%';
  document.querySelector('.progress-text').textContent =
    `${checked} de ${total} tarefas (${pct}%)`;
}

document.querySelectorAll('.entrega-check').forEach(cb => {
  cb.addEventListener('change', () => {
    localStorage.setItem(`prop-NOMECLIENTE-${cb.id}`, cb.checked);
    updateProgress();
  });
  // Restaurar estado salvo
  const saved = localStorage.getItem(`prop-NOMECLIENTE-${cb.id}`);
  if (saved === 'true') cb.checked = true;
});
updateProgress();
```

#### 12. Gantt Chart

```css
.gantt {
  overflow-x: auto;
  margin: 24px 0;
}
.gantt-table {
  min-width: 600px;
  width: 100%;
  border-collapse: collapse;
}
.gantt-bar {
  height: 24px;
  border-radius: 5px;
  font-size: 11px;
  color: white;
  display: flex;
  align-items: center;
  padding: 0 10px;
  position: relative;
}
.gantt-bar.fase-1 { background: linear-gradient(90deg, #1a3a6b, #244d8a); }
.gantt-bar.fase-2 { background: linear-gradient(90deg, #0d9488, #14b8a6); }
.gantt-bar.fase-3 { background: linear-gradient(90deg, #c49a4c, #d4aa5c); }
```

#### 13. Checkboxes Persistentes

```html
<label class="check-row">
  <input type="checkbox" class="entrega-check" id="entrega-1">
  <span>Configuração da arquitetura de IA</span>
</label>
```

```css
.entrega-check {
  accent-color: var(--navy);
  width: 18px;
  height: 18px;
  margin-right: 12px;
}
```

#### 14. Stat Cards

```css
.stat-card {
  text-align: center;
  padding: 20px;
}
.stat-number {
  font-family: 'Cormorant Garamond';
  font-size: 28px;
  font-weight: 700;
  color: var(--navy);
}
.stat-label {
  font-size: 13px;
  color: var(--text-sec);
}
```

#### 15. Back to Top

```css
.back-to-top {
  position: fixed;
  bottom: 24px;
  right: 24px;
  width: 44px;
  height: 44px;
  border-radius: 50%;
  background: var(--navy);
  color: white;
  display: none;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  z-index: 999;
  border: none;
}
.back-to-top.visible {
  display: flex;
}
```

JavaScript:
```javascript
window.addEventListener('scroll', () => {
  const btn = document.querySelector('.back-to-top');
  if (window.scrollY > 400) {
    btn.classList.add('visible');
  } else {
    btn.classList.remove('visible');
  }
});

document.querySelector('.back-to-top').addEventListener('click', () => {
  window.scrollTo({ top: 0, behavior: 'smooth' });
});
```

### Animações

```css
@keyframes fadeUp {
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
}

@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}

.animate-on-scroll {
  opacity: 0;
  transform: translateY(20px);
  transition: all 0.6s ease;
}
.animate-on-scroll.visible {
  opacity: 1;
  transform: translateY(0);
}
```

JavaScript com IntersectionObserver:
```javascript
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
    }
  });
}, { threshold: 0.1 });

document.querySelectorAll('.animate-on-scroll').forEach(el => {
  observer.observe(el);
});
```

### Responsividade

```css
@media (max-width: 1024px) {
  .container { padding: 0 20px; }
}

@media (max-width: 768px) {
  .header { padding: 60px 20px 40px; }
  .metrics { gap: 20px; flex-wrap: wrap; }
  .diagnostic-grid,
  .offer-grid,
  .card-grid-2,
  .card-grid-3,
  .card-grid-4 {
    grid-template-columns: 1fr;
  }
}

@media (max-width: 480px) {
  body { font-size: 15px; }
  h1 { font-size: 32px; }
  .price { font-size: 36px; }
}
```

---

## 5. ESTRUTURA DE CONTEÚDO

A proposta padrão tem 6 a 9 tabs, dependendo da complexidade. A média é 6 tabs. A primeira é sempre Visão Geral e a última é sempre Investimento ou Parceria.

### Tab 1. Visão Geral (obrigatória, sempre primeira)

Conteúdo:
- Quem é o cliente (descrição da empresa, contexto, números atuais).
- Diagnóstico two-column (o que funciona, o que precisa mudar).
- Solução proposta em 3 a 5 pilares.
- Callout com a tese central da proposta.

### Tabs intermediárias (personalizadas por cliente)

A quantidade e o nome variam. Exemplos reais:
- Ecossistema (escada de valor + esteira de produtos).
- Automação com IA (agentes propostos, papéis, integrações).
- Concorrência (análise comparativa).
- Frentes de Receita (modelos de monetização).
- Calculadora Interativa (simulador de ROI).
- Esteira de Produtos (escada de produtos).
- Rota de Vendas (funis, cartas, criativos).
- Estudos de Caso (proof points).
- Pesquisa de Mercado (validação externa).

### Tab Entregáveis (obrigatória)

Conteúdo:
- Lista detalhada com checkboxes interativos.
- Progress bar no topo.
- Agrupamento por categoria (estratégia, IA, vendas, suporte, infra).
- Cada item com descrição clara do que será entregue.

### Tab Plano de Ação (obrigatória)

Conteúdo:
- Fases mensais ou bimestrais (média de 7 a 9 fases).
- Cada fase é colapsável (chevron expand/collapse).
- Gráfico Gantt no final mostrando todas as fases em paralelo.
- Período de cada fase (datas reais ou semanas).

### Tab Investimento (obrigatória, sempre última, exceto variações)

Conteúdo:
- Stats no topo (duração, encontros, produtos entregues).
- Two-column com mentoria à esquerda e consultoria à direita.
- Card mentoria: preço, lista de inclusos.
- Card consultoria: preço, lista de inclusos, badge MAIS COMPLETO.
- Seção "Quem Entrega" com cards do time (Cliente Exemplo, Davi, Rafa, dev quando aplicável).
- Projeção de ROI explícita.
- Validade da proposta (7 dias).
- Referências de credibilidade do Cliente Exemplo.
- Próximos passos (CTA).

### Variações da última tab

| Cenário | Nome da última tab |
|---------|--------------------|
| Proposta padrão com preço | Investimento |
| Sem preço definido (parceria pendente) | Parceria |
| Plano de mentorado (já comprou) | Sem tab de investimento |
| Briefing pré-call (interno) | Sem tab de investimento |
| Projeto de sócio (equity) | Sem tab de investimento |

---

## 6. REGRAS DE PRECIFICAÇÃO

A precificação segue uma matriz por perfil de cliente. Os valores são referência. Sempre validar com o dono antes de gerar.

### Matriz de preços padrão

| Perfil do cliente | Mentoria (6 meses) | Consultoria (entrega completa) |
|-------------------|--------------------|--------------------------------|
| Solo / iniciante (faturamento até 50k/mês) | R$20.000 | R$50.000 |
| Estabelecido (faturamento 50k a 200k/mês) | R$30.000 | R$60.000 |
| Premium (alta exigência, ticket alto) | R$60.000 | R$70.000 a R$95.000 |
| Enterprise (faturamento 1M+/mês) | Sob consulta | R$95.000 a R$250.000 |

### Variações registradas

- Mentoria padrão: R$20k em 6 vezes via PIX, ou à vista com 10% de desconto.
- Mentoria premium (Dr. Fernando): R$60k.
- Consultoria com manutenção mensal: R$5k a R$10k/mês adicional.
- Projetos enterprise (Ronaldo): R$250k em 4 fases (50%/25%/25%).
- Setup + recorrência (Aline): R$5k setup + R$3k/mês + R$10k app.
- Equity e sociedade (InnVernia): R$100k + R$10k/mês + 10% comissão.

### Regras invioláveis

1. **Sempre apresentar 2 a 3 opções.** Mentoria, consultoria, ou ambas. Nunca apresentar opção única (cliente perde poder de decisão e a sensação de escolha).
2. **Escassez via prazo de validade.** Toda proposta tem validade de 7 dias. Após esse prazo, valores podem ser revistos. Comunicar de forma sutil.
3. **Forma de pagamento clara.** À vista (com desconto) ou parcelado em 3 a 12 vezes via PIX, cartão ou boleto.
4. **Setup + mensalidade quando aplicável.** Para projetos com manutenção contínua, separar valor de implementação do retainer mensal.
5. **Parcelas nunca vinculadas a entregas.** Parcela é parcela, não milestone. Não condicionar pagamento a fases do projeto.
6. **Valor de mercado em projetos técnicos.** Quando inclui app, SaaS ou software, mostrar quanto custaria contratar separadamente. Geralmente 3 a 5x o valor da consultoria.
7. **Pixel Meta opcional.** Geralmente NÃO usar em proposta privada (só em landing públicas). Cada proposta é tracking individual via dashboard.

### Ancoragem psicológica

Sempre ancorar o valor antes de mostrar o preço:
- Comparar com custo de equipe (12 meses de funcionário CLT custaria R$X).
- Comparar com agência (uma agência cobraria R$X só pelo setup).
- Mostrar projeção de retorno (ROI de 5x em 6 meses, payback em 2 a 4 meses).
- Listar o que está incluso para reforçar percepção de valor.

---

## 7. REGRAS INVIOLÁVEIS

### Técnicas

1. Repositório no GitHub SEMPRE privado. Nunca público. Conta `seu-usuario`.
2. Commits com `author` E `committer` igual a `usuario@exemplo.com`. Vercel rejeita o deploy se o committer não estiver vinculado ao team.
3. Cloudflare CNAME ou A com `proxied=false`. Proxy quebra o SSL da Vercel.
4. Cada proposta tem URL única `nomedocliente.seudominio.com.br`. Nunca reutilizar subdomínio.
5. Nomenclatura de repo respeitando prefixo (`proposta-`, `plano-`, `briefing-`, `projeto-`).
6. Branch padrão `main`, nunca `master`.
7. Pixel Meta não usar em proposta privada (a menos que pedido explícito).

### De conteúdo

1. **Português brasileiro CORRETO com ACENTUAÇÃO COMPLETA.** Sem exceções. Toda palavra que leva acento deve ter acento. "Ação", "Visão", "Operação", "Decisão", "Não", "Você", "Está", "Será". Erro de acentuação em proposta enviada é inaceitável.
2. **ZERO travessões.** Substituir por vírgula, ponto, ou quebra de linha. Travessão é sinal de IA mal calibrada.
3. **Tom profissional mas acessível.** Como um amigo que manja muito. Não robótico. Não bajulador.
4. **Nunca atribuir falas do Cliente Exemplo ao cliente.** Erro grave de credibilidade.
5. **Tangibilizar tudo o que foi discutido.** App? Detalhar telas. Agente? Detalhar papel. Evento? Detalhar formato.
6. **Valor de mercado em projetos técnicos.** Comparativo obrigatório quando inclui software.
7. **Nunca expor preços sem contexto.** Preço sempre acompanhado de inclusos, ROI, validade, ancoragem.
8. **Informações sensíveis fora.** Negócios paralelos do cliente que não vieram à tona, dados pessoais não relacionados, fofoca de call. Tudo isso fica fora.
9. **Modalidades pedidas apenas.** Se Cliente Exemplo pediu só mentoria, não incluir consultoria. Se pediu sem preço, não inventar preço.
10. **Validade de 7 dias visível.** Ancoragem de urgência.

### De entrega

1. Entregar link com `https://` na frente sempre.
2. Testar o link antes de mandar (DNS pode levar 5 min, SSL pode levar 10 min).
3. Se o domínio customizado não funcionar de cara, usar fallback Vercel `proposta-NOMECLIENTE.vercel.app`.
4. Atualizar dashboard `propostas.seudominio.com.br` IMEDIATAMENTE após entrega.
5. Nunca prometer alterações que demandem refazer estrutura. Pequenos ajustes sim, refatoração não.

---

## 8. EXEMPLO REAL. CASO EDILSON SUPERBRAIN

Caso real entregue em 24 de abril de 2026. Serve como referência completa.

### Contexto

- **Cliente:** Cliente Exemplo, perito contábil, sócio de Guilherme e Gabriel (também conhecido como Luqueta).
- **Empresas:** Superbrain (nova, soluções de IA para contadores) + IBCAPA (plataforma educacional desde 2019, pós-graduações para contadores).
- **Nicho:** IA aplicada à contabilidade e perícia contábil.
- **Posicionamento:** Autoridade técnica em contabilidade com foco em transformar contadores tradicionais em contadores aumentados por IA.

### Pipeline executada

1. **Transcrição.** Call de venda gravada e transcrita.
2. **Extração.** Identificação do nicho IA contábil, foco em formação de profissionais, escala via plataforma IBCAPA, novo braço de produto Superbrain.
3. **HTML.** Layout dark premium gold, tons dourados puxando para a vibe corporativa contábil. 6 tabs: Visão Geral, Ecossistema, Automação com IA, Entregáveis, Plano de Ação, Investimento.
4. **GitHub.** Repo `seu-usuario/proposta-edilson-superbrain` criado privado, push do `index.html`.
5. **Vercel.** Deploy via CLI no scope `seu-projeto`, status READY.
6. **Cloudflare DNS.** A record id `f44ef26b23c135157f675950ac78cb03`, name `edilson`, content `76.76.21.21`, proxied false.
7. **Dashboard.** Registrada com tipo mentoria/consultoria, valores M R$30k / C R$60k, status enviada.

### Output final

- URL: `https://edilson.seudominio.com.br`.
- Status: entregue e no ar.
- Layout: dark premium gold com toggle light, glassmorphism, gantt, checkboxes persistentes.
- 3 opções de investimento: mentoria pura, mentoria + consultoria leve, consultoria completa.

### Observações

- O HTML foi gerado pelo Paulo na sessão anterior, deploy finalizado pela Orquestradora em sessão posterior.
- Caso de proposta com 2 marcas no mesmo cliente (Superbrain + IBCAPA), exigindo seções específicas para cada empresa dentro da mesma proposta.
- Personalização visual puxou paleta dourada forte para reforçar autoridade contábil/financeira.

### Como usar este caso como referência

Se for criar proposta para nicho similar (educação técnica, formação profissional, autoridade B2B):
1. Clonar o `index.html` do repo `seu-usuario/proposta-edilson-superbrain` localmente.
2. Substituir nome, números, dores e copy mantendo a estrutura.
3. Ajustar paleta de cores se o nicho pedir tom diferente.
4. Refazer pipeline a partir da etapa 4 (GitHub novo, Vercel novo, DNS novo).

---

## 9. CHECKLIST DE QUALIDADE

Antes de mandar o link para o cliente, conferir item a item:

### Conteúdo

- [ ] Texto 100% com acentuação PT-BR completa.
- [ ] Zero travessões em todo o documento.
- [ ] Nome do cliente aparece em pelo menos 5 lugares (header, copy, footer, localStorage key, título do navegador).
- [ ] Nenhuma fala do Cliente Exemplo atribuída ao cliente.
- [ ] Tudo que foi discutido na call está tangibilizado.
- [ ] Modalidades corretas (mentoria, consultoria, ambas, ou nenhuma conforme pedido).
- [ ] Preços com escassez (validade 7 dias visível).
- [ ] Forma de pagamento explícita.
- [ ] Se tem software/app, tem precificação de mercado comparativa.
- [ ] Nenhuma informação pessoal sensível do cliente.
- [ ] Tom profissional, sem robótica de IA.

### Visual

- [ ] Layout Designer Exemplo respeitado (paleta, fontes, estrutura).
- [ ] Cor accent ajustada conforme nicho.
- [ ] Toggle dark/light funcionando (quando aplicável).
- [ ] Sticky navbar aparece ao scroll.
- [ ] Checkboxes persistindo no localStorage.
- [ ] Progress bar calculando corretamente.
- [ ] Phases colapsáveis funcionando.
- [ ] Gantt chart visível e correto.
- [ ] Animações fade-in ativando.
- [ ] Back to top aparecendo após 400px de scroll.
- [ ] Responsivo testado em mobile (max-width 480px).
- [ ] Tabs centralizadas.
- [ ] Fontes Google Fonts carregando.

### Técnico

- [ ] Repositório GitHub criado e PRIVADO.
- [ ] Commit author e committer = usuario@exemplo.com.
- [ ] Branch padrão `main`.
- [ ] Vercel deploy com status READY.
- [ ] Domínio customizado adicionado no Vercel.
- [ ] Cloudflare DNS A record com proxied=false.
- [ ] HTTPS funcionando (SSL provisionado).
- [ ] Link customizado abre normalmente em browser e mobile.
- [ ] Link Vercel direto disponível como fallback.

### Entrega

- [ ] Dashboard `propostas.seudominio.com.br` atualizado.
- [ ] Link enviado com `https://` na frente.
- [ ] Mensagem de envio adaptada ao tom da relação.
- [ ] Validade de 7 dias mencionada na mensagem ou na proposta.

---

## 10. CREDENCIAIS NECESSÁRIAS

Tabela com todas as credenciais usadas na pipeline. Manter atualizada e segura.

| Credencial | Uso | Observação |
|------------|-----|------------|
| GitHub CLI (gh) | Criar repo privado e fazer push | Autenticado como `seu-usuario` |
| Git config user.email | usuario@exemplo.com | OBRIGATÓRIO para Vercel aceitar deploy |
| Git config user.name | Cliente Exemplo | Padrão de identidade |
| Vercel API Token | Deploy estático e custom domain | Escopo `seu-projeto` |
| Vercel Scope | seu-projeto | Time da Vercel |
| Vercel Team ID | team_l6zSw1lZTlfHqKRIe38paQxY | Para chamadas API que pedem teamId |
| Cloudflare DNS Token | Criar A record no subdomínio | Permissão Edit Zone DNS |
| Cloudflare Zone ID seudominio.com.br | Apontar registro DNS | Zona mestre |
| API Dashboard Propostas | Registrar proposta no pipeline | Endpoint `propostas.seudominio.com.br/api/proposals` |

### Onde encontrar

- Todas as credenciais reais estão no arquivo `/opt/seu-projeto/knowledge/sales/PROCESSO-CRIACAO-PROPOSTAS.md` na pasta interna do agente Orquestradora.
- Tokens versionados em `.env` quando aplicável (nunca em código fonte público).
- Chaves de API rotacionadas a cada 90 dias por padrão.

### Como validar antes de começar

```bash
# Validar GitHub CLI
gh auth status

# Validar Vercel CLI
vercel whoami --token VERCEL_TOKEN

# Validar Cloudflare token (lista zonas)
curl -s "https://api.cloudflare.com/client/v4/zones" \
  -H "Authorization: Bearer CLOUDFLARE_TOKEN" | head -50

# Validar Dashboard
curl -s "https://propostas.seudominio.com.br/api/proposals?limit=1"
```

Se qualquer um falhar, parar a pipeline e pedir renovação de token antes de seguir.

---

## ANEXO A. FLUXO RESUMIDO EM 1 PÁGINA

```
1. Receber transcrição da call.
2. Extrair: cliente, nicho, dor, números, sugestões, preços, reação.
3. Validar diagnóstico com o dono.
4. Gerar HTML personalizado com Layout Designer Exemplo.
   - Escolher geração (Dark Premium ou Light Corporate).
   - Ajustar paleta accent ao nicho.
   - Construir 6 a 9 tabs.
   - Personalizar copy com nome e dores reais.
5. mkdir /tmp/proposta-NOMECLIENTE && salvar index.html.
6. git init + config email + commit + gh repo create privado + push.
7. vercel --prod --scope seu-projeto.
8. vercel domains add NOMECLIENTE.seudominio.com.br.
9. curl Cloudflare API: A record proxied=false.
10. curl Dashboard API: registrar proposta.
11. Aguardar 5 min DNS + 10 min SSL.
12. Testar https://NOMECLIENTE.seudominio.com.br.
13. Enviar link ao cliente com mensagem padrão.
```

## ANEXO B. ERROS HISTÓRICOS QUE NÃO PODEM REPETIR

1. **Marcos (Astrologia).** Atribuímos R$96k de faturamento ao cliente quando era do Cliente Exemplo falando de outro projeto. Lição: sempre identificar o falante na transcrição antes de extrair números.

2. **Marcos (Astrologia).** Não tangibilizamos o app de mapas astrais que foi discutido na call. Lição: tangibilizar TUDO. Se mencionou, detalha.

3. **Múltiplas propostas iniciais.** Texto sem acentuação completa. Lição: revisar caractere por caractere antes de subir. Não confiar em geração automática.

4. **Tiago (Prefeituras).** Incluímos referência ao negócio paralelo de lanchas dele que não tinha relação com o tema. Lição: filtrar informações pessoais sensíveis.

5. **Múltiplas propostas.** Tabs desalinhadas no centro. Lição: testar centralização em diferentes resoluções.

6. **Plano de ação.** Linguagem de "teste antes de comprar" em plano pós-venda. Lição: se é plano de mentorado, tudo começa após definição da parceria, sem condicionantes.

7. **Vercel rejeitando deploys.** Commit committer não vinculado. Lição: SEMPRE conferir `git config user.email` antes do primeiro commit.

8. **Cloudflare proxy ON.** SSL quebrado por ter proxy ativado. Lição: `proxied=false` é regra inviolável.

## ANEXO C. PADRÕES DE CREDIBILIDADE DO DONO

Os números de credibilidade evoluem ao longo do tempo. Usar a versão mais recente.

### Versão atual (propostas a partir de abril/2026)

- 10.000+ mentorados.
- 45.000+ alunos.
- 500+ lançamentos.
- 100+ vezes 6 em 7.
- 17 SaaS com IA construídos nos últimos 90 dias.
- R$120k/mês economizados (60 pessoas reduzidas para 6).
- 11 anos de mercado.

### Equipe que entrega (padrão)

- **Cliente Exemplo.** Estratégia, ecossistema, IA, mentoria pessoal.
- **Davi e Rafa.** Acompanhamento, implementação, suporte tático.
- **Dev Senior.** Para projetos técnicos com construção de software (Designer Exemplo, Ronaldo, Cliente Exemplo).

## ANEXO D. INSIGHTS ESTRATÉGICOS

Padrões que funcionam bem em propostas e merecem ser reforçados:

1. **Escada de valor personalizada.** Cada proposta desenha escada específica para o nicho do cliente. Nunca usar escada genérica.

2. **Diagnóstico honesto.** Mostrar que conhece o negócio do cliente. Two-column funciona vs precisa mudar gera identificação.

3. **ROI explícito.** "Investimento se paga em X meses". Sempre projeção numérica clara.

4. **App ou SaaS próprio como diferencial.** Quando o projeto inclui produto digital próprio do cliente, isso vira diferencial forte versus mentoria genérica.

5. **Comparativo com mercado.** "Se fosse contratar separado custaria R$X". Ancoragem de valor pelo custo evitado.

6. **Validade de 7 dias.** Urgência sutil, sem ser agressiva.

7. **Checkboxes persistentes.** Cliente interage e se engaja. Cria sensação de progresso ao ler.

8. **Tipografia Cormorant + DM Sans.** Padrão visual que transmite premium sem cansar.

9. **Personagens em cards (quando aplicável).** Time real com fotos e nomes humaniza a entrega.

10. **Numeração de fases clara.** Cliente enxerga o caminho dos próximos 6 meses ao bater o olho.

---

Documento operacional. Manter atualizado conforme novas propostas são entregues e novas práticas são consolidadas.

Versão: 1.0
Atualização: abril de 2026
Autor base: Cliente Exemplo, a empresa
Compilação: equipe de agentes Orquestradora
