---
name: incluir-modulo-erp
description: Ciclo de inclusão de módulo opcional num ERP modular já construído com o loop mestre (Fastify + React + PostgreSQL com RLS + BullMQ + Caddy). Use quando o pedido for incluir, ativar ou construir um módulo do pacote de opcionais (Vendas, Projetos e tarefas, Apontamento de horas, Recrutamento, Férias e ausências, Contabilidade, Fabricação, Manutenção, Tickets, Ponto de venda, Assinaturas, Despesas, Documentos e assinatura, Portal do cliente) em sistema cuja fase 1 já está no ar. Oferece dois modos: escolher módulos ou instalar todos em ondas pela ordem das dependências. Estuda o sistema, pergunta o que incluir, faz backup, constrói pela spec, revisa com regressão e faz deploy com canário.
---

# Incluir módulo no ERP modular

Sair de um ERP no ar e chegar no mesmo ERP com um módulo novo instalado, sem quebrar o que já funciona, com prova de fora. É o trilho "sistema que já existe" do loop mestre, especializado em módulo.

## 1. Estudar antes de perguntar

- Achar o repositório e o servidor. Ler `docs/LOOP-STATE.md`, `docs/CONTRATOS.md`, `docs/OWNERSHIP.md`, `specs/modulos.json`, a receita `model-modulo-erp` e um módulo já pronto como referência de forma (Cadastros).
- Levantar o que está instalado: tabela `modulos`, pasta `modules/`, itens da navegação, permissões existentes, versão no `/health`.
- Ler todas as specs em `specs/modulos-opcionais/`. Montar a tabela: módulo, existe no código (sim ou não), dependências construídas (sim ou não), menu de destino.

## 2. Escolha: dois modos

Pré-condição: provas P1 a P13 da fase 1 verdes. Se faltar alguma, parar e reportar qual.

Uma pergunta, com duas opções:

- **A · Escolher módulos.** O dono diz quais incluir. Validar dependências pela spec; dependência ausente (opcional ou padrão desligado na fase 1) entra no ciclo antes do módulo, com aviso em uma linha.
- **B · Instalar todos.** Construir todos os opcionais que ainda não existem, em ondas pela ordem das dependências:
  - Onda 0 · padrão que faltam e algum opcional exige (Cadastros, Financeiro, Contas, Estoque, Pessoas).
  - Onda 1 · Projetos e tarefas, Recrutamento, Férias e ausências, Contabilidade, Fabricação, Manutenção, Tickets e helpdesk, Ponto de venda, Assinaturas e recorrência, Despesas e reembolso, Documentos e assinatura, Portal do cliente, Vendas.
  - Onda 2 · Apontamento de horas (depende de Projetos e tarefas).

  Cada onda passa por build, review, deploy e instalação antes da seguinte. Falha numa onda: corrigir e retomar a mesma onda, sem refazer as anteriores.

Confirmar o tenant onde os módulos nascem ativos. Gravar o modo, a lista e as ondas em `docs/LOOP-STATE.md`.

## 3. Backup e rollback (inegociável)

- `pg_dump` fora da árvore do projeto, tag `pre-modulo-YYYYMMDD` empurrada.
- Lista de regressão: rotas e telas dos módulos vizinhos (quem o novo consome, quem consome o que ele toca), mais login, painel admin e `/health`. Comando de rollback escrito no LOOP-STATE antes do primeiro build.

## 4. Build

Ordem: dependências primeiro, depois o módulo. Para cada um, um agente com a spec, a receita, o padrão visual e a zona proibida (núcleo e outros módulos), entregando:

- `modules/<slug>/module.json` com nome, versão e `depende_de`.
- Migrations com prefixo do módulo, `tenant_id`, `workspace_id`, RLS, chave composta, soft delete.
- Agregados em `model/`, casos de uso em `use-case/`, consultas em `query/`, adapter Postgres, `routes.ts` com OpenAPI.
- Permissões geradas na instalação e ligadas aos papéis.
- Telas como abas no menu principal indicado na spec; item principal criado só se não existir.
- Seeds demo e testes (caso de uso em memória, `.http`, Playwright).
- Ponto de encaixe com outros módulos só por interface publicada, registrada em `docs/CONTRATOS.md`.

Registro no catálogo do sistema (`modulos`), instalação por `modulo:instalar <slug>` em ambiente local antes de qualquer deploy.

## 5. Review

Revisores independentes: spec do módulo (rodando as provas), segurança adversarial (ler registro do módulo de outro tenant, instalar sem permissão, webhook sem assinatura), visual (Playwright e greps de gradiente, emoji e travessão), robustez (estados vazio e de erro, mobile, i18n, fila parada). Lista de regressão dos vizinhos verde toda rodada. Módulo que mexe com dinheiro ou dado de cliente pede duas rodadas limpas.

## 6. Deploy e instalação

Deploy por SHA de uma cópia limpa, canário na porta reservada, rolling nas réplicas. Migrations do módulo idempotentes. Instalar pelo painel admin no tenant escolhido. Provar de fora: `/health` no SHA novo, rotas do módulo respondendo com sessão do tenant, 404 com sessão de outro tenant, screenshot de cada aba, desinstalar e reinstalar sem erro.

## 7. Fechamento

Atualizar `specs/modulos.json`, `docs/CONTRATOS.md`, `docs/OWNERSHIP.md`, `docs/LOOP-STATE.md`. Commit e push. Reporte com o nível de evidência de cada item e o comando de rollback.

## Invioláveis

- Nada fora da pasta do módulo, salvo catálogo, navegação e contratos.
- Núcleo só muda com aviso prévio em uma linha.
- Escopo de tenant vem da sessão. Toda tabela nova com RLS.
- Trabalho lento vai pra fila com outbox.
- Backup e tag antes do primeiro build. Regressão verde antes do deploy.
- "Concluído" só instalado no tenant e verificado de fora.
