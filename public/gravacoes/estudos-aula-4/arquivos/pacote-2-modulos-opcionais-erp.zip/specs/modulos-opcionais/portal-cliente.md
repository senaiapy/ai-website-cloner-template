# Módulo opcional: Portal do cliente

- Slug: `portal-cliente`
- Menu principal: Comercial
- Abas na página: Acesso do cliente, Faturas, Pedidos, Documentos
- Depende de: cadastros, contas
- Sidebar: não ganha item novo; entra como aba dentro de Comercial. Se o menu Comercial ainda não existir no tenant, o módulo cria o item principal.

## Escopo

Login próprio do cliente final (guard separado do usuário interno), com visão das suas faturas e pagamento por Pix, seus pedidos e agendamentos, documentos e assinaturas pendentes, abertura de ticket.

## Agregados e entidades

- AcessoCliente (raiz): cliente, email, senha_hash, ativo, ultimo_acesso
- Convite: cliente, token, expira_em

Toda tabela com `tenant_id`, `workspace_id`, `creator_id`, `created_at`, `updated_at`, `deleted_at`, RLS e chave composta. Prefixo de tabela `portal_cliente_`.

## Casos de uso

- ConvidarCliente
- AtivarAcesso
- ListarFaturasDoCliente
- PagarFatura (Pix)
- AbrirTicketDoPortal

Comando devolve void e passa por caso de uso; consulta devolve DTO. Entidade e objeto de valor com `create` e `tryCreate`. Result em vez de exceção. Trabalho lento (envio, geração de documento, job recorrente) vai pra fila com outbox.

## Rotas

`/api/v1/portal-cliente/...` descritas em OpenAPI antes do código: uma rota por caso de uso, listagens paginadas com filtro e ordenação, e a interface publicada que outros módulos consomem.

## Interfaces com outros módulos

- Contas a receber: faturas e pagamento
- Agenda: agendamentos
- Documentos: assinatura
- Tickets: abertura

Só por interface publicada, nunca por import interno.

## Permissões

`portal-cliente.ver`, `portal-cliente.criar`, `portal-cliente.editar`, `portal-cliente.excluir`, `portal-cliente.aprovar` quando houver aprovação, `portal-cliente.configurar`. Geradas na instalação e ligadas aos papéis existentes conforme a entrevista.

## Telas

Padrão visual do sistema: kicker, título, botão primário rosa, abas na página, cards e tabelas com estados vazio, carregando e erro, mobile sem scroll horizontal, i18n pt, en e es.

## Seeds e dados demo

Registros plausíveis com a marca demo do tenant, suficientes pra demonstrar cada aba.

## Provas exigidas

- Teste de cada caso de uso com repositório em memória.
- Arquivo `.http` com todas as rotas e resposta esperada.
- Screenshot Playwright de cada aba.
- Tentativa de ler registro deste módulo de outro tenant devolvendo 404.
- Instalar e desinstalar pelo painel admin sem erro, com bloqueio quando há dependente.
