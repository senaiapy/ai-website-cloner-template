# Módulo opcional: Ponto de venda

- Slug: `pdv`
- Menu principal: Operação
- Abas na página: Caixa, Mesas, Delivery, Fechamento
- Depende de: estoque, financeiro
- Sidebar: não ganha item novo; entra como aba dentro de Operação. Se o menu Operação ainda não existir no tenant, o módulo cria o item principal.

## Escopo

Tela de caixa rápida com leitura de código de barras, mesas e comandas para restaurante, pedidos de delivery, pagamento em Pix, cartão e dinheiro, fechamento de caixa por operador, funcionamento offline com sincronização pela fila.

## Agregados e entidades

- SessaoCaixa (raiz): operador, abertura, fechamento, saldo_inicial, saldo_final, estado
- VendaPDV (raiz): sessao, mesa ou delivery, itens[], pagamentos[], estado (aberta, paga, cancelada)
- Mesa: numero, capacidade, estado

Toda tabela com `tenant_id`, `workspace_id`, `creator_id`, `created_at`, `updated_at`, `deleted_at`, RLS e chave composta. Prefixo de tabela `pdv_`.

## Casos de uso

- AbrirCaixa
- RegistrarVenda (baixa estoque e lanca no financeiro via job)
- ReceberPagamento
- FecharCaixa
- SincronizarOffline

Comando devolve void e passa por caso de uso; consulta devolve DTO. Entidade e objeto de valor com `create` e `tryCreate`. Result em vez de exceção. Trabalho lento (envio, geração de documento, job recorrente) vai pra fila com outbox.

## Rotas

`/api/v1/pdv/...` descritas em OpenAPI antes do código: uma rota por caso de uso, listagens paginadas com filtro e ordenação, e a interface publicada que outros módulos consomem.

## Interfaces com outros módulos

- Estoque: baixa por item
- Financeiro: entrada por pagamento
- Fabricacao: ficha tecnica opcional

Só por interface publicada, nunca por import interno.

## Permissões

`pdv.ver`, `pdv.criar`, `pdv.editar`, `pdv.excluir`, `pdv.aprovar` quando houver aprovação, `pdv.configurar`. Geradas na instalação e ligadas aos papéis existentes conforme a entrevista.

## Telas

Padrão visual do sistema: kicker, título, botão primário rosa, abas na página, cards e tabelas com estados vazio, carregando e erro, mobile sem scroll horizontal, i18n pt, en e es.

## Seeds e dados demo

Registros plausíveis com a marca demo do tenant, suficientes pra demonstrar cada aba.

## Provas exigidas

- Teste de cada caso de uso com repositório em memória.
- Arquivo `.http` com todas as rotas e resposta esperada.
- Screenshot Playwright de cada aba.
- Tentativa de ler registro deste módulo de outro tenant devolvendo 404.
- Instalar e desinstalar pelo painel admin sem erro, com bloqueio quando há dependente.
