---
name: loop-mestre-erp-modular
description: Loop mestre de construção de sistemas Avalanche orientado para o ERP modular multi-tenant, com entrevista dos módulos iniciais (os 14 padrão do catálogo; os 14 opcionais ficam para o pacote 2, depois da fase 1 no ar), API REST e servidor MCP nativos para agentes (núcleo + módulos instaláveis, Fastify + React + PostgreSQL com RLS + Redis/BullMQ + Caddy). Use quando o pedido for construir, estender ou revisar o ERP modular, um módulo novo dele, ou adaptar o ERP a um nicho (clínica, escritório, restaurante, loja). Roda sozinho da spec até a entrega com prova.
---

# Loop mestre do ERP modular

Sair do pedido e chegar num ERP no ar, com login, módulos ligáveis pelo painel e prova de que cada peça funciona. O loop define o resultado de cada fase e as fronteiras que não se cruzam. O caminho técnico segue as nove camadas descritas no manual (`docs/MANUAL-CONSTRUCAO-ERP-MODULAR.md`).

**Fonte do escopo.** O que será construído está em `specs/ESPECIFICACAO-ITEM-A-ITEM.md`, com um código por item (I, B, N, F, M, D, P). No início do loop, copiar todos os códigos para `docs/LOOP-STATE.md` com estado pendente e atualizar a cada portão (pendente, feito, verificado). Nenhum item fora desse arquivo é construído. Os 14 módulos opcionais NÃO entram nesta fase: chegam pelo pacote 2 quando P1 a P13 estiverem verdes.

## Pergunta zero

Perguntar se é (a) ERP do zero, (b) módulo novo num ERP que já existe, ou (c) adaptação a um nicho. No trilho (b) e (c): achar o repositório, estudar núcleo, módulos instalados, contratos e telas antes de entrevistar; dump do banco e tag `pre-loop-YYYYMMDD` antes do primeiro build; lista de regressão dos módulos vizinhos, verde toda rodada.

Depois: entrevista, uma pergunta por vez, até "entendemos tudo, vai trabalhar". Daí o loop roda autônomo. Só volta com sistema pronto ou bloqueio real (credencial inexistente, decisão de negócio, acesso de terceiro).

## As 5 fases

| Fase | Resultado |
|---|---|
| 1 Spec | `specs/<nome>.md` com nicho, módulos a ligar, integrações, definição de concluído testável |
| 2 Arquitetura | As nove camadas conferidas: contrato OpenAPI das rotas, o que é síncrono e o que vai pra fila, topologia 1 ou 2, checklist dos 10 passos |
| 3 Build | Esqueleto, núcleo à mão, módulos por agente, cada peça com prova executável |
| 4 Review | Veredito por requisito contra o sistema real, quatro lentes, falhas devolvidas ao build |
| 5 Entrega | Verificação adversarial de fora, pacote fechado, reporte com prova |

Regra de nascença: repositório privado no GitHub antes da primeira linha de produção. Estado do loop em `docs/LOOP-STATE.md` a cada portão.

## Fase 1 · Spec e entrevista de módulos

A entrevista de módulos é obrigatória e vem antes de qualquer código. Ela usa `specs/CATALOGO-MODULOS.md` e oferece só os 14 módulos padrão, todos marcados, uma pergunta por vez:

1. Nicho e dono do tenant. Com o nicho, oferecer o perfil sugerido do catálogo como atalho para desligar os padrão que o negócio não usa (os opcionais do perfil ficam anotados para o pacote 2).
2. Cadastros e Comercial: Cadastros (fixo), Pipeline, Conversas.
3. Financeiro: Financeiro (fixo), Contas a receber e a pagar.
4. Operação e Agenda: Agenda, Estoque, Compras.
5. Pessoas: Pessoas (fixo), Benefícios e folha, Treinamento.
6. Integrações (fixo): quais conectores nascem ativos (WhatsApp Cloud API, Instagram Messenger, Google Calendar via Maton ou API direta, webhook de landing page, Pix e boleto via Asaas ou Stripe, players de vídeo, Resend) e quais agentes vão operar o ERP por MCP (Claude Code, OpenClaw, Hermes), para gerar as chaves e os snippets na entrega.
7. Topologia: 1 VPS (uso próprio) ou 2 ou mais com load balancer (revenda). Dados demo e idioma.

Se o dono pedir um opcional agora, responder em uma linha que ele entra pelo pacote 2 logo depois da fase 1 no ar, e anotar em `specs/modulos.json` no campo `opcionais_desejados`.

Cada resposta é validada contra as dependências do catálogo: escolher Compras sem Estoque faz o agente avisar e incluir Estoque. Painel admin, Configurações e Integrações entram sempre. O resultado vai para `specs/modulos.json` (nicho, topologia, módulos, integrações, opcionais_desejados) e a spec cita esse arquivo como fonte do escopo.

Além disso a spec cobre: quem é o dono do tenant, o que ele vai ver na primeira demonstração, e a definição de concluído testável.

## Fase 2 · Arquitetura

Conferir as nove camadas: VPS, systemd e infra como código; PostgreSQL com RLS, pgvector, migrations e backup; API Fastify com contrato OpenAPI, núcleo e módulos com dependência declarada; Redis, BullMQ, outbox e worker; Caddy, Cloudflare, sessão, RBAC e rate limit; webhooks assinados virando job; módulos de negócio do specs/modulos.json; React, tokens, temas e i18n; DNS, HTTPS, health check, deploy com canário e backup. Decisões anotadas na spec.

## Fase 3 · Build

**3.0 Esqueleto andante, um agente.** Repo, API em porta alta com `/health`, Caddy no domínio com HTTPS, Postgres migrado com tabelas do núcleo e RLS, login funcionando, sidebar vazia no padrão visual, deploy provado com curl 200 e screenshot do login. Verificar de fora antes de liberar o enxame.

**3.1 Núcleo à mão.** Usuários, papéis, tenants, workspaces, empresas, sequências, configurações, campos personalizados, auditoria, fila e outbox, sistema de módulos (`module.json`, instalar, desinstalar, tabela `modulos`), e a base de Integrações: registro de eventos para webhooks, anotação `@tool` que expõe caso de uso como tool MCP e rota da API pública, chaves de API com escopo, servidor MCP em `/mcp`. Especificação em `specs/INTEGRACOES-API-MCP.md` e itens N1 a N17 de `specs/ESPECIFICACAO-ITEM-A-ITEM.md`. Este é o único pedaço que não se delega: é a base que todos os módulos copiam.

**3.2 Fronteiras no repo.** `docs/OWNERSHIP.md` (um agente por módulo, zona proibida: núcleo e outros módulos) e `docs/CONTRATOS.md` (schema do banco, rotas por módulo, interfaces publicadas entre módulos, chaves i18n, tokens CSS).

**3.3 Receita de módulo.** Antes do fan-out, escrever a skill `model-modulo-erp` por engenharia reversa do primeiro módulo feito à mão (Cadastros): estrutura de pastas por agregado, entidade e objeto de valor com `create` e `tryCreate`, caso de uso com Result, repositório por porta, query, rotas, migrations com `tenant_id` e `workspace_id`, permissões, seeds, teste com repositório em memória e arquivo `.http`.

**3.4 Fan-out.** Um agente por módulo listado em `specs/modulos.json`, na ordem que a resolução de dependências do catálogo devolve (Cadastros e Pessoas primeiro, depois quem depende deles, e assim por diante). Módulo fora do arquivo não é construído, mas o sistema de módulos deixa ele ser instalado depois pelo painel admin. Cada agente recebe os itens M do seu módulo na especificação, contexto, propriedade, zona proibida, a receita, o padrão visual e a exigência de prova executável. Sem prova, não foi entregue.

## Fase 4 · Review

Revisores independentes, cegos entre si:
- Spec: requisito por requisito rodando as provas dos builders.
- Segurança adversarial: tentar ler dado de outro tenant por rota, por id, por webhook e por job; furar sessão; achar segredo em texto puro; instalar módulo sem permissão.
- Visual: Playwright nas telas, greps de gradiente, emoji e travessão.
- Robustez: N+1, estados vazio e de erro, mobile sem scroll horizontal, i18n e tema ao vivo, fila parada, Redis reiniciado.
Duas rodadas limpas seguidas antes de aprovar, porque o sistema mexe com dinheiro e dado de cliente.

## Fase 5 · Entrega

Login real com as credenciais do dono do tenant, módulos ligados e desligados pelo painel na frente da câmera, um agente MCP (Claude Code ou Hermes) conectado ao tenant demo listando e chamando tools, telas navegadas com screenshot, query no banco provando isolamento, probe externo no domínio, `/health` em 200, backup agendado, repositório igual à produção, credenciais no cofre. Provas P1 a P13 da especificação, todas verdes. Reporte curto com o nível de evidência de cada item e a indicação de que o pacote 2 (módulos opcionais) já pode ser aplicado.

## Invioláveis

- Escopo de tenant e workspace vem da sessão, nunca de header ou parâmetro.
- Toda tabela nova com `tenant_id`, `workspace_id`, RLS e chave composta.
- Trabalho lento vai pra fila, com outbox antes do Redis.
- Módulo não importa código interno de outro módulo.
- Zero gradiente, zero emoji, zero travessão, cor só por token.
- Segredo nunca no repositório. Caça de segredos antes de cada push.
- "Concluído" só com tudo verificado de fora.
