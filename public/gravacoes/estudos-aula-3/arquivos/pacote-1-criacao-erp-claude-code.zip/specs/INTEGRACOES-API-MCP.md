# Módulo padrão Integrações: conectores, webhooks, API e MCP

Menu principal `Integrações`, presente em todo tenant. Abas na página: Conectores, Webhooks, API, MCP. É o módulo que deixa o ERP ser operado por agentes (Claude Code, OpenClaw, Hermes ou qualquer cliente MCP) e ligado a sistemas externos sem tocar no núcleo.

## Como os agentes se conectam

Os três agentes falam MCP (Model Context Protocol) por transporte Streamable HTTP e autenticam com um cabeçalho `Authorization: Bearer <chave>`. A URL do servidor termina em `/mcp`. Cada um declara o servidor num arquivo de configuração próprio:

**Claude Code** (`.mcp.json` no projeto, ou o comando abaixo):

```bash
claude mcp add --transport http erp https://erp.suaempresa.com.br/mcp \
  --header "Authorization: Bearer erp_live_..."
```

```json
{ "mcpServers": { "erp": { "type": "http", "url": "https://erp.suaempresa.com.br/mcp",
  "headers": { "Authorization": "Bearer erp_live_..." } } } }
```

**OpenClaw** (`mcpServers` na configuração do gateway, transporte `streamable-http`, URL terminando em `/mcp`):

```json
{ "mcpServers": { "erp": { "transport": "streamable-http", "url": "https://erp.suaempresa.com.br/mcp",
  "headers": { "Authorization": "Bearer ${ERP_MCP_TOKEN}" } } } }
```

**Hermes** (`mcp_servers` em `~/.hermes/config.yaml`; servidor local usa `command` e `args`, servidor remoto usa `url` e `headers`):

```yaml
mcp_servers:
  erp:
    url: https://erp.suaempresa.com.br/mcp
    headers:
      Authorization: "Bearer ${ERP_MCP_TOKEN}"
```

A aba MCP gera esses três snippets já preenchidos com a URL do tenant e a chave recém-criada.

## Aba Conectores

Cada conector é um plugin com credencial do tenant guardada no cofre, status (conectado, expirado, erro), botão de testar conexão e reconexão.

| Conector | Protocolo | O que faz |
|---|---|---|
| WhatsApp Cloud API | Graph API da Meta, webhook | Número oficial, templates aprovados, mensagens e status na tela de Conversas, lembretes da Agenda e cobranças |
| Instagram Messenger API | Graph API da Meta, webhook | Direct da conta comercial na tela de Conversas |
| Google Calendar | Maton ou OAuth Google direto | Calendários escolhidos, sincronização bidirecional com a Agenda |
| Players de vídeo | YouTube, Vimeo, Panda Video, Bunny Stream | Treinamento guarda só o id do vídeo |
| Pagamentos | Asaas ou Stripe, webhook | Pix, boleto e cartão para Contas a receber e Assinaturas |
| E-mail transacional | Resend | Domínio verificado, templates de cobrança, convite e recuperação de senha |

Tabela `integracoes_conectores`: tenant, workspace, tipo, estado, credencial_ref (referência no cofre, nunca o segredo), config (jsonb), ultimo_teste, ultimo_erro.

## Aba Webhooks

**Saída.** Assinatura por evento do catálogo. Cada módulo publica seus eventos (`cliente.criado`, `oportunidade.movida`, `fatura.paga`, `agenda.confirmado`, `estoque.abaixo_minimo`, `folha.fechada`). Assinatura tem URL de destino, segredo HMAC-SHA256, filtros por evento, estado. Entrega assinada com cabeçalhos `X-ERP-Signature` (HMAC do corpo) e `X-ERP-Timestamp` (anti-replay, janela de 5 minutos), enviada pela fila com retry exponencial (1 min, 5 min, 30 min, 2 h, 12 h), log de entregas com status, payload e resposta, reenvio manual, desativação automática após 20 falhas seguidas com aviso ao dono.

Tabelas: `integracoes_webhook_assinaturas` (tenant, workspace, url, segredo_ref, eventos[], estado, falhas_seguidas) e `integracoes_webhook_entregas` (assinatura, evento, payload, tentativa, status_http, resposta, proxima_tentativa).

**Entrada.** Um endpoint por conector em `/api/v1/webhooks/<conector>/<tenant_token>`, com validação de assinatura do provedor (`X-Hub-Signature-256` da Meta, token do Asaas, assinatura do Stripe, token do formulário de landing page), idempotência pelo id do evento, gravação em `integracoes_eventos_recebidos` e enfileiramento. Nada executa dentro da request. Rate limit por endpoint.

## Aba API

REST versionada em `/api/v1`, a mesma que o frontend usa, documentada em OpenAPI 3.1 em `/api/docs`.

- Chave por workspace: prefixo visível (`erp_live_a1b2`), hash no banco, escopo por módulo (leitura, escrita), expiração e rotação. A chave completa aparece uma vez.
- Rate limit por chave (padrão 600 req/min, configurável por plano). `Idempotency-Key` obrigatório em POST que cria documento financeiro.
- Paginação por cursor, filtros e ordenação padronizados, erros com `code`, `message` e `details`.
- Sandbox: workspace demo com dados plausíveis para o integrador testar.
- Toda chamada passa pelo RBAC do papel ligado à chave e pelo RLS do tenant. Auditoria em `integracoes_api_chamadas` (chave, rota, status, latência, ip).

Tabela `integracoes_api_chaves`: tenant, workspace, nome, prefixo, hash, escopos[], papel, expira_em, ultimo_uso, estado.

## Aba MCP

Servidor MCP nativo no próprio backend, transporte Streamable HTTP em `/mcp`, JSON-RPC conforme a especificação do protocolo (versão 2025-06-18 ou posterior).

- **Tools** geradas automaticamente por módulo instalado, a partir dos casos de uso e consultas expostos com anotação `@tool`: nome `modulo.acao` (`clientes.listar`, `clientes.criar`, `oportunidade.mover`, `fatura.criar`, `fatura.baixar`, `agenda.disponibilidade`, `agenda.agendar`, `estoque.saldo`, `pedido_compra.criar`), schema de entrada em JSON Schema derivado do DTO, descrição em PT-BR, marcação de leitura ou escrita.
- **Resources**: `erp://schema/<modulo>` (schema dos agregados) e `erp://<modulo>/<id>` (registro), com paginação.
- **Prompts** prontos por tarefa: "qualificar oportunidade", "cobrar fatura vencida", "montar agenda da semana".
- **Autenticação**: Bearer com chave de API da aba API (escopo por módulo vale para as tools). OAuth 2.1 com PKCE opcional para clientes que exigem, com o ERP como servidor de autorização.
- **Escopo e RBAC**: a tool só aparece na listagem se a chave tem o escopo e o papel tem a permissão; chamada fora do escopo devolve erro padronizado e fica na auditoria.
- **Auditoria** em `integracoes_mcp_chamadas`: chave, tool, argumentos (com segredos mascarados), resultado, latência, tenant.
- **Limites**: timeout por tool (30 s padrão; tool lenta enfileira e devolve id de job com `jobs.status`), concorrência por chave, tamanho máximo de resposta.
- **Tela**: URL do servidor, status, lista de tools por módulo com toggle, snippets para Claude Code, OpenClaw e Hermes, últimas chamadas.

## Dependências e encaixe

Integrações é padrão e depende só do núcleo. Os outros módulos se ligam a ele por interface publicada: registram eventos no catálogo de webhooks, expõem casos de uso como tools com a anotação `@tool`, e consomem conectores pelo serviço `conectores.obter(tipo)`. Conversas, Agenda, Contas a receber, Assinaturas e Treinamento dependem dos conectores correspondentes estarem ativos; sem o conector, a funcionalidade aparece desativada com o link para esta tela.

## Provas exigidas no build

- `/api/docs` servindo o OpenAPI com todas as rotas dos módulos instalados.
- Chave criada, chamada com escopo devolvendo 200, chamada fora do escopo devolvendo 403, chave de outro tenant devolvendo 404.
- Cliente MCP de teste listando as tools da chave, chamando `clientes.listar` com sucesso e recebendo erro em tool sem escopo.
- Webhook de saída entregue com assinatura válida num receptor de teste, retry após falha simulada, reenvio manual.
- Webhook de entrada com assinatura inválida rejeitado, com assinatura válida gravado e enfileirado, evento duplicado ignorado.
- Snippets dos três agentes copiados e conectados de fato ao servidor MCP do tenant demo.
