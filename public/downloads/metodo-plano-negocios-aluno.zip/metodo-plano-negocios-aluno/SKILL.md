---
name: metodo-plano-negocios-aluno
description: Roteiro completo pra estruturar um plano de negócios personalizado pra cada aluno de mentoria de IA. Diagnóstico, definição de oferta, ciclo de vendas, projeção de faturamento, cronograma e checkpoints semanais. Metodologia o padrão. Use quando o dono pedir esse tipo de tarefa.
---

# Plano de Negócios do Aluno em Mentoria

> Metodologia o padrão #3/11. Tarefa operacional: a Naia delega (Juliana coordena), valida e entrega pro dono.

Roteiro completo pra estruturar um plano de negócios personalizado pra cada aluno de mentoria de IA. Diagnóstico, definição de oferta, ciclo de vendas, projeção de faturamento, cronograma e checkpoints semanais.

## Quando usar
- Você é mentor e precisa estruturar plano por aluno
- Aluno está perdido sem rumo claro
- Aluno tem ideia mas não sabe operacionalizar
- Quer entregar valor além de aulas

## Entregáveis
- Documento HTML navegável com plano de 90 dias
- Diagnóstico de competências
- Oferta em 1 frase
- Projeção financeira detalhada
- Cronograma semanal com KRs

## Tags
mentoria, ia, plano

## Passo-a-passo completo (LOCAL — fonte canônica)
O passo-a-passo detalhado completo (etapas + código) está em **`./reference.md`** (nesta skill).
LER `reference.md` antes de executar este método.

