---
name: landing-avelloia
description: "Layout AVELLOIA, a estetica neo-brutalista de fundo creme com acento laranja ember (#ff5a1f) que o dono amou no site seudominio.com. Use sempre que ele pedir \"faz uma landing no estilo avelloia\", \"monta um site naquele layout do playbook\", \"no estilo daquele site neo-brutalista laranja\", \"landing creme com laranja ember\", ou quando uma pagina nova precisar desse visual (Space Grotesk + DM Sans + Geist Mono, sombras duras offset, chips, marquee, infograficos por secao). Traz o design system completo em tokens, os componentes com snippets reais e o passo a passo pra montar uma landing nova do zero. Tarefa de codigo: a Naia NAO executa, delega pro Paulo, que segue esta skill e devolve pra Naia entregar pro dono."
---

# Landing AVELLOIA - layout neo-brutalista creme + ember

> Skill mestra do layout que o dono amou em **seudominio.com** (clone fiel da estetica da avelloia.cloud).
> **Tarefa de codigo: a Naia delega pro Paulo.** Ele monta seguindo esta skill, valida e devolve pra Naia entregar pro dono.
> Regra da casa nesta doc e no codigo gerado: **PT-BR, zero travessao** (usar virgula, ponto ou parenteses no lugar do traco longo).

---

## 🎯 O QUE E E QUANDO USAR

O AVELLOIA e um layout de landing **neo-brutalista premium**: fundo creme quente, um unico acento laranja ember forte, tipografia ousada em caixa alta, sombras solidas com offset (sem blur), animacoes sutis de scroll e uma secao por ideia com infografico do lado. Passa autoridade editorial sem parecer "feito por IA".

**Ative esta skill quando o dono pedir, por exemplo:**
- "faz uma landing no estilo avelloia" / "naquele layout do playbook"
- "aquele site neo-brutalista laranja com fundo creme"
- "monta uma pagina densa com infografico por secao igual o playbook"
- qualquer landing/site de conteudo, estudo, manifesto, proposta publica ou autoridade que se beneficie desse visual

**NAO use** pra: CRM/app interno (la vale UX funcional, nao este visual), carrossel de Instagram (skill `carrossel-instagram-publicacao`), proposta comercial single-page com tabs (skill `metodo-criacao-propostas`).

**Referencia viva:** `reference/index-exemplo.html` (template limpo com placeholders) + `reference/base.css` (CSS completo pronto pra copiar) + `reference/base.js` (interacoes) + `reference/avelloia-original.css` (o CSS original da fonte, so pra consulta de nuance).

---

## 🎨 DESIGN SYSTEM (TOKENS) - copiar VERBATIM

Estes tokens sao a assinatura do layout. Vao inteiros no `:root` do `style.css`. **NAO inventar cor nova, nao trocar fonte, nao suavizar sombra.** Se faltar uma cor, derivar harmonica das que existem, nunca uma cor solta.

### Cores (light mode, o unico modo do layout)
| Token | Hex | Uso |
|---|---|---|
| `--bg` | `#faf5ec` | Fundo geral (creme quente premium) |
| `--bg-alt` | `#f8f1e7` | Fundo de secoes intercaladas (`.section.alt`) |
| `--surface` | `#ffffff` | Cards, molduras, chips |
| `--fg` | `#1b1714` | Texto principal (quase preto quente) e cor das bordas/sombras |
| `--fg-muted` | `#6c6253` | Texto secundario, legendas, rotulos |
| `--ember` | `#ff5a1f` | **ACENTO PRINCIPAL** (laranja ember) |
| `--ember-dk` | `#b8380a` | Ember escuro: eyebrow, italico de enfase, hover |
| `--ember-lt` | `#ff8a3d` | Ember claro: hover do botao |
| `--line` | `#e8dccb` | Linhas/divisorias finas e a grade do hero |
| `--ink` | `#160f0a` | Preto puro pra contraste maximo (footer, texto sobre ember) |
| `--lime` | `#00bb7f` | Verde, com PARCIMONIA, so destaque pontual tipo "fato" |
| `--danger` | `#dc2626` | Vermelho, so pra "mito"/erro/anti-padrao |
| `--gold` | `#c98a00` | Dourado, destaque positivo pontual (chip gold) |
| `--white` | `#ffffff` | Branco |

> A fonte original usa exatamente estes hex. Confirmado no `avelloia-original.css`: ember #ff5a1f (20 ocorrencias), ember-dk #b8380a, bg #faf5ec, fg #1b1714, ink #160f0a, lime #00bb7f.

### Sombras BRUTAIS (a assinatura, offset solido SEM blur)
```css
--shadow-brutal:5px 5px 0 0 var(--fg);     /* card/botao padrao */
--shadow-brutal-lg:8px 8px 0 0 var(--fg);  /* hover / moldura grande */
--shadow-ember:6px 6px 0 0 var(--ember);   /* destaque ember */
```
Regra de hover universal do layout: o elemento **desloca** `translate(-2px,-2px)` (ou -3px) **e a sombra cresce** (ex: de 5px pra 8px). Transicao curta, 140ms a 180ms ease. Nunca usar sombra com blur (`0 4px 12px rgba(...)`) neste layout, quebra a identidade.

### Tipografia
Tres familias, cada uma com um papel fixo:
- **Titulos / display:** `"Space Grotesk"`, peso **700**, **CAIXA ALTA** nos headers grandes, `letter-spacing:-.025em` (levemente negativo). H1 enorme via `clamp(2.3rem, 1.7rem + 6vw, 6.2rem)`, `line-height:.97`.
- **Corpo:** `"DM Sans"`, 400/500, `line-height:1.62`.
- **Detalhes / labels / eyebrows / numeros de stat:** `"Geist Mono"` (monoespacada), `text-transform:uppercase`, `letter-spacing` de `.08em` a `.14em`, tamanho pequeno (`.72rem` a `.92rem`). Usar em: eyebrow ("// 01 · TESE"), tags, chips, legenda de infografico, fonte/creditos, nav.

Tokens de fonte:
```css
--font-display:"Space Grotesk", ui-sans-serif, system-ui, sans-serif;
--font-body:"DM Sans", ui-sans-serif, system-ui, sans-serif;
--font-mono:"Geist Mono", ui-monospace, "SFMono-Regular", Menlo, monospace;
```
Carregar via Google Fonts no `<head>` (link unico, ja pronto no template):
```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,700&family=Geist+Mono:wght@400;500;600&family=Space+Grotesk:wght@500;600;700&display=swap" rel="stylesheet">
```

### Bordas, radius e grid
```css
--container:1180px;                       /* largura maxima do conteudo */
--pad-x:clamp(1.25rem, 5vw, 3rem);        /* padding lateral */
--sec-pad-y:clamp(4.5rem, 9vw, 8.5rem);   /* padding vertical de secao (generoso) */
```
- **Radius pequeno** (neo-brutalista = cantos quase retos): **4px a 8px**. Card/botao usam 5px ou 6px, moldura de infografico 8px. NUNCA cantos super arredondados (`border-radius:20px+` mata o estilo).
- **Borda padrao de elemento brutal:** `2px solid var(--fg)` + uma das `--shadow-brutal`.
- **Divisoria de secao:** `border-bottom:2px solid var(--fg)` em cada `.section`.
- Espacamento **generoso**: muito whitespace entre blocos, secoes altas.

### Animacoes
- **Reveal no scroll:** elemento entra com `opacity 0 -> 1` + `translateY(26px -> 0)` via IntersectionObserver (classe `.reveal` ganha `.is-visible`), com stagger leve por posicao. Logica pronta no `base.js`.
- **Hover brutal** em card/botao/chip/nav: translate + sombra cresce (descrito acima).
- **Marquee** horizontal opcional: faixa ember com termos correndo (`@keyframes marquee` translateX -50%, duas copias do texto lado a lado pra loop perfeito).
- Sempre respeitar `prefers-reduced-motion` (desliga transforms e marquee), ja tratado no `base.css`.

---

## 🧩 COMPONENTES (com snippets reais)

Todos os snippets abaixo ja funcionam com o `base.css`. O HTML completo de cada um esta em `reference/index-exemplo.html`.

### 1. Navbar sticky
Logo (glifo `›‹` num quadrado ember + nome em duas linhas), navegacao numerada mono, CTA escura com sombra ember, e botao MENU no mobile.
```html
<header class="site-header" id="top">
  <a class="brand" href="#top">
    <span class="brand-mark">&rsaquo;&lsaquo;</span>
    <span class="brand-text">NOME DA<br>MARCA</span>
  </a>
  <nav class="site-nav" aria-label="Secoes">
    <a href="#s1">01</a><a href="#s2">02</a><a href="#s3">03</a>
  </nav>
  <a class="nav-cta" href="#" target="_blank" rel="noopener">@voce.ai</a>
  <button class="nav-toggle" aria-label="Abrir menu" aria-expanded="false">MENU</button>
</header>
```
Detalhe: fundo `rgba(250,245,236,.86)` + `backdrop-filter:blur(10px)` + `border-bottom:2px solid var(--fg)`. A `.brand-mark` e um quadrado ember com sombra dura.

### 2. Hero
Eyebrow mono, titulo gigante em caixa alta (parte em `<span class="ember">` pra colorir), subtitulo, citacao com barra ember a esquerda, fileira de stats (numeros gigantes Space Grotesk) e botao brutal. O fundo do hero tem **grade fina** (duas `repeating-linear-gradient` com `--line`) + **glow ember** (`radial-gradient`).
```html
<section class="hero">
  <div class="container">
    <p class="eyebrow">// EYEBROW &middot; CONTEXTO &middot; ANO</p>
    <h1 class="hero-title">TITULO<br>FORTE<br><span class="ember">EM EMBER.</span></h1>
    <p class="hero-sub">Subtitulo curto com a promessa central.</p>
    <blockquote class="hero-quote">&ldquo;Frase de efeito que ancora a tese.&rdquo;</blockquote>
    <div class="hero-stats">
      <div class="stat"><span class="stat-num">42%</span><span class="stat-label">rotulo curto</span></div>
      <div class="stat"><span class="stat-num">4</span><span class="stat-label">segundo dado</span></div>
    </div>
    <a class="btn-brutal" href="#s1">Chamada pra acao &rsaquo;</a>
  </div>
</section>
```

### 3. Botao brutal
```html
<a class="btn-brutal" href="#">Texto do botao &rsaquo;</a>
<a class="btn-brutal big" href="#">Versao grande &rsaquo;</a>
```
Fundo ember, texto ink, borda 2px preta, sombra dura. Hover: desloca e sombra cresce, fundo vira ember-lt.

### 4. Marquee (faixa ember correndo)
```html
<div class="marquee" aria-hidden="true">
  <div class="marquee-track">
    <span>FRASE UM &nbsp;&rsaquo;&lsaquo;&nbsp; FRASE DOIS &nbsp;&rsaquo;&lsaquo;&nbsp;</span>
    <span>FRASE UM &nbsp;&rsaquo;&lsaquo;&nbsp; FRASE DOIS &nbsp;&rsaquo;&lsaquo;&nbsp;</span>
  </div>
</div>
```
**Importante:** duplicar o `<span>` identico (duas copias) pro loop ser continuo. Separador padrao entre frases: `›‹`.

### 5. Secao padrao (texto + infografico)
A unidade que se repete. `.sec-grid` = duas colunas (texto + figura). Alternar `.section` / `.section.alt` (fundo) e `.sec-grid` / `.sec-grid.reverse` (lado do infografico) a cada bloco, pra criar o zigue-zague.
```html
<section class="section alt" id="s2">
  <div class="container sec-grid reverse">
    <div class="sec-text reveal">
      <p class="eyebrow">// 02 &middot; ROTULO</p>
      <h2 class="sec-title">Titulo da secao</h2>
      <p>Corpo com <em>enfase em italico ember</em> nas frases-chave.</p>
    </div>
    <figure class="infografico reveal">
      <img src="infografico-2.png" alt="Descricao" loading="lazy" width="1536" height="1024">
      <figcaption>// FIG. 02 &middot; LEGENDA</figcaption>
    </figure>
  </div>
</section>
```

### 6. Slot de infografico
`<figure class="infografico">` = moldura branca com borda 2px, radius 8px, sombra dura grande e legenda mono embaixo. Imagem dentro com `loading="lazy"` e `width/height` setados (evita layout shift). Proporcao usada no playbook: **1536x1024** (paisagem). Os infograficos sao gerados a parte (ver secao de imagens) e ficam na mesma pasta do `index.html`.

### 7. Chips (tags brutais)
```html
<div class="chip-grid">
  <span class="chip">Conceito neutro</span>
  <span class="chip danger">Anti-padrao</span>
  <span class="chip gold">Destaque positivo</span>
</div>
```
Tres variantes: padrao (borda/sombra preta), `.danger` (vermelho, pra riscos) e `.gold` (dourado, pra positivos).

### 8. Fechamento (fundo escuro + quotes + CTA)
`.section.closing` inverte o esquema: fundo `--fg` escuro, texto creme. Grade de `blockquote` mono brutais (uma com `.big` ocupa a largura toda em ember). Termina com `.closing-statement`, `.closing-cta` (botao grande) e `.source` (creditos mono).
```html
<section class="section closing" id="s4">
  <div class="container">
    <p class="eyebrow center">// O QUE FICA</p>
    <h2 class="sec-title center">As frases que resumem o jogo</h2>
    <div class="quotes">
      <blockquote class="reveal">&ldquo;Citacao curta.&rdquo;</blockquote>
      <blockquote class="reveal big">&ldquo;A frase mais forte, em destaque.&rdquo;</blockquote>
    </div>
    <p class="closing-statement reveal">Paragrafo que amarra a tese.</p>
    <div class="closing-cta reveal"><a class="btn-brutal big" href="#">@voce.ai &rsaquo;</a></div>
    <p class="source">// Fonte &middot; creditos &middot; assinatura</p>
  </div>
</section>
```

### 9. Footer
Fundo `--ink` (preto), glifo da marca + uma linha mono centralizada.
```html
<footer class="site-footer">
  <div class="container footer-inner">
    <span class="brand-mark">&rsaquo;&lsaquo;</span>
    <p>NOME DA MARCA &middot; tagline &middot; @voce.ai</p>
  </div>
</footer>
```

---

## 🛠️ PASSO A PASSO - montar uma landing nova neste layout

1. **Criar a pasta** da landing em `/tmp/<nome-landing>/` (path sem acento). Copiar pra dentro: `base.css` da skill como `style.css`, `base.js` como `script.js`, e `index-exemplo.html` como `index.html`.
   ```bash
   D=/tmp/minha-landing && mkdir -p "$D"
   SK=~/seu-app/.claude/skills/landing-avelloia/reference
   cp "$SK/base.css" "$D/style.css"
   cp "$SK/base.js"  "$D/script.js"
   cp "$SK/index-exemplo.html" "$D/index.html"
   ```
2. **NAO tocar no `style.css`** (a menos que precise de um componente novo). Os tokens e componentes ja estao prontos. Toda a personalizacao e no `index.html`.
3. **Definir a estrutura de conteudo:** uma ideia por secao. Hero + (N secoes texto+infografico, alternando `.alt` e `.reverse`) + fechamento + footer. O playbook usou 10 secoes; landing menor pode usar 4 a 6.
4. **Escrever o conteudo** trocando os placeholders do `index.html`: titulo do hero (caixa alta, parte em `.ember`), eyebrows numeradas (`// 01 · ROTULO`), corpo com `<em>` ember nas frases-chave, stats, chips, quotes de fechamento. Atualizar `<title>`, `description` e og tags. **Zero travessao no texto.**
5. **Gerar os infograficos** (um por secao, padrao 1536x1024) e salvar na pasta como `infografico-1.png`, `infografico-2.png`, etc. Seguir a skill de imagem da casa (`gpt-image-2` por padrao). Atencao conhecida: o gpt-image-2 as vezes come acento ou poe travessao DENTRO da imagem; se for critico, fazer overlay de texto via HTML+Chrome (como no carrossel) ou pedir OK pro dono.
6. **Conferir o checklist QA** (abaixo) e abrir local pra ver:
   ```bash
   open /tmp/minha-landing/index.html
   ```
7. **Deploy** (padrao do dono): repo privado em `seu-usuario` > Vercel > Cloudflare DNS (A record pro IP `76.76.21.21`, dominio tipo `<nome>seudominio.com` ou `seudominio.com`). Detalhe do fluxo na skill `metodo-criacao-propostas`/`metodo-criacao-landing-pages`. Toda alteracao vai pro GitHub.

### Checklist QA (validar ANTES de entregar)
- [ ] Fontes carregando (Space Grotesk no titulo, Geist Mono nos eyebrows/chips, DM Sans no corpo). Se nao, conferir o link do Google Fonts.
- [ ] Acento ember presente e unico (sem segunda cor de destaque competindo).
- [ ] Sombras duras com offset (sem blur) em cards, botoes, chips, infograficos.
- [ ] Reveal no scroll funcionando (elementos entram suaves) e marquee correndo.
- [ ] Secoes alternando fundo (`.alt`) e lado do infografico (`.reverse`).
- [ ] Todos os `infografico-N.png` carregando (sem imagem quebrada).
- [ ] **Zero travessao** no HTML (usar `grep` por traco longo no arquivo).
- [ ] Responsivo: testar largura mobile (nav vira MENU, grid colapsa pra 1 coluna).
- [ ] `<title>`, meta description e og tags preenchidos.

---

## 🚫 ANTI-PADROES (o que NAO fazer)

- **NAO** mexer nos tokens do `:root` nem nas sombras `--shadow-brutal*`. Sao a identidade. Trocar a cor ember ou suavizar a sombra descaracteriza o layout.
- **NAO** trocar as fontes. Space Grotesk + DM Sans + Geist Mono e a tripa do estilo. Nada de Inter, Roboto, Arial, system-ui como fonte principal.
- **NAO** usar sombra com blur (`box-shadow:0 4px 12px rgba(...)`). Neste layout, sombra e sempre solida com offset.
- **NAO** arredondar muito (`border-radius` grande). Cantos quase retos (4 a 8px).
- **NAO** usar gradiente agressivo como fundo de secao. O unico gradiente do layout e a grade fina + glow sutil do hero.
- **NAO** colocar duas cores de destaque brigando. Ember manda; lime/gold/danger entram so pontual e com significado (fato/positivo/erro).
- **NAO** usar travessao na doc nem no codigo gerado (regra da casa). Virgula, ponto ou parenteses.
- **NAO** desenhar infografico em SVG na unha nem inventar grafico sem funcao ("data slop"). Infografico e imagem gerada de verdade, uma por secao, com proposito.
- **NAO** deixar `const styles = {}` generico se algum dia virar React: nomear unico por componente. (No estatico isso nao se aplica, mas vale se portar.)
- **NAO** trabalhar em pasta com acento no caminho (quebra render/ferramentas no Mac). Usar `/tmp/<nome-sem-acento>/`.

---

## 📎 RESUMO DOS ARQUIVOS DA SKILL
- `SKILL.md` (este arquivo): o que e, quando usar, design system em tokens, componentes com snippets, passo a passo, anti-padroes.
- `reference/base.css`: CSS completo do layout, validado em producao. Copiar como `style.css`.
- `reference/base.js`: reveal no scroll + menu mobile. Copiar como `script.js`.
- `reference/index-exemplo.html`: template limpo com placeholders e todos os componentes. Copiar como `index.html` e trocar o conteudo.
- `reference/avelloia-original.css`: CSS original da fonte (avelloia.cloud), minificado, so pra consulta de nuance. Nao usar direto (e cheio de utilitarios Tailwind alheios ao nosso template).
