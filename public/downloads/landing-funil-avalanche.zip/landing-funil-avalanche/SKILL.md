---
name: landing-funil
description: "Montar página de funil/landing no layout EDITORIAL do método (estilo \"jornal tech bege coral\", o mesmo das páginas seudominio.com e seudominio.com). Use sempre que o dono pedir uma página nova do funil (captura, VSL, carta de vendas, upsell, downsell, obrigado, página de aula/passo a passo) OU pedir pra \"fazer no layout do funil novo\", \"no estilo da página do método\", \"igual o funil do método\". Cobre o design system completo em tokens (tema CLARO e tema ESCURO body.theme-dark), os componentes com snippets reais (navbar Ø Premium, eyebrow, barra de oferta, cards, accordion details/summary, finalcta, rodapé megaword), o passo a passo de montar página do zero e a regra de quando usar claro x escuro. Tudo amarrado num único base.css compartilhado. Tarefa de código: a Naia NÃO executa, delega pro Paulo."
---

# Landing / Funil Premium · Layout Editorial (bege + coral + navy)

> Skill pra montar QUALQUER página do funil do método já no visual certo, sem reinventar.
> O layout é editorial tech: papel bege quente, acento coral, texto navy quase preto, serifa italic Playfair nos detalhes, mono JetBrains nas labels. Cara de "revista/jornal de negócio digital", não de SaaS genérico.
> **Esta é tarefa de código: a Naia NÃO executa, delega pro Paulo**, que monta a página, valida e devolve pra Naia entregar pro dono.

Páginas que JÁ rodam neste layout (referência viva):
- `seudominio.com` é o funil VSL completo (captura, VSL1, VSL2, upsell1, upsell2, downsell). Fonte em `/opt/funil-metodo-claw/static/`.
- `seudominio.com` é a página de aula "como construímos o funil", com accordion por fase. Fonte em `/opt/funil/static/`.

Os dois sites usam **o MESMO `base.css`** (mesmos tokens, mesmos componentes). A única diferença é que o `base.css` do método inclui o bloco do **tema escuro** (`body.theme-dark`) usado nas páginas de pós-compra. Tudo está no `reference/base.css` desta skill.

---

## 🧠 O QUE É ESTE LAYOUT (o feel)

Editorial impresso encontrando tech. Os ingredientes que dão a "alma":
- Fundo **papel bege** (`#efe7d2`) com textura de ruído sutil (SVG fractalNoise em `body::before`, opacity .06, multiply) e dois glows quentes nos cantos (`body::after`).
- **Faixa de metadados** no topo (metastrip) tipo cabeçalho de jornal: "DOC · FUNIL VSL", "8 fases", e um selo "AO VIVO" pulsando.
- **Trilhos verticais** nas laterais (`.rail`) com texto rotacionado em mono (some abaixo de 1280px).
- Numeração romana e estrela nas regras de seção (`.sec-rule .rom`).
- Serifa **Playfair Display italic** só em detalhes (o "Ø" da marca, números de card, ênfases), nunca em corpo de texto.
- Acento **coral** (`#ed6f5c`) em CTAs, links de status, bordas de destaque. Verde **olive** pra "concluído". Mostarda só pontual.
- Botões pílula (`border-radius:999px`), cards com sombra longa e suave, hover sutil (`translateY(-2px/-3px)`).
- Animação de entrada `.reveal` (fade + slide up) via IntersectionObserver.

Quando bater dúvida de "tá com cara de Premium?": papel bege + coral + serifa italic nos detalhes + mono nas labels = sim. Gradiente roxo, Inter solto, card com borda-esquerda colorida genérica = não, fugiu.

---

## 🎨 DESIGN SYSTEM · TOKENS

Tudo vive em CSS vars no `:root` do `base.css`. NÃO inventar cor solta: usar a var. Pra montar página nova é só linkar o `base.css` e usar as classes; os tokens abaixo são pra entender/ajustar.

### Fontes (carregar SEMPRE no `<head>`, antes do base.css)

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter+Tight:ital,wght@0,400;0,500;0,600;0,700;0,800;0,900;1,500&family=Inter:wght@300;400;500&family=Playfair+Display:ital,wght@1,500;1,600&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/base.css">
```

| Papel | Var | Família | Uso |
|---|---|---|---|
| Display / títulos / botões / labels | `--font-display` | **Inter Tight** | h1/h2/h3, `.btn`, eyebrow, tags |
| Corpo de texto | `--font-body` | **Inter** | parágrafos, `.lead`, inputs |
| Serifa de detalhe | `--font-serif` | **Playfair Display** *(italic)* | "Ø" da marca, números de card, ênfases `<em>`, aspas |
| Mono / etiqueta | `--font-mono` | **JetBrains Mono** | coordenadas, status, chips, captions, contador |

> O `<head>` da página de aula usa pesos um pouco diferentes (`Inter+Tight:wght@500..900` sem ital, `Inter:wght@400..700`). Os dois funcionam. Pra página de funil/venda usa o `<head>` acima (com ital no Inter Tight, que habilita o italic dos números).

### Cores · TEMA CLARO (padrão: captura, VSL, venda)

```css
--paper:#efe7d2;        /* fundo principal (bege papel) */
--paper-warm:#ece4cf;   /* fundo alternado / seção ruim do VS */
--paper-dark:#ddd2b6;   /* bege escuro, texto sobre fundo navy */
--bone:#f7f1de;         /* fundo de cards e inputs (mais claro que o paper) */
--ink:#15140f;          /* TEXTO principal (navy quase preto) */
--ink-soft:#2a2620;     /* texto secundário */
--ink-mute:#5a5448;     /* texto de apoio / muted */
--ink-faint:#8b8676;    /* labels fracas, captions */
--coral:#ed6f5c;        /* ACENTO principal: CTA, links, bordas de destaque */
--coral-soft:#f08e7c;   /* hover do coral / coral sobre fundo escuro */
--mustard:#e9b94a;      /* acento pontual (amarelo) */
--olive:#6e7448;        /* "concluído" / sucesso (verde) */
--line:rgba(21,20,15,.14);     /* bordas */
--line-soft:rgba(21,20,15,.08);/* bordas fracas */
--container:1360px;
```

### Cores · TEMA ESCURO (`body.theme-dark`, só pós-compra: upsell / downsell / obrigado)

O escuro **não é uma paleta nova**: é a INVERSÃO das mesmas vars. O navy vira fundo, o bege vira texto. Acentos coral/olive/mustard ficam iguais. Por isso a mesma página/componente funciona nos dois temas só trocando a classe no `<body>`.

```css
body.theme-dark{
  --paper:#15140f;        /* fundo (era o texto navy) */
  --paper-warm:#1c1a14;   /* fundo alternado */
  --paper-dark:#c9c0a6;   /* bege médio legível dentro de painel escuro */
  --bone:#1d1b16;         /* fundo de cards/inputs (1 tom acima do fundo) */
  --ink:#efe7d2;          /* TEXTO principal (era o fundo bege) */
  --ink-soft:#e6ddc6;
  --ink-mute:#b9af96;
  --ink-faint:#8f8a78;
  --line:rgba(239,231,210,.16);   /* bordas claras pra aparecer no escuro */
  --line-soft:rgba(239,231,210,.09);
  --panel:#26221b;        /* painéis de DESTAQUE (cards que eram escuros no claro) */
}
```

> Detalhe importante do escuro: painéis que no tema claro já eram escuros (`.finalcta`, `.pricecard .pright`, `.totalbar`, lado `.ai` do VS, players) **não invertem pra claro**. O base.css os força pro `--panel` (`#26221b`) com texto bege, pra manter a hierarquia. Isso já está resolvido no `base.css`; não precisa fazer nada além de pôr `class="theme-dark"` no `<body>`.

### Escala tipográfica (clamps prontos no base.css)

- `h1.display` → `clamp(28px,3.3vw,46px)`, weight 800, letter-spacing -.03em
- `h2.display` → forçado a `clamp(26px,2.7vw,40px)` (override elegante), line-height 1.07
- `h3.sub` → `clamp(20px,2vw,30px)`, weight 700
- `.lead` → 16.5px, line-height 1.6, `--ink-soft`, max 54ch
- corpo / `.letter p` → 17px, line-height 1.7
- labels / `.eyebrow` → 11px, weight 600, letter-spacing .22em, UPPERCASE, coral
- mono / chips / caption → 10-12.5px, letter-spacing .04–.14em

### Espaçamento e raios

- `section` padding vertical 130px (`.tight` = 90px; mobile 80px).
- `.container` 1360px, padding lateral 64px → 44 → 32 → 24 (responsivo).
- Raios: cards 18px, painéis grandes 22-24px, botões/pílulas 999px, inputs 10-12px.
- Sombra padrão de card: `0 30px 60px -30px rgba(21,20,15,.15)` (longa e suave, nunca dura).

---

## 🧱 COMPONENTES (com snippet real)

Todos saem do `base.css`. Copiar o HTML, trocar o texto. Snippets verbatim das páginas reais.

### 1. Estrutura base da página (esqueleto)

```html
<!doctype html>
<html lang="pt-BR"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>…</title>
<meta name="description" content="…">
<!-- fontes + base.css (bloco acima) -->
</head>
<body>            <!-- pós-compra: <body class="theme-dark"> -->
<div class="wrap">

  <!-- trilhos laterais (some <1280px) -->
  <div class="rail left"><span>a empresa · MMXXVI</span></div>
  <div class="rail right"><span>Funil · Negócio Digital</span></div>

  <!-- (opcional) metastrip + topbar -->
  <header class="topbar"> … </header>

  <main id="top">
    <section id="topo"> … </section>
    …
  </main>

  <footer> … </footer>
</div>
<script> /* reveal on scroll (ver passo a passo) */ </script>
</body></html>
```

### 2. Navbar "Ø Premium"

Dois sabores reais. Página de venda usa marca + título da página:

```html
<header class="topbar">
  <div class="container">
    <span class="brand"><span class="o">Ø</span> Premium</span>
    <span class="topbar-title">o método de instalação e treinamento de agentes Claw</span>
  </div>
</header>
```

Página de documento/aula usa metastrip em cima + marca "Premium." com `<small>`:

```html
<div class="metastrip">
  <div class="container">
    <span class="filed">DOC · <b>FUNIL VSL</b></span>
    <div class="mid"><span>Perpétuo</span><span>8 fases</span><span>Escada de valor</span></div>
    <span class="live"><span class="pulse"></span>MODELO INTERNO</span>
  </div>
</div>
<header class="topbar">
  <div class="container">
    <a class="brand" href="#topo">Premium<span class="o">.</span><small>Instituto</small></a>
    <div class="topbar-title">Como construímos o Funil VSL · passo a passo</div>
  </div>
</header>
```

> O "Ø"/"." da marca é a serifa Playfair italic em coral (`.brand .o`). É a assinatura visual, sempre manter.

### 3. Eyebrow (sobre-título) e regra de seção

```html
<p class="eyebrow">Para quem é</p>

<div class="sec-rule">
  <span class="rom">★</span>
  <span class="mid">Para quem é · Reconheça o seu perfil</span>
  <span>VOL. 01</span>
</div>
```

O eyebrow é label coral em mono-caps com um tracinho antes (`::before`). A `.sec-rule` é a linha fina de topo de seção com estrela serifada + texto centro + volume à direita.

### 4. Barra de oferta / contador (topo de página escura)

Na página de upsell, a navbar vira uma barra de urgência com contador (CSS escopado no `<style>` da página, ver `reference/exemplo-pagina-escura-upsell.html`):

```html
<header class="topbar">
  <div class="container">
    <div class="cd-bar" role="timer" aria-live="off">
      <span class="cd-dot" aria-hidden="true"></span>
      <span class="cd-text">Essa página fecha sozinha em <span class="cd-time" id="cd-time">15:00</span></span>
    </div>
  </div>
</header>
```

### 5. Hero de captura (imagem → título → descrição → formulário empilhados)

Padrão da página de captura: tudo centralizado numa coluna (`.topo-stack`).

```html
<section id="topo">
  <div class="container">
    <div class="topo-stack">
      <div class="reveal topo-copy"><h1 class="display">Título com ponto coral<span class="dot">.</span></h1></div>
      <figure class="media-frame reveal" style="max-width:860px;margin:0 auto;">
        <video class="lazyvid" muted loop playsinline preload="none" poster="/img/poster.webp" data-src="/img/video.mp4"></video>
      </figure>
      <div class="reveal topo-copy">
        <p class="lead muted">Subtítulo com <strong class="hl-money">+20 mil reais</strong> destacado.</p>
      </div>
      <div class="form-card reveal" id="form-wrap">
        <h3 class="sub" style="margin:0 0 14px;">Libere o vídeo agora<span class="dot">.</span></h3>
        <form id="lead-form" novalidate>
          <div class="form-grid" style="grid-template-columns:1fr;">
            <div class="form-field full"><label for="f-nome">Nome</label>
              <input class="diag-input" id="f-nome" name="nome" type="text" required placeholder="Seu nome"></div>
            <div class="form-field full"><label for="f-email">E-mail</label>
              <input class="diag-input" id="f-email" name="email" type="email" required placeholder="seu@email.com"></div>
          </div>
          <button class="btn btn-primary" type="submit" style="width:100%;justify-content:center;margin-top:18px;">Quero meu funcionário digital.</button>
          <p class="form-note">É grátis assistir. Leva 2 minutos.</p>
        </form>
      </div>
    </div>
  </div>
</section>
```

### 6. Player de VSL (vídeo vertical 9:16, autoplay mudo + "ativar som")

```html
<div class="vstage reveal" id="vstage" style="margin-top:36px;">
  <span class="vlive"><span class="pulse"></span> AO VIVO</span>
  <video id="vsl-video" playsinline muted autoplay preload="auto" poster="" src="URL_DO_VIDEO.mp4"></video>
  <button type="button" class="vsound" id="vsl-sound" aria-label="Ativar o som do vídeo">
    <span class="vs-ico">🔊</span>
    <span class="vs-txt">Toque para ativar o som</span>
    <span class="vs-sub">O vídeo já começou · clique para ouvir</span>
  </button>
</div>
<p class="player-cap reveal">Assista com som. Fica até o final.</p>
```

O JS de unmute está no passo a passo (e em `reference/exemplo-pagina-escura-upsell.html`).

### 7. Cards (grade de 2 ou 3)

```html
<div class="grid-3">
  <div class="card reveal">
    <div class="crow"><span class="cnum">01</span><span class="ctag">Atende</span></div>
    <h4>WhatsApp 24h</h4>
    <p>Responde, qualifica e agenda sozinho, sem pausa.</p>
    <span class="arr">→</span>
  </div>
  … <!-- repetir -->
</div>
```

`.card` = fundo bone, borda fina, sombra longa, número em serifa coral, tag em mono-caps, setinha no canto que vira coral no hover.

### 8. Accordion por fase (`<details>`/`<summary>` nativo, abre sem JS)

Usado na página de aula. Toggle de 1 clique, acessível, chevron que gira. (CSS no `<style>` da página de aula, copiar de `reference/exemplo-aula-accordion-index.html`.)

```html
<details class="acc reveal">
  <summary aria-label="Abrir Fase 1">
    <span class="acchev" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg></span>
    <div class="achead">
      <div>
        <div class="stag">Fase 1 · Infraestrutura</div>
        <h3>Onde o agente mora</h3>
      </div>
      <span class="status done"><span class="dotico">✓</span> Pronto</span>
    </div>
    <p class="acteaser">Uma frase do "o que é", visível só com a caixa fechada.</p>
  </summary>
  <div class="acbody">
    <!-- conteúdo da fase: .lesson, .figframe, .principle, etc -->
  </div>
</details>
```

Variante "fundação" (label coral + título com `<em>` serifado): `<details class="acc accbase reveal">`. Status WIP: `<span class="status wip"><span class="dotico"></span> Ainda não</span>`.

### 9. Card de preço / oferta (split bege + painel navy)

```html
<div class="pricecard reveal">
  <div class="pleft">
    <p class="eyebrow">A oferta</p>
    <h3 class="sub">Tudo que você instala hoje<span class="dot">.</span></h3>
    <ul class="incl-list">
      <li><span class="mk">+</span> Passo a passo em vídeo</li>
      <li><span class="mk">+</span> Apostila completa</li>
    </ul>
  </div>
  <div class="pright">
    <div class="bignum">R$ 297<small>pagamento único · acesso imediato</small></div>
    <a class="btn btn-checkout" href="#" data-checkout="pendente" onclick="return false;">Quero instalar agora <span class="arrow">→</span></a>
    <span class="checkout-soon">Checkout em breve</span>
  </div>
</div>
```

Comparativo de planos: `.vs` (3 colunas: ruim · "vs" serifado · bom navy). Tabela: `.cmp`. Oferta one-time de upsell: `.onetime` + `.cashcard` + `.acceptblock` (com `.decline` discreto pra recusar). Garantia: `.guarantee` (caixa coral tracejada). FAQ: `.faq`.

### 10. CTA final (painel navy com glow coral)

```html
<div class="finalcta reveal">
  <p class="eyebrow">Comece hoje</p>
  <h2>Por R$ 297 você instala o seu primeiro funcionário digital.</h2>
  <p class="lead">Acesso imediato. Pagamento único. Garantia de 7 dias.</p>
  <div class="actions">
    <a class="btn btn-checkout" href="#" data-checkout="pendente" onclick="return false;">Quero instalar por R$ 297 <span class="arrow">→</span></a>
  </div>
  <span class="checkout-soon">Checkout em breve</span>
</div>
```

### 11. Rodapé (megaword)

```html
<footer>
  <div class="container">
    <div class="megaword reveal">Premium<span class="dot">.</span></div>
    <div class="footrow">
      <span class="live"><span class="pulse"></span> o método de instalação e treinamento de agentes Claw</span>
      <span>Vol. 01 / Issue Nº 26 · MMXXVI</span>
      <span>Edited in pt-BR · Filed under Negócio Digital · FIN.</span>
    </div>
  </div>
</footer>
```

O `.megaword` é a palavra "Premium." gigante (clamp até 200px) com o ponto coral. Assinatura de fechamento de página.

### Outros componentes prontos no base.css (usar pela classe)
`.kanban` (CRM kanban interativo), `.team-naia` + `.team-grid` (squad de agentes), `.method`/`.mstep` (passos numerados), `.role-grid`/`.rolecard` (IA vs humano com custo), `.desire` (bullets de skill), `.perfis`/`.perfil` (pra quem é), `.letter` (carta longa de VSL2), `.modal-overlay`/`.modal-card` (modal de agendamento), `.promptbox` (bloco de código copiável tema terminal), `.media-frame`/`.figframe` (molduras de vídeo/infográfico).

---

## 🛠️ PASSO A PASSO · montar página nova

1. **Definir o tipo e o tema.** Captura / VSL / carta / página de aula = **tema CLARO** (`<body>`). Upsell / downsell / obrigado (pós-compra) = **tema ESCURO** (`<body class="theme-dark">`). (Regra detalhada na seção abaixo.)
2. **Onde vai morar.** Mesma família de página do método → cair em `/opt/funil-metodo-claw/static/`. Família da página de aula → `/opt/funil/static/`. Página/funil novo e separado → pasta nova `/opt/<nome>/static/` com uma CÓPIA do `reference/base.css` desta skill servida em `/base.css`. NUNCA editar o `base.css` de produção sem necessidade (ele é compartilhado por várias páginas; mudança quebra todas).
3. **Criar o arquivo** a partir do exemplo certo: clara → copiar `reference/exemplo-pagina-clara-cadastro.html`; escura → `reference/exemplo-pagina-escura-upsell.html`; aula com accordion → `reference/exemplo-aula-accordion-index.html`. Trocar `<title>`/`<meta>`.
4. **Garantir `<head>`**: fontes (4 famílias) + `/base.css`, na ordem mostrada. Sem isso o layout quebra.
5. **Montar o corpo** empilhando os componentes acima (navbar → hero → seções → finalcta → footer). Só trocar texto; não recriar CSS. Cor sempre via var (`var(--coral)` etc), nunca hex solto. Para variação pontual, usar `style="…"` inline curto (é o padrão das páginas reais), não criar classe nova.
6. **Pôr `.reveal`** nos blocos que devem animar ao entrar na tela e colar o JS de scroll no fim do `<body>`:

```html
<script>
(function(){
  var io = new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting)e.target.classList.add('in');});},{threshold:.12});
  document.querySelectorAll('.reveal').forEach(function(el){io.observe(el);});
})();
</script>
```

7. **Vídeo/VSL?** colar o JS de autoplay-mudo + unmute (verbatim em `reference/exemplo-pagina-clara-cadastro.html` / `...escura-upsell.html`). Accordion NÃO precisa de JS (é `<details>` nativo).
8. **Mobile.** O base.css já tem hardening anti-overflow horizontal (grids viram 1 coluna, paddings encolhem). Não mexer nisso. Só conferir que blocos novos usam as classes/grids existentes (`.grid-3`, `.split`, etc) que já têm os breakpoints.
9. **Checkout pendente.** Enquanto não há link de pagamento, usar `class="btn btn-checkout" data-checkout="pendente" onclick="return false;"` + `<span class="checkout-soon">Checkout em breve</span>`. Trocar pelo link real depois.
10. **Validar** (o Paulo faz, a Naia confere): abrir no navegador / screenshot desktop + mobile, conferir fontes carregando, coral nos CTAs, `.reveal` aparecendo, e no escuro que os painéis de destaque não ficaram claros. Deploy: as páginas são servidas estáticas na Hetzner (pasta `static/` atrás do serviço do funil); sincronizar o arquivo e recarregar, conforme o serviço já configurado.

---

## ☀️🌙 QUANDO USAR CADA TEMA

| Etapa do funil | Tema | Por quê |
|---|---|---|
| Página de captura / opt-in | **CLARO** | Topo de funil, primeiro contato. Bege = leve, convidativo, editorial. |
| VSL (vídeo de vendas) + carta | **CLARO** | Atração e venda do front-end. Mantém o tom de "conteúdo/aula", não de promoção agressiva. |
| Página de aula / passo a passo | **CLARO** | Documento, leitura longa. |
| Upsell (oferta única pós-compra) | **ESCURO** (`body.theme-dark`) | Marca a virada "você já comprou, agora atenção": muda o cenário, cria foco e urgência sem trocar a identidade. |
| Downsell | **ESCURO** | Mesmo momento pós-compra do upsell. |
| Obrigado / confirmação | **ESCURO** | Fecha o ciclo no mesmo ambiente da sequência de pós-compra. |

Regra curta: **antes da compra = claro; depois da compra = escuro.** É o mesmo design, só inverte fundo/texto. A transição claro→escuro sinaliza "mudou a fase" pro lead sem ele perceber que é a mesma marca.

---

## 🚫 ANTI-PADRÕES (não fazer)

- **Não inventar paleta nova.** Sempre as vars do base.css. Nada de roxo, azul tech, gradiente arco-íris. O acento é coral, ponto.
- **Não trocar as fontes.** Inter Tight + Inter + Playfair italic + JetBrains Mono. Sem Roboto, sem Arial, sem system-ui solto. Playfair SÓ em detalhe (marca, números, ênfase), NUNCA em corpo.
- **Não usar serifa em parágrafo** nem mono em texto corrido. Mono é só label/chip/caption.
- **Não recriar componente do zero** se já existe a classe. Card, accordion, oferta, footer: usar a classe e trocar texto.
- **Não editar o `base.css` de produção** por causa de uma página só. Ele é compartilhado; mudança quebra as outras. Se precisar de algo só dessa página, põe num `<style>` escopado no `<head>` dela (foi assim que fizeram o contador do upsell).
- **Não esquecer o `.reveal` + o JS de scroll**, senão os blocos com `.reveal` ficam invisíveis em quem tem JS (o base.css esconde `.reveal` quando `html.js`). Na página de aula tem um override que deixa visível sem JS; nas de funil, garanta o script.
- **Não pôr `border-radius` arredondado + borda-esquerda colorida** genérica nem emoji fora de marca: é cara de "feito por IA", foge do editorial.
- **Não trocar tema no meio da mesma página.** Claro OU escuro por página inteira (via classe no `<body>`).
- **Não cortar a textura/glows do body** nem os trilhos laterais: fazem parte do feel.
- **Sem travessão** em nenhum texto da página (regra de copy da casa).

---

## 📎 REFERENCE (arquivos reais nesta skill)

- `reference/base.css` é o design system COMPLETO (tema claro + tema escuro `body.theme-dark`), idêntico ao de produção do método. Servir como `/base.css`.
- `reference/exemplo-pagina-clara-cadastro.html` é uma página de captura real (tema claro, hero empilhado + formulário + JS de vídeo).
- `reference/exemplo-pagina-escura-upsell.html` é uma página de upsell real (`body.theme-dark`, barra-contador, player VSL + JS de unmute, oferta one-time).
- `reference/exemplo-aula-accordion-index.html` é a página de aula real (metastrip, accordion `<details>` por fase com todo o CSS escopado no `<head>`, recap, mascotes).

> Pra montar qualquer página nova: copiar o exemplo do tema/tipo certo, manter o `<head>`, empilhar os componentes desta doc trocando só o texto. Não precisa escrever CSS, está tudo no base.css.
