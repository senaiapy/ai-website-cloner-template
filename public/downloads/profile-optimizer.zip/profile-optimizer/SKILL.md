---
name: profile-optimizer
description: >
  Reconstrói um perfil do LinkedIn para máxima conversão. Gera novas opções de headline, seção sobre, seção de experiência, estratégia da seção em destaque e 4 prompts de geração de imagem (banner, foto de perfil, 2 cards em destaque). Use esta skill sempre que o dono pedir "otimiza meu perfil", "ajeita meu LinkedIn", "reescreve minha headline", "revisa meu perfil", "auditoria do LinkedIn", "reconstrói meu perfil", ou quiser ajuda com qualquer parte do perfil do LinkedIn. Acione também quando o dono enviar um PDF ou print do perfil do LinkedIn para revisão.
---

# Otimizador de Perfil

## CRÍTICO: começar sozinha ao carregar

Quando esta skill for acionada, vá direto pro Passo 1. Não resuma. Não explique o que vai produzir. Comece a coletar as informações imediatamente.

## Passo 1. Coletar informações

Veja se o projeto tem um arquivo about-me.md. Se existir, pré-preencha nome, público, temas e ponto de vista a partir dele. Pule essas perguntas e diga pro dono o que você puxou de lá.

Chame AskUserQuestion em duas levas.

### Leva 1

```json
[
  {
    "question": "Qual é o objetivo principal da sua presença no LinkedIn?",
    "header": "Objetivo",
    "multiSelect": false,
    "options": [
      {"label": "Calls agendadas", "description": "Gerar calls de descoberta ou demonstrações"},
      {"label": "Leads inbound", "description": "Atrair prospects que procuram você"},
      {"label": "Inscritos na newsletter", "description": "Crescer sua lista de e-mails a partir do LinkedIn"},
      {"label": "Oportunidades de trabalho", "description": "Fazer recrutadores e gestores procurarem você"}
    ]
  },
  {
    "question": "Qual é sua oferta ou serviço principal?",
    "header": "Oferta",
    "multiSelect": false,
    "options": [
      {"label": "Mentoria", "description": "Mentoria individual ou em grupo"},
      {"label": "Consultoria", "description": "Trabalho de assessoria ou estratégia"},
      {"label": "Serviços de agência", "description": "Serviços feitos para o cliente"},
      {"label": "Freelance", "description": "Trabalho por projeto ou contrato"}
    ]
  },
  {
    "question": "Você tem cores de marca (códigos hex)?",
    "header": "Cores",
    "multiSelect": false,
    "options": [
      {"label": "Não, sugira pra mim", "description": "Escolha cores com base no meu posicionamento"},
      {"label": "Sim, vou colar elas", "description": "Tenho códigos hex específicos para usar"}
    ]
  },
  {
    "question": "Tem alguma prova social que você quer destacar?",
    "header": "Prova",
    "multiSelect": false,
    "options": [
      {"label": "Anos de experiência", "description": "ex.: mais de 10 anos em marketing"},
      {"label": "Resultados de clientes", "description": "ex.: ajudei mais de 200 clientes"},
      {"label": "Aparições na mídia", "description": "ex.: destaque em revistas do setor"},
      {"label": "Vou escrever a minha", "description": "Deixe eu colar pontos de prova específicos"}
    ]
  }
]
```

### Leva 2

```json
[
  {
    "question": "Quais links externos você quer na sua Seção em Destaque? (máximo 2)",
    "header": "Links",
    "multiSelect": false,
    "options": [
      {"label": "Página de agendamento + newsletter", "description": "Link principal para agendar calls, secundário para se inscrever"},
      {"label": "Portfólio + página de agendamento", "description": "Mostra o trabalho primeiro, depois converte"},
      {"label": "Vou colar as URLs", "description": "Tenho links específicos para usar"}
    ]
  },
  {
    "question": "Como eu pego seu perfil atual?",
    "header": "Perfil atual",
    "multiSelect": false,
    "options": [
      {"label": "Vou colar", "description": "Vou copiar e colar minha headline, sobre e experiência"},
      {"label": "Começar do zero", "description": "Ignore meu perfil atual, monte do zero usando meu about-me.md"},
      {"label": "Vou enviar um print", "description": "Vou compartilhar um print ou PDF do meu perfil"}
    ]
  }
]
```

Espere todas as respostas antes de seguir.

## Passo 2. A Headline

Escreva 3 opções de headline. Saída em bloco de código.

Restrições:
- No máximo 50 caracteres cada
- Só primeira letra maiúscula (não Title Case)
- Comece pelo valor central
- Inclua o público-alvo quando a contagem de caracteres permitir
- Sem cargos (nada de "Fundador" / "CEO" / "Designer")
- Sem palavras de enrolação

Formato: [Valor central] + [para público-alvo]

```
Opção 1 (Direta): [resultado + público]
Opção 2 (Focada na dor): [problema + público]
Opção 3 (Diferencial): [ângulo único + público]
```

Depois chame AskUserQuestion para o dono escolher:

```json
[
  {
    "question": "Com qual headline você quer ir?",
    "header": "Headline",
    "multiSelect": false,
    "options": [
      {"label": "Opção 1", "description": "[O texto real da headline acima]"},
      {"label": "Opção 2", "description": "[O texto real da headline acima]"},
      {"label": "Opção 3", "description": "[O texto real da headline acima]"}
    ]
  }
]
```

## Passo 3. A Seção Sobre

Saída em bloco de código. Regras de formatação:
- Escreva em frases completas. Não force quebra de linha no meio da frase.
- Uma quebra de linha entre frases ou trechos curtos para facilitar a leitura.
- Quebra de linha dupla entre seções (gancho, história, autoridade, CTA).
- O LinkedIn cuida da quebra de texto no celular e no desktop. Não quebre manualmente a cada 50 ou 60 caracteres.
- Frases curtas e diretas são boas. Cortar frase pela metade não é.

Estrutura: Gancho > Luta/Empatia > Método/Filosofia > Autoridade > CTA

Tom: Direto, humano, sem rodeio. Nada de corporativo.

Exemplo de formatação correta:
```
Saí do meu emprego de carteira assinada em setembro de 2024.
Dois anos depois: mais de 200 mil seguidores, vários negócios de seis dígitos, milhares de profissionais de marketing treinados.

Foi isso que eu aprendi.
A maioria das pessoas não precisa de mais conteúdo. Precisa de um sistema que transforma conteúdo em clientes. É isso que eu construo.

✦ Agência de conteúdo: conteúdo feito para você no LinkedIn, para fundadores e executivos.
✦ Ferramenta de design com IA: cria infográficos prontos para publicar em minutos.
✦ Newsletter de marketing com IA: mais de 200 mil leitores recebendo frameworks toda semana.
✦ Comunidade de criadores: lives com cases, sistemas comprovados e uma turma que ajuda você a crescer em semanas, não em meses.

Parcerias de marca e palestras: fale comigo por aqui.

Dá uma olhada na minha seção em Destaque logo abaixo. Ou me chama no direct. Eu aponto o caminho certo.
```

## Passo 4. A Seção de Experiência

Reescreva os 2 cargos do topo. Saída em bloco de código. Mesma abordagem de formatação da seção Sobre: frases completas, sem quebra forçada no meio da frase, o LinkedIn cuida da quebra.

Estrutura por cargo: Contexto > Desafio > Ação > Resultado

Formato de storytelling, não tópicos. De 8 a 15 frases por cargo, no máximo.

Exemplo de formatação correta:
```
Entrei num time que tinha perdido 3 gestores em 2 anos.
A moral estava no chão. A receita escorregando.

Não comecei com slides de estratégia. Comecei ouvindo.

Em 6 meses reconstruímos a cultura.
Em 12 meses a receita subiu 40%.

Isso me ensinou tudo sobre liderar no meio do caos.
```

Exemplo de formatação errada:
- Gerenciei um time de 15 representantes de vendas
- Responsável pelas metas de receita do Q3
- Implementei um novo CRM

## Passo 5. Estratégia da Seção em Destaque

No máximo 2 itens. Os dois precisam ser links externos.

Item 1: Objetivo principal de conversão
- Propósito: caminho direto para a oferta principal (página de agendamento, formulário de inscrição, página de vendas)
- Título: 3 a 5 palavras, focado em benefício

Item 2: Construtor de valor secundário
- Propósito: gerar confiança ou capturar leads (inscrição na newsletter, recurso gratuito, portfólio, case)
- Título: 3 a 5 palavras, focado em benefício

Sem subtítulos. Sem posts internos do LinkedIn. Sem itens do tipo "me chama no direct".

## Passo 6. Briefing de Design Visual

Gere 4 prompts de geração de imagem separados, cada um no seu próprio bloco de código. Cada prompt precisa ser totalmente independente e funcionar quando colado no Gemini como um pedido sozinho.

Declare as cores de marca no topo:
- Hex primário: [informado pelo dono ou sugerido]
- Hex secundário: [informado pelo dono ou sugerido]
- Uma linha sobre por que essas cores combinam com o posicionamento

### Asset 1: Banner do LinkedIn (1584 x 396 pixels)

O prompt precisa:
- Dizer "Usando a foto minha em anexo..."
- Criar o banner nas dimensões exatas
- Colocar a headline escolhida no centro-direita
- Colocar uma tagline de 5 a 8 palavras abaixo da headline
- Incluir um elemento de botão de CTA (3 a 4 palavras)
- Incluir texto de prova social
- Usar as cores de marca
- Especificar o estilo do fundo

### Asset 2: Foto de Perfil (400 x 400 pixels)

O prompt precisa:
- Dizer "Usando a foto de rosto em anexo como base..."
- Aplicar fundo na cor de marca (sólido ou gradiente)
- Centralizar o rosto a 60 a 70% do quadro
- Funcionar quando recortado em círculo
- Adicionar borda na cor de marca se fizer sentido

### Asset 3: Card da Seção em Destaque 1 (552 x 368 pixels)

- Texto do título do Item 1 em Destaque como ponto focal
- Cores de marca combinando com o banner
- Pista visual simples de que é clicável (ícone de seta)
- Limpo, minimalista, sem subtítulo nem texto de corpo
- Não precisa de foto

### Asset 4: Card da Seção em Destaque 2 (552 x 368 pixels)

- Texto do título do Item 2 em Destaque como ponto focal
- Visualmente diferente do Card 1 (troque o uso da cor primária/secundária)
- Não precisa de foto

Depois dos 4 prompts, diga:

> Cole cada prompt num novo chat do Gemini, um de cada vez. No banner e na foto de perfil, anexe a sua foto de rosto junto com o prompt. Os cards em destaque não precisam de foto.

## Regras

- Sempre leia o about-me.md se ele existir e pré-preencha as respostas a partir dele.
- Toda a copy do perfil (headline, sobre, experiência) precisa ir em bloco de código.
- Escreva frases completas. Não force quebra de linha no meio da frase. O LinkedIn cuida da quebra.
- Sem cargos nas headlines.
- Sem parágrafos em bloco em lugar nenhum.
- Cada prompt de imagem precisa ser totalmente independente.
- Nunca use travessões.
- Português do Brasil em tudo.
- NÃO ofereça escrever um post de lançamento ou estratégia de engajamento depois do briefing de design. Termine no briefing de design.
