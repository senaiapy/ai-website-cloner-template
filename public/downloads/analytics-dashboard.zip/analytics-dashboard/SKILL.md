---
name: analytics-dashboard
description: >
  Transforma uma exportação do LinkedIn Analytics num dashboard React interativo com tema escuro, mais uma análise estratégica escrita com 5 recomendações de conteúdo baseadas em dados. Lê todas as abas da exportação e monta gráficos de tendência de engajamento, crescimento de seguidores, dispersão de desempenho dos posts, mapa de calor por dia da semana e segmentação de audiência. Use esta skill sempre que o dono pedir "analisa meu linkedin", "analytics do linkedin", "monta meu dashboard", "revisa meu desempenho", ou enviar um arquivo de exportação do LinkedIn Analytics. Precisa da exportação do LinkedIn Analytics do dono (xlsx) como entrada.
---

# Dashboard de Analytics

## CRÍTICO: começar sozinha ao carregar

Quando esta skill for acionada, vá direto pro Passo 1.

## Passo 1. Pegar o arquivo de exportação

Peça:

> Envie o arquivo de exportação do seu LinkedIn Analytics (xlsx).
>
> Não sabe como pegar? Vá no LinkedIn Analytics, defina o intervalo de datas (30, 60 ou 90 dias funciona bem) e clique em Exportar no canto superior direito.

Espere o envio do arquivo.

## Passo 2. Ler os dados

Leia todas as abas do arquivo. Espere estas abas:

- **DISCOVERY**: impressões e alcance gerais
- **ENGAGEMENT**: impressões e engajamentos diários ao longo do tempo
- **TOP POSTS**: top 50 posts, ranqueados por engajamentos e por impressões (duas tabelas para juntar)
- **FOLLOWERS**: novos seguidores por dia mais a contagem total
- **DEMOGRAPHICS**: cargos, localizações, setores, senioridade, tamanho de empresa, principais empresas

Limpe cabeçalhos bagunçados. Junte as duas tabelas de TOP POSTS (por engajamentos e por impressões) num único conjunto unificado por post. Remova duplicatas.

## Passo 3. Montar o dashboard interativo

Crie um único artifact React. Tema escuro (fundo `#0f1117`), cores de destaque para os gráficos. Use Recharts para todas as visualizações.

Inclua estes painéis nesta ordem:

### Métricas de destaque (cards da linha superior)
- Total de impressões
- Alcance total
- Total de novos seguidores
- Média diária de impressões
- Média diária de engajamentos
- Taxa média de engajamento (engajamentos / impressões)
- Total de posts rastreados

### Tendência de engajamento (gráfico de linha)
- Impressões diárias (eixo y à esquerda) e engajamentos (eixo y à direita) em todo o intervalo de datas
- Destaque os 3 dias de maior pico com marcadores

### Crescimento de seguidores (gráfico de área)
- Novos seguidores por dia
- Linha de tendência de média móvel de 7 dias sobreposta
- Ganho acumulado de seguidores

### Dispersão de desempenho dos posts
- Eixo X: impressões. Eixo Y: engajamentos
- Codifique os posts por cor em quatro quadrantes:
  - **Estrelas**: alto alcance + alto engajamento
  - **Viral mas raso**: alto alcance + baixo engajamento
  - **Ouro de nicho**: baixo alcance + alto engajamento
  - **Abaixo do esperado**: baixo alcance + baixo engajamento
- Pontos com hover mostrando a URL e a data do post

### Mapa de calor por dia da semana
- Média de impressões e engajamentos por dia da semana
- Destaque os dias mais fortes

### Segmentação de audiência (gráficos de barra)
- Cargos
- Setores
- Senioridade
- Tamanho de empresa
- Principais localizações

### Regras de formatação
- Formate números: `67 mil` e não `67000`, `1,2 mi` e não `1200000`
- Contagem total de seguidores em destaque no topo
- Layout responsivo (funciona em notebook e em tela grande)
- Fundo escuro, cores de gráfico de alto contraste

## Passo 4. Análise estratégica escrita

Abaixo do dashboard, escreva uma análise concisa com estas seções:

### Resumo de Desempenho
- Trajetória: crescendo, estabilizado ou caindo (use as linhas de tendência)
- Taxa de engajamento atual e como ela se compara aos benchmarks do LinkedIn para contas desse tamanho

### Padrões dos Melhores Posts
- Analise os top 10 por impressões e os top 10 por engajamentos
- Padrões: dia de postagem, época do mês, temas de conteúdo
- Muitas impressões + baixo engajamento: o que isso sinaliza?
- Poucas impressões + alto engajamento: o que isso sinaliza?

### Encaixe entre Audiência e Conteúdo
- Quem é o público central, com base na demografia
- Quais temas e formatos de conteúdo ressoariam
- Segmentos para reforçar ou para se afastar

### Velocidade de Crescimento
- Crescimento médio diário de seguidores
- Projeções de 30, 60 e 90 dias no ritmo atual
- Tendências de aceleração ou desaceleração

### Estratégia de Dia e Horário
- Melhores dias para impressões
- Melhores dias para engajamento
- Agenda de postagem ideal com base nos dados

### 5 Recomendações Específicas de Conteúdo
Cada uma inclui:
- Ângulo ou tema do conteúdo
- Por que os dados sustentam isso
- Qual segmento de audiência ela mira
- Impacto esperado com base nos padrões dos dados

## Passo 5. Oferecer o próximo passo

Depois da análise:

> Quer que eu escreva uma dessas 5 recomendações como um post completo? Chame a skill de escrever post ou de formatar post com o número da recomendação.

## Regras

- Use números, não adjetivos. "A taxa de engajamento é 2,3%" vence "o engajamento está saudável".
- Mantenha a análise direta. Sem enrolação, sem encheção.
- Nunca invente métricas que não estão na exportação.
- Sinalize problemas de qualidade nos dados (colunas faltando, intervalos de data estranhos) em vez de contornar em silêncio.
- Nunca use travessões.
- Português do Brasil, a menos que o voice.md diga outra coisa.
- Recomende rodar isso todo mês. Os padrões só aparecem com o tempo.
