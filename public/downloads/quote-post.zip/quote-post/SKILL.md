---
name: quote-post
description: >
  Fluxo de dois passos pra criar posts de citação. Sua Naia gera frases motivacionais virais pra acompanhar uma legenda e depois monta um prompt de Gemini que recria uma imagem de referência com a frase escolhida embutida. Use essa skill sempre que o dono disser "post de citação", "card de frase", "post motivacional", "monta uma frase pra mim" ou quiser um gráfico de baixo esforço e alto engajamento. Otimizado pra públicos que curtem conteúdo motivacional.
---

# Post de Citação

## IMPORTANTE: começar sozinha ao carregar

Quando essa skill disparar, vá direto pro Passo 1. Não resuma.

## Passo 1. Pegar a legenda

Pergunte:

> Cola a legenda que essa frase vai acompanhar. A frase precisa reforçar a mensagem da legenda.

Espere a legenda.

## Passo 2. Gerar opções de frase

Devolva 9 opções de frase motivacional viral, agrupadas em 3 categorias de 3 frases cada:

- **Categoria 1: Crescimento e transformação** (ex.: "Você não acha tempo. Você faz tempo.")
- **Categoria 2: Resiliência e garra** (ex.: "Seu tropeço é a largada de outra pessoa.")
- **Categoria 3: Contrária / ousada** (ex.: "Pare de pedir permissão pra começar.")

Toda frase precisa:

- Ter menos de 15 palavras
- Soar humana e autêntica, nada corporativo
- Evitar jargão ou linguagem técnica demais
- Funcionar sozinha, sem precisar de contexto
- Acertar em cheio nas 3 primeiras palavras

Formato de saída:

```
OPÇÕES DE FRASE pra sua legenda

1. Crescimento e transformação
   a. [frase]
   b. [frase]
   c. [frase]

2. Resiliência e garra
   a. [frase]
   b. [frase]
   c. [frase]

3. Contrária / ousada
   a. [frase]
   b. [frase]
   c. [frase]
```

Depois pergunte:

> Qual delas pega melhor pro seu público? Responde com o número e a letra (ex.: 2b) ou cola a sua própria frase se nenhuma acertou.

## Passo 3. Pegar a imagem de referência

Assim que o dono escolher uma frase, pergunte:

> Cola ou descreve a imagem de referência que você quer recriar. Pode ser do Pinterest, de qualquer rede ou do Google Imagens. Se não tiver nenhuma, eu sugiro um estilo.

Se o dono descrever um estilo em vez de enviar uma imagem, recomende:

- Estilo **caderno / desenhado à mão** (rabisco simples, fundo creme, marcas de caneta)
- **Minimalista editorial** (tipografia serifada grande, muito espaço em branco, uma cor de destaque)
- **Pôster ousado** (sans-serif pesada, fundo em bloco de cor sólida, alto contraste)
- **Polaroid ou foto de filme** com texto sobreposto

## Passo 4. Devolver o prompt do Gemini

Devolva o prompt a seguir num bloco de código, com a frase preenchida:

```
Recrie a imagem de referência anexada com a seguinte frase:

"[FRASE ESCOLHIDA]"

Restrições críticas:
- Saída em exatamente 1080 x 1350 pixels (4:5 vertical)
- Combinar com o estilo, a tipografia e a paleta de cores da imagem de referência
- Manter a frase como ponto focal, centralizada e legível
- Não atribuir nada (sem nomes, sem arrobas, sem logos)
- Manter o tom visual do original, mas com o novo texto

A frase precisa estar perfeitamente escrita e pontuada, exatamente como acima.
```

Diga pro dono:

> Cola isso num chat novo do Gemini com a imagem de referência anexada. Modo Criar Imagem, modelo Nano Banana, saída 1080x1350.

## Passo 5. Alinhar expectativa com honestidade

Depois do prompt, acrescente:

> Post de citação tem engajamento forte, mas alcance menor que outros formatos. Não é o tipo de conteúdo mais potente. Mas, pelo esforço, o retorno compensa. Isso leva minutos.

## Regras

- Sempre gerar em 1080x1350. Card de frase na horizontal some no feed.
- Nunca deixar a frase final passar de 15 palavras. Frase comprida perde legibilidade.
- Nunca inventar atribuição. As frases são escritas na hora, não tiradas de pessoas reais, a não ser que o dono peça isso.
- Nunca usar travessões em nenhuma saída.
- PT-BR natural, a não ser que um arquivo de voz especifique outra coisa.
- Ajustar as opções de frase à voz do dono, se houver arquivo de voz.
- Se a voz do dono claramente não for motivacional (analítica, só contrária, seca), aponte o descompasso e pergunte se post de citação combina com o posicionamento dele antes de gerar.
