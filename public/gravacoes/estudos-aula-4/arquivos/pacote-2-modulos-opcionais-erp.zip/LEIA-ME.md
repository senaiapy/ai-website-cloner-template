# Pacote 2 · Módulos opcionais do ERP modular

Use este pacote DEPOIS que a fase 1 (pacote 1) estiver no ar, com as provas P1 a P13 verdes.

## Conteúdo

- `PROMPT-MODULOS-OPCIONAIS.md` · o prompt que você cola no Claude Code, na raiz do repositório do ERP.
- `.claude/skills/incluir-modulo-erp/SKILL.md` · a skill do ciclo de inclusão (estudar, escolher, backup, build, review, deploy).
- `specs/modulos-opcionais/` · uma spec por módulo (14 arquivos).

## Dois modos

- **Escolher módulos** · o Claude mostra a lista do que ainda não existe no sistema e você marca quais quer.
- **Instalar todos** · o Claude constrói os 14 opcionais em ondas, na ordem das dependências.

## Módulos

Vendas, Projetos e tarefas, Apontamento de horas, Recrutamento, Férias e ausências, Contabilidade, Fabricação, Manutenção, Tickets e helpdesk, Ponto de venda, Assinaturas e recorrência, Despesas e reembolso, Documentos e assinatura, Portal do cliente.

## Como usar

1. Descompacte este ZIP na raiz do repositório do ERP. A skill fica em `.claude/skills/` e as specs em `specs/modulos-opcionais/`.
2. Abra o Claude Code na raiz do repositório e cole o prompt.
3. Responda uma pergunta: escolher módulos ou instalar todos.
