---
name: gemini-carousel
description: >
  Gera um carrossel de slides com identidade visual própria usando Gemini. Recebe o conteúdo de origem, monta um briefing de design, espera a aprovação do dono e então entrega um prompt de geração de imagem por slide. Formato vertical 1080x1350. Use esta skill sempre que o dono disser "carrossel", "monta um carrossel", "transforma isso em carrossel", "carrossel no Gemini" ou pedir conteúdo de vários slides para redes sociais. Sempre inclui um ponto de aprovação entre o briefing e a geração das imagens.
---

# Carrossel no Gemini

## IMPORTANTE: começar sozinha ao carregar

Quando esta skill for acionada, vá direto para o Passo 1. Não fique resumindo.

## Passo 1. Reunir as informações

Pergunte:

> Cola aqui o conteúdo que você quer no carrossel. Pode ser um post, um trecho de newsletter, anotações de pesquisa ou um framework, qualquer um funciona.

Espere o conteúdo e então chame o AskUserQuestion:

```json
[
  {
    "question": "Estilo de marca?",
    "header": "Estilo",
    "multiSelect": false,
    "options": [
      {"label": "Puxar do brand-kit.md", "description": "Usar as cores e a tipografia do arquivo de marca do projeto"},
      {"label": "Eu digito as cores", "description": "Vou colar os códigos hex e as preferências de fonte"},
      {"label": "Sugere você", "description": "Escolha uma paleta e tipografia com base no conteúdo"}
    ]
  },
  {
    "question": "Quantos slides?",
    "header": "Slides",
    "multiSelect": false,
    "options": [
      {"label": "6 slides", "description": "Direto, leitura rápida"},
      {"label": "8 slides", "description": "Tamanho padrão de carrossel"},
      {"label": "10 slides", "description": "Carrossel de aprofundamento"}
    ]
  }
]
```

## Passo 2. Montar o briefing de design

Analise o conteúdo e produza um briefing slide a slide com:

- **Slide 1 (Capa)**: gancho, texto grande e em negrito, direção visual
- **Slides 2 até N-1 (Corpo)**: uma ideia por slide, no máximo 15 palavras por slide, sugestão visual
- **Slide N (CTA)**: pedido de compartilhamento, nome, link ou oferta

Para cada slide inclua:

- Número do slide
- Título (no máximo 8 palavras)
- Texto do corpo (no máximo 15 palavras)
- Sugestão visual (ícone, bloco de cor, ilustração, diagrama)

Diga ao dono:

> Aqui está o briefing de design. Me fala o que mudar, ou escreve "gerar" quando estiver satisfeito.

Espere a aprovação. Não avance até o dono aprovar explicitamente.

## Passo 3. Entregar os prompts slide a slide

Depois de aprovado, entregue um prompt de geração de imagem do Gemini por slide, cada um no seu próprio bloco de código, numerados com clareza.

Todo prompt segue esta estrutura:

```
Atue como um designer gráfico especialista. Crie um slide de carrossel para redes sociais com 1080x1350 pixels (proporção 4:5).

Estilo de marca:
- Cor primária: [HEX]
- Cor secundária: [HEX]
- Cor de destaque: [HEX]
- Tipografia: [fonte de título industrial e em negrito, fonte de corpo geométrica e limpa]
- Estética: moderna, autoritária, alto contraste

Slide [N de M]: [objetivo do slide]

Conteúdo:
- Título: "[texto do título]"
- Corpo: "[texto do corpo]"
- Elemento visual: [sugestão visual específica]

Instruções de layout:
- [Posição e tamanho do título]
- [Posição e tamanho do corpo]
- [Posição do elemento visual]
- [Tratamento do fundo]

Restrições:
- Proporção vertical 4:5 em exatamente 1080x1350 pixels
- Sem marcas d'água, sem logos a menos que especificado acima
- Manter a consistência visual com os outros slides do conjunto
```

Diga ao dono:

> Cola cada prompt em um novo chat do Gemini com a opção de criar imagem ativada e o Nano Banana selecionado. Gere os slides um por vez para ter o máximo de controle sobre a consistência.

## Passo 4. Oferecer a alternativa em um só disparo

Depois dos prompts slide a slide, ofereça:

> Quer um único prompt combinado que gera o carrossel inteiro de uma vez? É mais rápido, mas com menos consistência visual. Escreve "combinar" que eu reescrevo.

## Regras

- Sempre trave na aprovação do dono ao briefing antes de entregar os prompts de imagem.
- 1080x1350 pixels por slide. Nenhuma outra proporção.
- No máximo 15 palavras de texto de corpo por slide. A legibilidade se perde no feed.
- Mantenha o estilo de marca idêntico em todos os prompts de slide para o conjunto parecer um único carrossel.
- O slide de capa (1) e o de CTA (último) precisam ser visualmente distintos dos slides de corpo.
- Nunca use travessões.
- Se existir um brand-kit.md no projeto, leia e use exatamente os códigos hex e as escolhas de tipografia dele.
