# Módulo opcional: Apontamento de horas

- Slug: `horas`
- Menu principal: Operação
- Abas na página: Horas, Por projeto, Por pessoa, Faturar horas
- Depende de: projetos-tarefas, pessoas
- Sidebar: não ganha item novo; entra como aba dentro de Operação. Se o menu Operação ainda não existir no tenant, o módulo cria o item principal.

## Escopo

Apontamento de horas por tarefa e projeto, por pessoa e dia, com aprovação; relatório por projeto e por pessoa; horas faturáveis viram linhas em Vendas ou em Contas a receber.

## Agregados e entidades

- Apontamento (raiz): pessoa, projeto, tarefa, data, horas, descricao, faturavel, estado (rascunho, enviado, aprovado, faturado)

Toda tabela com `tenant_id`, `workspace_id`, `creator_id`, `created_at`, `updated_at`, `deleted_at`, RLS e chave composta. Prefixo de tabela `horas_`.

## Casos de uso

- ApontarHoras
- EnviarSemana
- AprovarApontamentos
- FaturarHoras

Comando devolve void e passa por caso de uso; consulta devolve DTO. Entidade e objeto de valor com `create` e `tryCreate`. Result em vez de exceção. Trabalho lento (envio, geração de documento, job recorrente) vai pra fila com outbox.

## Rotas

`/api/v1/horas/...` descritas em OpenAPI antes do código: uma rota por caso de uso, listagens paginadas com filtro e ordenação, e a interface publicada que outros módulos consomem.

## Interfaces com outros módulos

- Projetos e tarefas: tarefa de destino
- Pessoas: pessoa e custo hora
- Contas a receber ou Vendas: faturamento

Só por interface publicada, nunca por import interno.

## Permissões

`horas.ver`, `horas.criar`, `horas.editar`, `horas.excluir`, `horas.aprovar` quando houver aprovação, `horas.configurar`. Geradas na instalação e ligadas aos papéis existentes conforme a entrevista.

## Telas

Padrão visual do sistema: kicker, título, botão primário rosa, abas na página, cards e tabelas com estados vazio, carregando e erro, mobile sem scroll horizontal, i18n pt, en e es.

## Seeds e dados demo

Registros plausíveis com a marca demo do tenant, suficientes pra demonstrar cada aba.

## Provas exigidas

- Teste de cada caso de uso com repositório em memória.
- Arquivo `.http` com todas as rotas e resposta esperada.
- Screenshot Playwright de cada aba.
- Tentativa de ler registro deste módulo de outro tenant devolvendo 404.
- Instalar e desinstalar pelo painel admin sem erro, com bloqueio quando há dependente.
