# Orca · ambiente de desenvolvimento com agentes

O Orca é um aplicativo de desktop gratuito e de código aberto (licença MIT, feito pela Stably) para trabalhar com agentes de código. Ele roda Claude Code, Codex, Gemini, Cursor CLI e outros agentes de terminal em paralelo, cada um no seu git worktree isolado, com terminal embutido, revisão de diff dentro do app, navegador embutido e desenvolvimento remoto por SSH. Funciona em macOS, Windows e Linux, e tem app de acompanhamento para iOS e Android.

## Instalar e configurar com um prompt

1. Abra o Claude Code ou o Codex em qualquer pasta.
2. Cole o conteúdo de `PROMPT-CONFIGURAR-ORCA.md`.

O agente detecta o sistema, baixa e instala o Orca pelos instaladores oficiais, coloca o comando `orca` no terminal, abre o app, instala as skills do Orca nos agentes, cadastra seus projetos e testa um worktree.

## Se preferir baixar na mão

- Página oficial: https://www.onorca.dev/download
- macOS pelo Homebrew: `brew install --cask stablyai/orca/orca`
- Todas as versões: https://github.com/stablyai/orca/releases
