# Módulo opcional: Fabricação

- Slug: `fabricacao`
- Menu principal: Operação
- Abas na página: Lista de materiais, Ordens de produção, Centros de trabalho, Consumo
- Depende de: estoque
- Sidebar: não ganha item novo; entra como aba dentro de Operação. Se o menu Operação ainda não existir no tenant, o módulo cria o item principal.

## Escopo

Lista de materiais por produto (componentes e quantidades), ordem de produção que reserva e consome componentes e dá entrada no produto acabado, centros de trabalho com capacidade e apontamento de operação.

## Agregados e entidades

- ListaMateriais (raiz): produto, versao, componentes[] (produto, quantidade), operacoes[]
- OrdemProducao (raiz): produto, quantidade, lista, estado (rascunho, confirmada, em_producao, concluida, cancelada), consumos[]
- CentroTrabalho: nome, capacidade_hora, custo_hora

Toda tabela com `tenant_id`, `workspace_id`, `creator_id`, `created_at`, `updated_at`, `deleted_at`, RLS e chave composta. Prefixo de tabela `fabricacao_`.

## Casos de uso

- CriarListaMateriais
- CriarOrdemProducao
- ConfirmarOrdem (reserva componentes)
- ApontarOperacao
- ConcluirOrdem (consome componentes e entra acabado via Estoque)

Comando devolve void e passa por caso de uso; consulta devolve DTO. Entidade e objeto de valor com `create` e `tryCreate`. Result em vez de exceção. Trabalho lento (envio, geração de documento, job recorrente) vai pra fila com outbox.

## Rotas

`/api/v1/fabricacao/...` descritas em OpenAPI antes do código: uma rota por caso de uso, listagens paginadas com filtro e ordenação, e a interface publicada que outros módulos consomem.

## Interfaces com outros módulos

- Estoque: reserva, consumo e entrada por movimentacao
- Compras: componente abaixo do minimo gera requisicao

Só por interface publicada, nunca por import interno.

## Permissões

`fabricacao.ver`, `fabricacao.criar`, `fabricacao.editar`, `fabricacao.excluir`, `fabricacao.aprovar` quando houver aprovação, `fabricacao.configurar`. Geradas na instalação e ligadas aos papéis existentes conforme a entrevista.

## Telas

Padrão visual do sistema: kicker, título, botão primário rosa, abas na página, cards e tabelas com estados vazio, carregando e erro, mobile sem scroll horizontal, i18n pt, en e es.

## Seeds e dados demo

Registros plausíveis com a marca demo do tenant, suficientes pra demonstrar cada aba.

## Provas exigidas

- Teste de cada caso de uso com repositório em memória.
- Arquivo `.http` com todas as rotas e resposta esperada.
- Screenshot Playwright de cada aba.
- Tentativa de ler registro deste módulo de outro tenant devolvendo 404.
- Instalar e desinstalar pelo painel admin sem erro, com bloqueio quando há dependente.
