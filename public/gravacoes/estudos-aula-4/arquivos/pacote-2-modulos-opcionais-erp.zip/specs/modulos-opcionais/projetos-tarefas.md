# Módulo opcional: Projetos e tarefas

- Slug: `projetos-tarefas`
- Menu principal: Operação
- Abas na página: Projetos, Tarefas, Marcos, Estágios
- Depende de: cadastros
- Sidebar: não ganha item novo; entra como aba dentro de Operação. Se o menu Operação ainda não existir no tenant, o módulo cria o item principal.

## Escopo

Projeto com cliente, equipe, prazo e orçamento; tarefas em kanban por estágio configurável, com responsável, prioridade, prazo e checklist; marcos com data; visibilidade por equipe.

## Agregados e entidades

- Projeto (raiz): nome, cliente, responsavel, inicio, fim, orcamento, visibilidade, estagios[]
- Tarefa: projeto, titulo, descricao, estagio, responsavel, prioridade, prazo, checklist[], ordem
- Marco: projeto, nome, data, concluido

Toda tabela com `tenant_id`, `workspace_id`, `creator_id`, `created_at`, `updated_at`, `deleted_at`, RLS e chave composta. Prefixo de tabela `projetos_tarefas_`.

## Casos de uso

- CriarProjeto
- MoverTarefa
- ConcluirTarefa
- CriarMarco
- ArquivarProjeto

Comando devolve void e passa por caso de uso; consulta devolve DTO. Entidade e objeto de valor com `create` e `tryCreate`. Result em vez de exceção. Trabalho lento (envio, geração de documento, job recorrente) vai pra fila com outbox.

## Rotas

`/api/v1/projetos-tarefas/...` descritas em OpenAPI antes do código: uma rota por caso de uso, listagens paginadas com filtro e ordenação, e a interface publicada que outros módulos consomem.

## Interfaces com outros módulos

- Cadastros: cliente do projeto
- Agenda: prazo de tarefa vira compromisso opcional
- Chatter do nucleo em projeto e tarefa

Só por interface publicada, nunca por import interno.

## Permissões

`projetos-tarefas.ver`, `projetos-tarefas.criar`, `projetos-tarefas.editar`, `projetos-tarefas.excluir`, `projetos-tarefas.aprovar` quando houver aprovação, `projetos-tarefas.configurar`. Geradas na instalação e ligadas aos papéis existentes conforme a entrevista.

## Telas

Padrão visual do sistema: kicker, título, botão primário rosa, abas na página, cards e tabelas com estados vazio, carregando e erro, mobile sem scroll horizontal, i18n pt, en e es.

## Seeds e dados demo

Registros plausíveis com a marca demo do tenant, suficientes pra demonstrar cada aba.

## Provas exigidas

- Teste de cada caso de uso com repositório em memória.
- Arquivo `.http` com todas as rotas e resposta esperada.
- Screenshot Playwright de cada aba.
- Tentativa de ler registro deste módulo de outro tenant devolvendo 404.
- Instalar e desinstalar pelo painel admin sem erro, com bloqueio quando há dependente.
