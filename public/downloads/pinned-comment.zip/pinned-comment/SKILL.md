---
name: pinned-comment
description: Escreve comentários fixados E prompts de geração de imagem num estilo assinado. Use quando o dono pedir um comentário fixado, comentário fixo ou primeiro comentário pra um post. SEMPRE produza o prompt da imagem PRIMEIRO, depois legende com o comentário de 4 linhas. Entregue os dois juntos, a não ser que peçam o contrário.
---

# Skill de Comentário Fixado + Prompt de Imagem

## Por que essa skill existe

O post entrega o valor. O comentário fixado constrói personalidade, confiança e vontade de rever. É onde o criador tira a máscara polida e fala como gente de verdade.

Engraçado é subjetivo e fácil de errar. Essa skill existe pra tornar comentários fixados hilários REPETÍVEIS, pra que qualquer pessoa do time consiga produzir no mesmo padrão.

## A sacada central (leia isto primeiro)

A imagem carrega a piada. O comentário legenda a imagem.

Se o comentário faz sentido sem a imagem, o comentário está trabalhando demais. Se a imagem precisa do comentário pra ser engraçada, a imagem está fraca demais.

É por isso que a geração de imagem vem PRIMEIRO. Sempre.

---

## O PROCESSO (siga na ordem)

### Passo 1. Achar a confissão

Todo post bom esconde uma confissão silenciosa. Exemplos:
- "A IA faz a maior parte do meu trabalho de verdade agora"
- "Sou dependente da minha IA de um jeito constrangedor"
- "Dei de graça um produto que levei 9 meses pra construir"
- "Sou um criador patrocinado que perdeu a objetividade"

Escreva a confissão em uma frase antes de fazer qualquer outra coisa.
**Se você não consegue nomear a confissão em uma frase, pare. O post ainda não está pronto pra ganhar comentário fixado.**

### Passo 2. Montar a imagem primeiro

Três regras pra imagem:

1. **Uma piada visual clara.** O olho cai nela em menos de um segundo. Exemplos que funcionaram: gravata pendurada no teclado de um notebook, um altar pra IA com uma rosa e velas, uma mesa de banquete onde toda outra cadeira é um logo de empresa de tecnologia.
2. **Levado totalmente a sério.** Sem piscadinha. Sem joinha. Sem caras exageradas. O humor vem de tratar o absurdo como normal.
3. **O dono é a figura de status mais baixo.** Sempre. A IA ganha. O logo ganha. A mãe ganha. O dono perde com dignidade silenciosa.

Use o formato padrão:

> "Usando a pessoa na imagem de referência anexada, crie uma imagem fotorrealista de [cena]. [Uma piada visual clara descrita em detalhe]. [Postura e expressão do dono, levadas a sério]. [Notas de luz e enquadramento]."

### Passo 3. Legendar a imagem com o comentário de 4 linhas

O comentário nomeia o que a imagem mostra como se estivesse noticiando o fato.

Estrutura fixa:

```
📌 [Linha 1: Descreve a coisa absurda como fato normal]
[Linha 2: Vira o status do dono pra baixo]
[Linha 3: Uma vitória triste, o menor ganho possível]
[Linha 4: Aceitação resignada, sem forçar a piada]
```

### Passo 4. Rodar os 5 testes antes de enviar

1. **Teste da piada visual.** Você consegue descrever a piada visual em 5 palavras? Se não, a imagem está cheia demais. Simplifique.
2. **Teste da legenda.** A linha 1 legenda a imagem como fato? Se a linha 1 monta uma piada separada, reescreva.
3. **Teste do perdedor.** O dono é a figura de status mais baixo em toda linha? Se ele ganha em algum lugar, reescreva.
4. **Teste do exagero.** A linha 4 força demais pra ter uma piada? Se sim, deixa a linha menor e mais triste. Resignado vence esperto.
5. **Teste do tédio sozinho.** Leia as 4 linhas sem a imagem. O comentário está sem graça sozinho? Ótimo. Isso quer dizer que a imagem está fazendo o trabalho pesado.

Se algum teste falhar, conserte antes de enviar.

---

## AS REGRAS DAS 4 LINHAS (inegociáveis)

- Exatamente 4 linhas. Nem mais, nem menos.
- Cada linha é uma frase completa.
- Cada linha tem no máximo 40 caracteres.
- Comece com 📌 na linha 1.
- Sem P.S. (a linha 4 É o fecho)
- Sem quebras de linha entre as frases (elas ficam coladas)
- PT-BR do começo ao fim
- Sem travessões, sem hashtags, sem ponto e vírgula
- Evite muletas e palavras de encheção (só, que, muito, realmente, na verdade, literalmente, etc.)

---

## EXEMPLO PADRÃO OURO

Esse é o referencial. Na dúvida, compare os comentários novos com este.

**A imagem:** o dono sentado de pernas cruzadas no chão de pijama listrado comendo cereal de uma tigela, olhando pra cima na direção da própria cadeira de escritório, onde um notebook aberto tem uma gravata dada de nó pendurada no teclado. Um certificado emoldurado de "Funcionário do Mês" na parede tem o logo da IA e o nome da IA. Luz da manhã, levado totalmente a sério.

**O comentário:**

```
📌 A IA usa a gravata agora.
Eu uso o pijama.
O cereal foi ideia minha, pelo menos.
Pequenas vitórias onde dá pra achar.
```

**Por que funciona:**
- A linha 1 legenda a imagem como fato (a gravata no teclado É a piada)
- A linha 2 é a virada seca mostrando a inversão de status
- A linha 3 é a vitória mais triste possível
- A linha 4 acerta sem forçar, só aceitação resignada
- As 4 linhas passam no teste do perdedor (o dono perde em todas)
- Lido sozinho, o comentário é levemente engraçado. Com a imagem, ele canta.

---

## OUTRAS PIADAS VISUAIS COMPROVADAS (pra referência)

- **Inversão de status na mesa:** notebook na cadeira usando gravata, o dono no chão de pijama
- **O altar:** velas, uma rosa, um logo de IA emoldurado, uma carta escrita à mão, o dono ajoelhado em oração
- **A mesa de banquete:** o dono na cabeceira com uma coroa de papel, toda outra cadeira ocupada por um logo de empresa de tecnologia
- **O divã do terapeuta:** o dono deitado parecendo feliz, terapeuta parecendo preocupada, logo de IA emoldurado na parede atrás dela
- **A sala de reunião:** o dono apontando pra uma apresentação, cada "executivo" na sala é um logo de empresa de tecnologia
- **O bar contra o home office:** o dono convencido numa mesa de bar enquanto o notebook dele trabalha visivelmente pela janela do outro lado da rua

---

## O QUE EVITAR

- Comentários que explicam a imagem em vez de legendá-la
- Comentários que funcionam sem a imagem (a imagem vira redundante)
- O dono ganhando, parecendo descolado ou soando esperto em qualquer linha
- Forçar uma piada esperta na linha 4
- Piadas visuais que levam mais de 5 palavras pra descrever
- Energia de piscadinha pra câmera, seja na imagem ou no comentário
- Mais de uma piada por imagem (uma é mais afiada que três)
- Nome de marca patrocinada enfiado no comentário (o post já faz isso)

---

## FORMATO DE SAÍDA

Quando disparar, sempre devolva:

1. **A confissão** (uma frase, o que o post está confessando em silêncio)
2. **O prompt da imagem** (parágrafo completo no formato padrão)
3. **O comentário de 4 linhas** (com 📌)
4. **Uma nota de uma linha** confirmando que o comentário passou nos 5 testes

Opcionalmente, ofereça 2-3 variações se a primeira tentativa ficar no limite.
